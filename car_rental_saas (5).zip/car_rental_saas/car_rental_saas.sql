/* =========================================================
   Car Rental SaaS - CLEAN DATABASE (MySQL)
   File: car_rental_saas.sql
   Copy / Paste & Run
   ========================================================= */

SET FOREIGN_KEY_CHECKS = 0;

DROP DATABASE IF EXISTS car_rental_saas;

CREATE DATABASE car_rental_saas
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE car_rental_saas;

SET FOREIGN_KEY_CHECKS = 1;

/* =========================
   1) COMPANIES
   ========================= */
CREATE TABLE companies (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) DEFAULT NULL,
    phone VARCHAR(50) DEFAULT NULL,
    address VARCHAR(255) DEFAULT NULL,
    tax_number VARCHAR(100) DEFAULT NULL,
    subscription_start_at DATE DEFAULT NULL,
    subscription_end_at DATE DEFAULT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

/* =========================
   2) USERS (Super Admin + Company Users)
   ========================= */
CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id INT UNSIGNED NULL,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(50) DEFAULT NULL,
    is_super_admin TINYINT(1) NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_users_company
      FOREIGN KEY (company_id) REFERENCES companies(id)
      ON DELETE SET NULL
) ENGINE=InnoDB;

/* =========================
   3) ROLES
   ========================= */
CREATE TABLE roles (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id INT UNSIGNED NULL,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_roles_company
      FOREIGN KEY (company_id) REFERENCES companies(id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

/* =========================
   4) USER_ROLES
   ========================= */
CREATE TABLE user_roles (
    user_id INT UNSIGNED NOT NULL,
    role_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (user_id, role_id),
    CONSTRAINT fk_user_roles_user
      FOREIGN KEY (user_id) REFERENCES users(id)
      ON DELETE CASCADE,
    CONSTRAINT fk_user_roles_role
      FOREIGN KEY (role_id) REFERENCES roles(id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

/* =========================
   5) DRIVERS (LEGAL / CONTRACT READY)
   ========================= */
CREATE TABLE drivers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id INT UNSIGNED NOT NULL,

    -- Identity
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    birth_date DATE NOT NULL,
    nationality VARCHAR(100) NOT NULL,

    -- Contact
    phone VARCHAR(50) NOT NULL,
    has_whatsapp TINYINT(1) NOT NULL DEFAULT 1,

    -- Driving License
    license_number VARCHAR(100) NOT NULL,
    license_country VARCHAR(100) NOT NULL,
    license_issue_date DATE NOT NULL,
    license_expiry_date DATE NOT NULL,
    license_category VARCHAR(10) NOT NULL DEFAULT 'B',

    -- Status
    status ENUM('active','blocked','under_review') NOT NULL DEFAULT 'under_review',

    -- Notes
    notes TEXT DEFAULT NULL,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uniq_company_license (company_id, license_number),
    INDEX idx_drivers_company (company_id),
    INDEX idx_drivers_status (company_id, status),

    CONSTRAINT fk_drivers_company
      FOREIGN KEY (company_id) REFERENCES companies(id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

/* =========================
   6) DRIVER DOCUMENTS
   ========================= */
CREATE TABLE driver_documents (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    driver_id INT UNSIGNED NOT NULL,
    type ENUM('license_front','license_back','cin','passport') NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_driver_docs_driver (driver_id),

    CONSTRAINT fk_driver_documents_driver
      FOREIGN KEY (driver_id) REFERENCES drivers(id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

/* =========================
   7) VEHICLES
   ========================= */
CREATE TABLE vehicles (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id INT UNSIGNED NOT NULL,

    brand VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,

    -- IMPORTANT (SaaS): unique per company, not global
    plate_number VARCHAR(50) NOT NULL,

    vin VARCHAR(100) DEFAULT NULL,
    year SMALLINT UNSIGNED DEFAULT NULL,
    color VARCHAR(50) DEFAULT NULL,

    mileage_current INT UNSIGNED NOT NULL DEFAULT 0,
    fuel_type ENUM('diesel','essence','hybrid','electric') DEFAULT 'diesel',
    status ENUM('in_park','on_rent','maintenance','sold') DEFAULT 'in_park',

    insurance_expiry_date DATE DEFAULT NULL,
    technical_visit_expiry_date DATE DEFAULT NULL,
    oil_change_next_at_km INT UNSIGNED DEFAULT NULL,

    purchase_price DECIMAL(10,2) DEFAULT NULL,
    sale_price DECIMAL(10,2) DEFAULT NULL,

    notes TEXT DEFAULT NULL,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uniq_company_plate (company_id, plate_number),
    INDEX idx_vehicles_company (company_id),
    INDEX idx_vehicles_status (company_id, status),

    CONSTRAINT fk_vehicles_company
      FOREIGN KEY (company_id) REFERENCES companies(id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

/* =========================
   8) PLACES (Pickup/Dropoff)
   ========================= */
CREATE TABLE places (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id INT UNSIGNED NOT NULL,
    name VARCHAR(150) NOT NULL,
    type ENUM('pickup','dropoff','both') DEFAULT 'both',
    address VARCHAR(255) DEFAULT NULL,
    city VARCHAR(100) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_places_company (company_id),

    CONSTRAINT fk_places_company
      FOREIGN KEY (company_id) REFERENCES companies(id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

/* =========================
   9) BOOKINGS
   ========================= */
CREATE TABLE bookings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id INT UNSIGNED NOT NULL,
    reference VARCHAR(50) NOT NULL UNIQUE,

    vehicle_id INT UNSIGNED NOT NULL,

    start_datetime DATETIME NOT NULL,
    end_datetime DATETIME NOT NULL,

    pickup_place_id INT UNSIGNED NULL,
    dropoff_place_id INT UNSIGNED NULL,

    start_mileage INT UNSIGNED DEFAULT NULL,
    end_mileage INT UNSIGNED DEFAULT NULL,

    start_fuel_level ENUM('empty','quarter','half','three_quarter','full') DEFAULT 'full',
    end_fuel_level   ENUM('empty','quarter','half','three_quarter','full') DEFAULT NULL,

    daily_price DECIMAL(10,2) DEFAULT NULL,
    total_days INT DEFAULT NULL,
    total_price DECIMAL(10,2) DEFAULT NULL,

    status ENUM('yet_to_start','ongoing','completed','cancelled') DEFAULT 'yet_to_start',

    paid_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    payment_status ENUM('unpaid','partial','paid') DEFAULT 'unpaid',

    addon VARCHAR(255) DEFAULT NULL,
    notes TEXT DEFAULT NULL,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_bookings_company (company_id),
    INDEX idx_bookings_vehicle_dates (vehicle_id, start_datetime, end_datetime),
    INDEX idx_bookings_status (company_id, status),

    CONSTRAINT fk_bookings_company
      FOREIGN KEY (company_id) REFERENCES companies(id)
      ON DELETE CASCADE,

    CONSTRAINT fk_bookings_vehicle
      FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
      ON DELETE RESTRICT,

    CONSTRAINT fk_bookings_pickup
      FOREIGN KEY (pickup_place_id) REFERENCES places(id)
      ON DELETE SET NULL,

    CONSTRAINT fk_bookings_dropoff
      FOREIGN KEY (dropoff_place_id) REFERENCES places(id)
      ON DELETE SET NULL
) ENGINE=InnoDB;

/* =========================
   10) BOOKING_DRIVERS (Principal/Additional)
   ========================= */
CREATE TABLE booking_drivers (
    booking_id INT UNSIGNED NOT NULL,
    driver_id INT UNSIGNED NOT NULL,
    role ENUM('principal','additional') NOT NULL,
    PRIMARY KEY (booking_id, driver_id),

    INDEX idx_booking_drivers_booking (booking_id),
    INDEX idx_booking_drivers_driver (driver_id),

    CONSTRAINT fk_booking_drivers_booking
      FOREIGN KEY (booking_id) REFERENCES bookings(id)
      ON DELETE CASCADE,

    CONSTRAINT fk_booking_drivers_driver
      FOREIGN KEY (driver_id) REFERENCES drivers(id)
      ON DELETE RESTRICT
) ENGINE=InnoDB;

/* =========================
   11) CONTRACTS
   ========================= */
CREATE TABLE contracts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id INT UNSIGNED NOT NULL,
    booking_id INT UNSIGNED NOT NULL,

    contract_number VARCHAR(50) NOT NULL UNIQUE,

    deposit_amount DECIMAL(10,2) DEFAULT 0,
    terms TEXT DEFAULT NULL,

    signed_at DATETIME DEFAULT NULL,
    pdf_path VARCHAR(255) DEFAULT NULL,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_contracts_company (company_id),
    INDEX idx_contracts_booking (booking_id),

    CONSTRAINT fk_contracts_company
      FOREIGN KEY (company_id) REFERENCES companies(id)
      ON DELETE CASCADE,

    CONSTRAINT fk_contracts_booking
      FOREIGN KEY (booking_id) REFERENCES bookings(id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

/* =========================
   12) INCOMES
   ========================= */
CREATE TABLE incomes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id INT UNSIGNED NOT NULL,
    booking_id INT UNSIGNED NULL,
    amount DECIMAL(10,2) NOT NULL,
    type ENUM('rental','penalty','other') DEFAULT 'rental',
    date DATE NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_incomes_company (company_id),
    INDEX idx_incomes_booking (booking_id),

    CONSTRAINT fk_incomes_company
      FOREIGN KEY (company_id) REFERENCES companies(id)
      ON DELETE CASCADE,

    CONSTRAINT fk_incomes_booking
      FOREIGN KEY (booking_id) REFERENCES bookings(id)
      ON DELETE SET NULL
) ENGINE=InnoDB;

/* =========================
   13) EXPENSES
   ========================= */
CREATE TABLE expenses (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id INT UNSIGNED NOT NULL,
    vehicle_id INT UNSIGNED NULL,
    amount DECIMAL(10,2) NOT NULL,
    type ENUM('maintenance','fuel','insurance','tax','other') DEFAULT 'other',
    date DATE NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_expenses_company (company_id),
    INDEX idx_expenses_vehicle (vehicle_id),

    CONSTRAINT fk_expenses_company
      FOREIGN KEY (company_id) REFERENCES companies(id)
      ON DELETE CASCADE,

    CONSTRAINT fk_expenses_vehicle
      FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
      ON DELETE SET NULL
) ENGINE=InnoDB;

/* =========================
   14) MAINTENANCE_SCHEDULES
   ========================= */
CREATE TABLE maintenance_schedules (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id INT UNSIGNED NOT NULL,
    vehicle_id INT UNSIGNED NOT NULL,

    type ENUM('oil_change','inspection','tire_change','other') DEFAULT 'other',
    due_date DATE DEFAULT NULL,
    due_mileage INT UNSIGNED DEFAULT NULL,
    status ENUM('pending','done','overdue') DEFAULT 'pending',
    notes TEXT DEFAULT NULL,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_maint_company (company_id),
    INDEX idx_maint_vehicle (vehicle_id),
    INDEX idx_maint_status (company_id, status),

    CONSTRAINT fk_maintenance_company
      FOREIGN KEY (company_id) REFERENCES companies(id)
      ON DELETE CASCADE,

    CONSTRAINT fk_maintenance_vehicle
      FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

/* =========================
   15) NOTIFICATIONS
   ========================= */
CREATE TABLE notifications (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id INT UNSIGNED NULL,
    user_id INT UNSIGNED NULL,
    type VARCHAR(100) NOT NULL,
    data JSON DEFAULT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_notifications_company (company_id),
    INDEX idx_notifications_user (user_id),

    CONSTRAINT fk_notifications_company
      FOREIGN KEY (company_id) REFERENCES companies(id)
      ON DELETE CASCADE,

    CONSTRAINT fk_notifications_user
      FOREIGN KEY (user_id) REFERENCES users(id)
      ON DELETE SET NULL
) ENGINE=InnoDB;

/* =========================
   16) COMPANY SETTINGS
   ========================= */
CREATE TABLE company_settings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    company_id INT UNSIGNED NOT NULL,
    currency VARCHAR(10) DEFAULT 'MAD',
    tax_rate DECIMAL(5,2) DEFAULT 0.00,
    timezone VARCHAR(100) DEFAULT 'Africa/Casablanca',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uniq_settings_company (company_id),

    CONSTRAINT fk_settings_company
      FOREIGN KEY (company_id) REFERENCES companies(id)
      ON DELETE CASCADE
) ENGINE=InnoDB;

/* =========================
   17) DEFAULT SUPER ADMIN
   ========================= */
INSERT INTO users (company_id, name, email, password, phone, is_super_admin, is_active)
VALUES (
    NULL,
    'Super Admin',
    'admin@example.com',
    MD5('admin123'),
    '0000000000',
    1,
    1
);

SET FOREIGN_KEY_CHECKS = 1;
