<?php
// includes/auth.php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/functions.php';

function require_login()
{
    if (!is_logged_in()) {
        redirect('login.php');
    }
}

function require_super_admin()
{
    require_login();
    if (!is_super_admin()) {
        // ممكن ترجع 403 أو توجهه لداشبورد الشركة
        redirect('index.php');
    }
}
