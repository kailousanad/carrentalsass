<?php
// includes/bootstrap.php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

// حماية أساسية: ما تبقاش تظهر errors للمستخدم (في الإنتاج)
ini_set('display_errors', '0');
error_reporting(E_ALL);

// كيخلي كل الصفحات عندها نفس timezone (بدّلها إذا بغيتي)
date_default_timezone_set('Africa/Casablanca');
