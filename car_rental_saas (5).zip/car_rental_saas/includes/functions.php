<?php
// includes/functions.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function redirect($path)
{
    header("Location: {$path}");
    exit;
}

function is_logged_in(): bool
{
    return isset($_SESSION['user_id']);
}

function is_super_admin(): bool
{
    return !empty($_SESSION['is_super_admin']) && (int)$_SESSION['is_super_admin'] === 1;
}

function current_user_id()
{
    return $_SESSION['user_id'] ?? null;
}

function current_company_id()
{
    // super admin ما عندوش company_id
    return $_SESSION['company_id'] ?? null;
}

/** =========================
 *  Flash messages
 *  ========================= */
function flash($key, $message = null)
{
    if ($message === null) {
        if (!isset($_SESSION['flash'][$key])) {
            return null;
        }
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    } else {
        $_SESSION['flash'][$key] = $message;
    }
}

/** =========================
 *  CSRF (simple)
 *  ========================= */
function csrf_token(): string
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['_csrf'];
}

function csrf_verify($token): bool
{
    return !empty($token) && !empty($_SESSION['_csrf']) && hash_equals($_SESSION['_csrf'], $token);
}

/** =========================
 *  Helpers
 *  ========================= */
function e($str): string
{
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

function money_fmt($amount): string
{
    return number_format((float)$amount, 2, '.', ' ');
}
