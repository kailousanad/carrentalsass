<?php
// public/ajax_available_vehicles.php
require_once __DIR__ . '/../includes/auth.php';
require_login();
require_once __DIR__ . '/../config/config.php';

$companyId = current_company_id();
$pickup = $_GET['pickup'] ?? '';
$return = $_GET['return'] ?? '';

if (!$pickup || !$return || strtotime($return) <= strtotime($pickup)) {
    echo json_encode([]);
    exit;
}

$stmt = $pdo->prepare("
    SELECT v.id, v.brand, v.model, v.plate_number, v.year
    FROM vehicles v
    WHERE v.company_id = :cid
      AND v.status IN ('in_park', 'available')
      AND v.id NOT IN (
        SELECT b.vehicle_id
        FROM bookings b
        WHERE b.company_id = :cid
          AND b.status NOT IN ('cancelled', 'completed')
          AND (
            (b.start_datetime <= :return AND b.end_datetime >= :pickup)
          )
      )
    ORDER BY v.brand, v.model
");
$stmt->execute(['cid' => $companyId, 'pickup' => $return, 'return' => $pickup]); // عمداً معكوس للتداخل
$vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($vehicles);