<?php
// public/ajax_calendar_events.php
require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
  http_response_code(403);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['error' => 'Forbidden']);
  exit;
}

require_once __DIR__ . '/../config/config.php';

$companyId = current_company_id();
if (!$companyId) {
  http_response_code(400);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['error' => 'Company not found']);
  exit;
}

// FullCalendar sends start/end (ISO dates)
$start = $_GET['start'] ?? '';
$end   = $_GET['end'] ?? '';

if (!$start || !$end) {
  // fallback: show current month
  $start = date('Y-m-01 00:00:00');
  $end   = date('Y-m-t 23:59:59');
}

// Normalize datetime
$startDt = date('Y-m-d H:i:s', strtotime($start));
$endDt   = date('Y-m-d H:i:s', strtotime($end));

$stmt = $pdo->prepare("
  SELECT 
    b.id,
    b.reference,
    b.start_datetime,
    b.end_datetime,
    b.status,
    b.total_price,
    v.brand, v.model, v.plate_number,
    d.first_name AS driver_first, d.last_name AS driver_last
  FROM bookings b
  JOIN vehicles v ON v.id = b.vehicle_id
  LEFT JOIN booking_drivers bd ON bd.booking_id = b.id AND bd.role = 'principal'
  LEFT JOIN drivers d ON d.id = bd.driver_id
  WHERE b.company_id = :cid
    AND (b.start_datetime < :endDt AND b.end_datetime > :startDt)
  ORDER BY b.start_datetime ASC
");

$stmt->execute([
  'cid' => $companyId,
  'startDt' => $startDt,
  'endDt' => $endDt,
]);

$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

function status_color(string $status): array {
  // background, border, text
  return match($status) {
    'yet_to_start' => ['#0d6efd', '#0d6efd', '#ffffff'], // blue
    'ongoing'      => ['#198754', '#198754', '#ffffff'], // green
    'finished'     => ['#6c757d', '#6c757d', '#ffffff'], // gray
    'cancelled'    => ['#dc3545', '#dc3545', '#ffffff'], // red
    default        => ['#212529', '#212529', '#ffffff'], // dark
  };
}

$events = [];
foreach ($rows as $r) {
  $car = trim(($r['brand'] ?? '').' '.($r['model'] ?? ''));
  $plate = $r['plate_number'] ?? '';
  $driver = trim(($r['driver_first'] ?? '').' '.($r['driver_last'] ?? ''));
  $ref = $r['reference'] ?? '';
  $status = $r['status'] ?? '';

  [$bg, $border, $text] = status_color($status);

  $events[] = [
    'id' => (string)$r['id'],
    'title' => $car . ($plate ? ' • '.$plate : '') . ($ref ? ' • '.$ref : ''),
    'start' => $r['start_datetime'],
    'end'   => $r['end_datetime'],
    'backgroundColor' => $bg,
    'borderColor' => $border,
    'textColor' => $text,
    'extendedProps' => [
      'booking_id' => (int)$r['id'],
      'reference' => $ref,
      'vehicle' => $car . ($plate ? ' ('.$plate.')' : ''),
      'client' => $driver ?: '',
      'status' => $status,
      'total_price' => (float)($r['total_price'] ?? 0),
    ]
  ];
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode($events);
