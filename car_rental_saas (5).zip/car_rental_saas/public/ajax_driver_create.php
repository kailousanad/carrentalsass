<?php
// public/ajax_driver_create.php

session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';

/**
 * ✅ AUTH CHECK (متوافق مع login.php)
 */
if (!isset($_SESSION['user_id']) || !isset($_SESSION['company_id'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized'
    ]);
    exit;
}

// Super admin ممنوع من إضافة drivers
if (!empty($_SESSION['is_super_admin'])) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'Action not allowed for super admin'
    ]);
    exit;
}

$companyId = (int) $_SESSION['company_id'];
if ($companyId <= 0) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Invalid company'
    ]);
    exit;
}

/**
 * ✅ INPUTS
 */
$first  = trim($_POST['first_name'] ?? '');
$last   = trim($_POST['last_name'] ?? '');
$phone  = trim($_POST['phone'] ?? '');
$status = trim($_POST['status'] ?? 'active');
$notes  = trim($_POST['notes'] ?? '');

/**
 * ✅ VALIDATION
 */
if ($first === '' || $last === '' || $phone === '') {
    http_response_code(422);
    echo json_encode([
        'success' => false,
        'message' => 'First name, last name and phone are required.'
    ]);
    exit;
}

try {
    /**
     * ✅ INSERT (غير الأعمدة الموجودة)
     */
    $stmt = $pdo->prepare("
        INSERT INTO drivers
            (company_id, first_name, last_name, phone, status, notes)
        VALUES
            (:company_id, :first_name, :last_name, :phone, :status, :notes)
    ");

    $stmt->execute([
        ':company_id' => $companyId,
        ':first_name' => $first,
        ':last_name'  => $last,
        ':phone'      => $phone,
        ':status'     => $status ?: 'active',
        ':notes'      => $notes ?: null,
    ]);

    $driverId = (int) $pdo->lastInsertId();

    echo json_encode([
        'success' => true,
        'driver' => [
            'id'   => $driverId,
            'name' => $first . ' ' . $last
        ]
    ]);
    exit;

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'DB error: ' . $e->getMessage()
    ]);
    exit;
}
