(function(){
  const toggleBtn =
    document.querySelector('.js-sidebar-toggle') ||
    document.querySelector('[data-sb-toggle]');

  // optional overlay element (recommended to add it once in layout)
  const overlay = document.querySelector('.sb-overlay');

  function closeSidebar(){
    document.body.classList.remove('sb-open');
  }
  function toggleSidebar(){
    document.body.classList.toggle('sb-open');
  }

  if (toggleBtn) toggleBtn.addEventListener('click', toggleSidebar);
  if (overlay) overlay.addEventListener('click', closeSidebar);

  // Close on ESC
  window.addEventListener('keydown', (e)=>{
    if (e.key === 'Escape') closeSidebar();
  });

  // Auto close when clicking sidebar links on mobile
  document.addEventListener('click', (e)=>{
    const a = e.target.closest('.sb-link, .sidebar a, .sb a');
    if (a && window.innerWidth <= 992) closeSidebar();
  });
})();
// assets/js/bookings.js

(function () {
  const form = document.getElementById('filtersForm');
  const qInput = document.getElementById('qInput');
  const statusSelect = document.getElementById('statusSelect');
  const paymentSelect = document.getElementById('paymentSelect');
  const perPageSelect = document.getElementById('perPageSelect');
  const loading = document.getElementById('ubLoading');

  // Bootstrap Toast
  const toastEl = document.getElementById('ubToast');
  const toastBody = document.getElementById('ubToastBody');
  const toast = (window.bootstrap && toastEl) ? new bootstrap.Toast(toastEl, { delay: 1800 }) : null;

  function showToast(msg) {
    if (!toast) return;
    toastBody.textContent = msg || 'Done';
    toast.show();
  }

  function showLoading() {
    if (!loading) return;
    loading.classList.add('is-show');
    loading.setAttribute('aria-hidden', 'false');
  }

  // Confirm modal (Bootstrap)
  const confirmModalEl = document.getElementById('confirmModal');
  const confirmTitle = document.getElementById('confirmTitle');
  const confirmBody = document.getElementById('confirmBody');
  const confirmGo = document.getElementById('confirmGo');
  const confirmModal = (window.bootstrap && confirmModalEl) ? new bootstrap.Modal(confirmModalEl) : null;

  // Expose confirmAction globally (used in PHP)
  window.confirmAction = function (url, title, message) {
    if (!confirmModal) {
      // fallback
      if (confirm(message || 'Are you sure?')) window.location.href = url;
      return;
    }
    confirmTitle.textContent = title || 'Confirm';
    confirmBody.textContent = message || 'Are you sure?';
    confirmGo.setAttribute('href', url);
    confirmModal.show();
  };

  // Row click open (ignore clicks on buttons/links)
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('a,button,.dropdown-menu');
    if (btn) return;

    const row = e.target.closest('tr.ub-row');
    if (row && row.dataset.href) {
      window.location.href = row.dataset.href;
    }
  });

  // Copy reference
  document.addEventListener('click', async function (e) {
    const copyBtn = e.target.closest('.ub-copy');
    if (!copyBtn) return;
    e.stopPropagation();

    const text = copyBtn.getAttribute('data-copy') || '';
    if (!text) return;

    try {
      await navigator.clipboard.writeText(text);
      showToast('Reference copied');
    } catch (_) {
      // fallback
      const t = document.createElement('textarea');
      t.value = text;
      document.body.appendChild(t);
      t.select();
      document.execCommand('copy');
      document.body.removeChild(t);
      showToast('Reference copied');
    }
  });

  // Debounced search auto-submit (600ms)
  let t = null;
  function scheduleSubmit() {
    if (!form) return;
    if (t) clearTimeout(t);
    t = setTimeout(() => {
      showLoading();
      form.submit();
    }, 600);
  }

  if (qInput) {
    qInput.addEventListener('input', function () {
      // only auto-submit if user typed 2+ chars OR cleared field
      const v = (qInput.value || '').trim();
      if (v.length >= 2 || v.length === 0) scheduleSubmit();
    });
  }

  // Change selects => submit immediately
  [statusSelect, paymentSelect, perPageSelect].forEach(el => {
    if (!el) return;
    el.addEventListener('change', function () {
      showLoading();
      if (form) form.submit();
    });
  });

  // Apply button loading
  const applyBtn = document.getElementById('applyBtn');
  if (applyBtn && form) {
    form.addEventListener('submit', function () {
      showLoading();
    });
  }
})();
// assets/js/settings.js

(function () {
  const loading = document.getElementById('usLoading');

  function showLoading() {
    if (!loading) return;
    loading.classList.add('is-show');
    loading.setAttribute('aria-hidden', 'false');
  }
  window.usShowLoading = showLoading;

  // Scroll top
  const btnTop = document.getElementById('btnScrollTop');
  if (btnTop) {
    btnTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  // Bootstrap confirm modal
  const confirmModalEl = document.getElementById('confirmModal');
  const confirmTitle = document.getElementById('confirmTitle');
  const confirmBody = document.getElementById('confirmBody');
  const confirmGo = document.getElementById('confirmGo');
  const confirmModal = (window.bootstrap && confirmModalEl) ? new bootstrap.Modal(confirmModalEl) : null;

  window.confirmActionForm = function (form, title, message) {
    if (!confirmModal) return window.confirm(message || 'Are you sure?');
    confirmTitle.textContent = title || 'Confirm';
    confirmBody.textContent = message || 'Are you sure?';
    confirmGo.onclick = function () {
      showLoading();
      form.submit();
    };
    confirmModal.show();
    return false;
  };

  // Place modal controls
  const placeModalEl = document.getElementById('placeModal');
  const placeModal = (window.bootstrap && placeModalEl) ? new bootstrap.Modal(placeModalEl) : null;

  const placeModalTitle = document.getElementById('placeModalTitle');
  const placeAction = document.getElementById('placeAction');
  const placeId = document.getElementById('placeId');
  const placeName = document.getElementById('placeName');
  const placeType = document.getElementById('placeType');
  const placeCity = document.getElementById('placeCity');
  const placeAddress = document.getElementById('placeAddress');
  const placeSaveBtn = document.getElementById('placeSaveBtn');

  window.resetPlaceModal = function () {
    if (!placeAction) return;
    placeModalTitle.textContent = 'Add place';
    placeAction.value = 'add_place';
    placeId.value = '';
    placeName.value = '';
    placeType.value = 'both';
    placeCity.value = '';
    placeAddress.value = '';
    placeSaveBtn.innerHTML = '<i class="bi bi-save me-2"></i>Save';
  };

  window.openEditPlace = function (btn) {
    const raw = btn.getAttribute('data-place');
    if (!raw) return;
    const p = JSON.parse(raw);

    placeModalTitle.textContent = 'Edit place';
    placeAction.value = 'update_place';
    placeId.value = p.id || '';
    placeName.value = p.name || '';
    placeType.value = p.type || 'both';
    placeCity.value = p.city || '';
    placeAddress.value = p.address || '';
    placeSaveBtn.innerHTML = '<i class="bi bi-check2 me-2"></i>Update';

    if (placeModal) placeModal.show();
  };

  // Price modal controls
  const priceModalEl = document.getElementById('priceModal');
  const priceModal = (window.bootstrap && priceModalEl) ? new bootstrap.Modal(priceModalEl) : null;

  const priceModalTitle = document.getElementById('priceModalTitle');
  const priceAction = document.getElementById('priceAction');
  const priceId = document.getElementById('priceId');
  const pickupSelect = document.getElementById('pickupSelect');
  const dropoffSelect = document.getElementById('dropoffSelect');
  const priceValue = document.getElementById('priceValue');
  const priceSaveBtn = document.getElementById('priceSaveBtn');

  window.resetPriceModal = function () {
    if (!priceAction) return;
    priceModalTitle.textContent = 'Add / update price';
    priceAction.value = 'save_price';
    priceId.value = '';
    pickupSelect.value = '';
    dropoffSelect.value = '';
    priceValue.value = '0';
    priceSaveBtn.innerHTML = '<i class="bi bi-save me-2"></i>Save';
  };

  window.openEditPrice = function (btn) {
    const raw = btn.getAttribute('data-price');
    if (!raw) return;
    const pp = JSON.parse(raw);

    // We will use save_price (upsert) for edit too, but pre-fill selects and value
    priceModalTitle.textContent = 'Update price rule';
    priceAction.value = 'save_price';
    priceId.value = pp.id || '';
    pickupSelect.value = pp.pickup_place_id || '';
    dropoffSelect.value = pp.dropoff_place_id || '';
    priceValue.value = (pp.price != null) ? pp.price : '0';
    priceSaveBtn.innerHTML = '<i class="bi bi-check2 me-2"></i>Update';

    if (priceModal) priceModal.show();
  };

  window.setPricePreset = function (v) {
    if (!priceValue) return;
    priceValue.value = String(v);
    priceValue.focus();
  };

  // Reset modals on hide
  if (placeModalEl) placeModalEl.addEventListener('hidden.bs.modal', window.resetPlaceModal);
  if (priceModalEl) priceModalEl.addEventListener('hidden.bs.modal', window.resetPriceModal);
})();
// assets/js/notifications.js
window.UN = (function () {
  const modalEl = document.getElementById('unConfirm');
  const titleEl = document.getElementById('unConfirmTitle');
  const bodyEl  = document.getElementById('unConfirmBody');
  const goBtn   = document.getElementById('unConfirmGo');

  const modal = (window.bootstrap && modalEl) ? new bootstrap.Modal(modalEl) : null;

  function confirmForm(form, title, message) {
    if (!modal) return window.confirm(message || 'Are you sure?');

    titleEl.textContent = title || 'Confirm';
    bodyEl.textContent = message || 'Are you sure?';

    goBtn.onclick = function () {
      form.submit();
    };

    modal.show();
    return false;
  }

  return { confirmForm };
})();
