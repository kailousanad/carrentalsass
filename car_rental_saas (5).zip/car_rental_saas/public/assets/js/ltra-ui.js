(function () {
  "use strict";

  function qs(sel, root=document){ return root.querySelector(sel); }
  function qsa(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }

  // Detect sidebar element (works with common ids/classes)
  function getSidebar(){
    return qs(".app-sidebar") || qs("#sidebar") || qs(".sidebar");
  }

  const sidebar = getSidebar();

  // overlay for mobile
  const overlay = document.createElement("div");
  overlay.className = "ultra-overlay";
  document.body.appendChild(overlay);

  function openSidebar(){
    if (!sidebar) return;
    sidebar.classList.add("ultra-open");
    overlay.classList.add("show");
    document.body.style.overflow = "hidden";
  }

  function closeSidebar(){
    if (!sidebar) return;
    sidebar.classList.remove("ultra-open");
    overlay.classList.remove("show");
    document.body.style.overflow = "";
  }

  overlay.addEventListener("click", closeSidebar);

  // 1) Sidebar toggle button
  // Put this attribute on your burger button in header: data-sidebar-toggle
  qsa("[data-sidebar-toggle]").forEach(btn=>{
    btn.addEventListener("click", function(e){
      e.preventDefault();
      if (!sidebar) return;
      const isOpen = sidebar.classList.contains("ultra-open");
      isOpen ? closeSidebar() : openSidebar();
    });
  });

  // 2) Close on ESC
  window.addEventListener("keydown", function(e){
    if (e.key === "Escape") closeSidebar();
  });

  // 3) Submenu toggle (for links having next UL)
  // Expected HTML:
  // <a class="has-submenu">Menu</a>
  // <ul class="submenu">...</ul>
  qsa(".has-submenu").forEach(a=>{
    a.addEventListener("click", function(e){
      const next = a.nextElementSibling;
      if (!next || next.tagName !== "UL") return;
      e.preventDefault();
      next.classList.toggle("open");
      a.classList.toggle("open");
    });
  });

  // If submenu has class open, show it (bootstrap-like)
  const style = document.createElement("style");
  style.innerHTML = `
    .submenu{ display:none; padding-left: 14px; margin-top:6px; }
    .submenu.open{ display:block; }
    .has-submenu{ display:flex; align-items:center; justify-content:space-between; cursor:pointer; }
    .has-submenu:after{ content:"▾"; opacity:.7; font-size:12px; }
    .has-submenu.open:after{ transform: rotate(180deg); }
  `;
  document.head.appendChild(style);

})();
