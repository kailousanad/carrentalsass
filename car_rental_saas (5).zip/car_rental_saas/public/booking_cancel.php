<?php
// public/booking_cancel.php

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$page_title = 'Cancel Booking – Car Rental SaaS';

$companyId = current_company_id();
if (!$companyId) {
    die('Company ID not found in session.');
}

if (empty($_SESSION['_csrf'])) {
    $_SESSION['_csrf'] = bin2hex(random_bytes(16));
}
$csrfToken = $_SESSION['_csrf'];

$bookingId = (int)($_GET['id'] ?? 0);
if ($bookingId <= 0) {
    die('Booking ID missing.');
}

$errors = [];
$success = '';

$stmt = $pdo->prepare("
  SELECT id, reference, vehicle_id, status, start_datetime, end_datetime
  FROM bookings
  WHERE id = :id AND company_id = :cid
  LIMIT 1
");
$stmt->execute(['id' => $bookingId, 'cid' => $companyId]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$booking) {
    die('Booking not found.');
}

// POST cancel
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['_csrf'] ?? '';
    if (!hash_equals($csrfToken, $csrf)) {
        $errors[] = 'Unauthorized (CSRF). Please refresh the page.';
    }

    // only cancel if not already cancelled/completed
    $currentStatus = (string)($booking['status'] ?? '');
    if (!in_array($currentStatus, ['yet_to_start','ongoing'], true)) {
        $errors[] = "This booking cannot be cancelled (current status: {$currentStatus}).";
    }

    if (!$errors) {
        try {
            $pdo->beginTransaction();

            // cancel booking
            $stmt = $pdo->prepare("
              UPDATE bookings
              SET status = 'cancelled'
              WHERE id = :id AND company_id = :cid
              LIMIT 1
            ");
            $stmt->execute(['id' => $bookingId, 'cid' => $companyId]);

            $vehicleId = (int)$booking['vehicle_id'];

            // if vehicle has NO other active bookings now/future, set in_park
            $stmt = $pdo->prepare("
              SELECT COUNT(*)
              FROM bookings
              WHERE company_id = :cid
                AND vehicle_id = :vid
                AND status IN ('yet_to_start','ongoing')
            ");
            $stmt->execute(['cid' => $companyId, 'vid' => $vehicleId]);
            $activeCount = (int)$stmt->fetchColumn();

            if ($activeCount <= 0) {
                $stmt = $pdo->prepare("
                  UPDATE vehicles
                  SET status = 'in_park'
                  WHERE id = :vid AND company_id = :cid
                  LIMIT 1
                ");
                $stmt->execute(['vid' => $vehicleId, 'cid' => $companyId]);
            }

            $pdo->commit();

            header('Location: booking_view.php?id=' . $bookingId);
            exit;

        } catch (Throwable $e) {
            $pdo->rollBack();
            $errors[] = 'DB error: ' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-md-10 p-4">

  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <h4 class="mb-0">Cancel Booking</h4>
      <div class="text-muted small">Reference: <strong><?= htmlspecialchars($booking['reference'] ?? '') ?></strong></div>
    </div>
    <a class="btn btn-outline-secondary" href="booking_view.php?id=<?= (int)$bookingId ?>">Back</a>
  </div>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
      <div class="fw-semibold mb-1">Please fix the following:</div>
      <ul class="mb-0">
        <?php foreach ($errors as $e): ?>
          <li><?= htmlspecialchars($e) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <div class="card shadow-sm">
    <div class="card-body">
      <div class="mb-2"><strong>Status:</strong> <?= htmlspecialchars($booking['status'] ?? '') ?></div>
      <div class="mb-2"><strong>Start:</strong> <?= htmlspecialchars($booking['start_datetime'] ?? '') ?></div>
      <div class="mb-2"><strong>End:</strong> <?= htmlspecialchars($booking['end_datetime'] ?? '') ?></div>

      <hr>

      <div class="alert alert-warning mb-3">
        ⚠️ Are you sure you want to cancel this booking? This action will set status to <strong>cancelled</strong>.
      </div>

      <form method="post">
        <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrfToken) ?>">
        <button class="btn btn-danger" type="submit">
          Confirm Cancel
        </button>
        <a class="btn btn-light" href="booking_view.php?id=<?= (int)$bookingId ?>">No, go back</a>
      </form>
    </div>
  </div>

</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
