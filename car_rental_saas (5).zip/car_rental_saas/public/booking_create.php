<?php
// public/booking_create.php

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$page_title = 'Create Booking – Car Rental SaaS';

$companyId = current_company_id();
if (!$companyId) {
    die('Company ID not found in session.');
}

/* =========================================================
   Helpers
   ========================================================= */
function json_response($data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

function table_exists(PDO $pdo, string $table): bool {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = :t");
    $stmt->execute(['t' => $table]);
    return (int)$stmt->fetchColumn() > 0;
}

function calc_days_any_part_counts(string $start, string $end): int {
    $s = strtotime($start);
    $e = strtotime($end);
    if (!$s || !$e || $e <= $s) return 0;
    $diff = $e - $s;
    $days = (int)ceil($diff / 86400);
    return max(1, $days);
}

function payment_status_from_amount(float $paid, float $total): string {
    if ($paid <= 0) return 'unpaid';
    if ($paid + 0.00001 >= $total) return 'paid';
    return 'partial';
}

function driver_license_recent_warning(?string $issueDate): ?string {
    if (!$issueDate) return null;
    $issueTs = strtotime($issueDate);
    if (!$issueTs) return null;
    $twoYears = 86400 * 365 * 2;
    if ((time() - $issueTs) < $twoYears) {
        return "⚠️ Driver license is less than 2 years old (warning only).";
    }
    return null;
}

/* =========================================================
   AJAX: Create Driver (Popup)
   URL: booking_create.php?ajax=create_driver
   Notes:
   - License < 2 years => WARNING only (not blocking)
   ========================================================= */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'create_driver') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        json_response(['ok' => false, 'message' => 'Invalid method'], 405);
    }

    $csrf = $_POST['_csrf'] ?? '';
    if (!isset($_SESSION['_csrf']) || !hash_equals($_SESSION['_csrf'], $csrf)) {
        json_response(['ok' => false, 'message' => 'Unauthorized (CSRF)'], 401);
    }

    $first_name          = trim($_POST['first_name'] ?? '');
    $last_name           = trim($_POST['last_name'] ?? '');
    $birth_date          = trim($_POST['birth_date'] ?? '');
    $nationality         = trim($_POST['nationality'] ?? '');
    $phone               = trim($_POST['phone'] ?? '');
    $has_whatsapp        = isset($_POST['has_whatsapp']) ? 1 : 0;

    $license_number      = trim($_POST['license_number'] ?? '');
    $license_country     = trim($_POST['license_country'] ?? '');
    $license_issue_date  = trim($_POST['license_issue_date'] ?? '');
    $license_expiry_date = trim($_POST['license_expiry_date'] ?? '');
    $license_category    = trim($_POST['license_category'] ?? 'B');

    $status              = trim($_POST['status'] ?? 'under_review');
    $notes               = trim($_POST['notes'] ?? '');

    $errors = [];
    $warnings = [];

    // Required
    if ($first_name === '') $errors[] = 'First name is required.';
    if ($last_name === '')  $errors[] = 'Last name is required.';
    if ($birth_date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $birth_date)) $errors[] = 'Birth date is required (YYYY-MM-DD).';
    if ($nationality === '') $errors[] = 'Nationality is required.';
    if ($phone === '') $errors[] = 'Phone is required.';
    if ($license_number === '') $errors[] = 'License number is required.';
    if ($license_country === '') $errors[] = 'License country is required.';
    if ($license_issue_date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $license_issue_date)) $errors[] = 'License issue date is required (YYYY-MM-DD).';
    if ($license_expiry_date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $license_expiry_date)) $errors[] = 'License expiry date is required (YYYY-MM-DD).';

    $allowedStatus = ['active','blocked','under_review'];
    if (!in_array($status, $allowedStatus, true)) $status = 'under_review';

    // License validity (BLOCK)
    $expTs = strtotime($license_expiry_date);
    if ($expTs && $expTs < time()) {
        $errors[] = 'License is expired.';
    }

    // Legal age 18+ (BLOCK)
    $birthTs = strtotime($birth_date);
    if ($birthTs && (time() - $birthTs) < (86400 * 365 * 18)) {
        $errors[] = 'Driver must be at least 18 years old.';
    }

    // License < 2 years (WARNING ONLY)
    $w = driver_license_recent_warning($license_issue_date);
    if ($w) $warnings[] = $w;

    if ($errors) {
        json_response(['ok' => false, 'message' => 'Validation failed', 'errors' => $errors], 422);
    }

    try {
        $stmt = $pdo->prepare("
            INSERT INTO drivers
                (company_id, first_name, last_name, birth_date, nationality, phone, has_whatsapp,
                 license_number, license_country, license_issue_date, license_expiry_date, license_category,
                 status, notes)
            VALUES
                (:company_id, :first_name, :last_name, :birth_date, :nationality, :phone, :has_whatsapp,
                 :license_number, :license_country, :license_issue_date, :license_expiry_date, :license_category,
                 :status, :notes)
        ");
        $stmt->execute([
            'company_id'          => $companyId,
            'first_name'          => $first_name,
            'last_name'           => $last_name,
            'birth_date'          => $birth_date,
            'nationality'         => $nationality,
            'phone'               => $phone,
            'has_whatsapp'        => $has_whatsapp,
            'license_number'      => $license_number,
            'license_country'     => $license_country,
            'license_issue_date'  => $license_issue_date,
            'license_expiry_date' => $license_expiry_date,
            'license_category'    => $license_category ?: 'B',
            'status'              => $status,
            'notes'               => $notes ?: null,
        ]);

        $newId = (int)$pdo->lastInsertId();
        json_response([
            'ok' => true,
            'message' => 'Driver created',
            'warnings' => $warnings,
            'driver' => [
                'id' => $newId,
                'label' => $first_name . ' ' . $last_name . ' — ' . $phone,
            ]
        ]);
    } catch (PDOException $e) {
        if (str_contains($e->getMessage(), 'uniq_company_license')) {
            json_response(['ok' => false, 'message' => 'This license number already exists for your company.'], 409);
        }
        json_response(['ok' => false, 'message' => 'DB error', 'details' => $e->getMessage()], 500);
    }
}

/* =========================================================
   Normal page load
   ========================================================= */
if (empty($_SESSION['_csrf'])) {
    $_SESSION['_csrf'] = bin2hex(random_bytes(16));
}
$csrfToken = $_SESSION['_csrf'];

/* =========================================================
   Detect Clients table (optional)
   ========================================================= */
$hasClientsTable = table_exists($pdo, 'clients');

/* =========================================================
   Fetch Places
   ========================================================= */
$stmt = $pdo->prepare("SELECT id, name, city FROM places WHERE company_id = :cid ORDER BY name ASC");
$stmt->execute(['cid' => $companyId]);
$places = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* =========================================================
   Fetch Drivers
   ========================================================= */
$stmt = $pdo->prepare("
    SELECT id, first_name, last_name, phone, birth_date, nationality,
           license_number, license_issue_date, license_expiry_date, license_country, license_category, status
    FROM drivers
    WHERE company_id = :cid
    ORDER BY id DESC
");
$stmt->execute(['cid' => $companyId]);
$drivers = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* =========================================================
   Fetch Clients (if clients table exists)
   ========================================================= */
$clients = [];
if ($hasClientsTable) {
    $stmt = $pdo->prepare("
        SELECT id,
               COALESCE(full_name, CONCAT(first_name,' ',last_name)) AS full_name,
               phone,
               birth_date,
               nationality,
               COALESCE(has_whatsapp, 1) AS has_whatsapp
        FROM clients
        WHERE company_id = :cid
        ORDER BY id DESC
    ");
    $stmt->execute(['cid' => $companyId]);
    $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    foreach ($drivers as $d) {
        $clients[] = [
            'id' => $d['id'],
            'full_name' => trim(($d['first_name'] ?? '') . ' ' . ($d['last_name'] ?? '')),
            'phone' => $d['phone'] ?? '',
            'birth_date' => $d['birth_date'] ?? '',
            'nationality' => $d['nationality'] ?? '',
            'has_whatsapp' => 1,
        ];
    }
}

/* =========================================================
   Fetch Vehicles
   ========================================================= */
$stmt = $pdo->prepare("
    SELECT id, brand, model, plate_number, status
    FROM vehicles
    WHERE company_id = :cid
    ORDER BY id DESC
");
$stmt->execute(['cid' => $companyId]);
$vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* =========================================================
   Handle POST: Create Booking
   - Vehicle overlap => BLOCK
   - License <2 years => WARNING ONLY
   - Vehicle status != in_park => WARNING ONLY
   ========================================================= */
$errors = [];
$warnings = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_GET['ajax'])) {

    $csrf = $_POST['_csrf'] ?? '';
    if (!hash_equals($csrfToken, $csrf)) {
        $errors[] = 'Unauthorized (CSRF). Please refresh the page.';
    }

    $start_datetime = trim($_POST['start_datetime'] ?? '');
    $end_datetime   = trim($_POST['end_datetime'] ?? '');

    $vehicle_id     = (int)($_POST['vehicle_id'] ?? 0);

    $pickup_place_id  = ($_POST['pickup_place_id'] ?? '') !== '' ? (int)$_POST['pickup_place_id'] : null;
    $dropoff_place_id = ($_POST['dropoff_place_id'] ?? '') !== '' ? (int)$_POST['dropoff_place_id'] : null;

    $client_id      = (int)($_POST['client_id'] ?? 0);
    $driver_id      = (int)($_POST['driver_id'] ?? 0);
    $same_client_driver = isset($_POST['same_client_driver']) ? 1 : 0;

    $daily_price    = (float)($_POST['daily_price'] ?? 0);
    $discount       = (float)($_POST['discount'] ?? 0);
    $deposit_amount = (float)($_POST['deposit_amount'] ?? 0);

    $payment_method = trim($_POST['payment_method'] ?? 'cash');
    $paid_amount    = (float)($_POST['paid_amount'] ?? 0);

    $start_mileage  = ($_POST['start_mileage'] ?? '') !== '' ? (int)$_POST['start_mileage'] : null;
    $start_fuel_level = trim($_POST['start_fuel_level'] ?? 'full');

    $notes = trim($_POST['notes'] ?? '');

    if ($start_datetime === '') $errors[] = 'Start date/time is required.';
    if ($end_datetime === '')   $errors[] = 'End date/time is required.';
    if ($vehicle_id <= 0)       $errors[] = 'Vehicle is required.';
    if ($client_id <= 0)        $errors[] = 'Client is required.';
    if ($daily_price <= 0)      $errors[] = 'Daily price must be > 0.';
    if ($deposit_amount < 0)    $errors[] = 'Deposit amount cannot be negative.';
    if ($paid_amount < 0)       $errors[] = 'Paid amount cannot be negative.';

    if ($same_client_driver) {
        $driver_id = $client_id;
    }
    if ($driver_id <= 0) {
        $errors[] = 'Driver is required.';
    }

    $days = calc_days_any_part_counts($start_datetime, $end_datetime);
    if ($days <= 0) {
        $errors[] = 'End date/time must be after start date/time.';
    }

    $allowedFuel = ['empty','quarter','half','three_quarter','full'];
    if (!in_array($start_fuel_level, $allowedFuel, true)) {
        $start_fuel_level = 'full';
    }

    $subtotal = $days * $daily_price;
    $total = max(0, $subtotal - max(0, $discount));

    if ($paid_amount > $total + 0.00001) {
        $errors[] = 'Paid amount cannot be greater than total amount.';
    }

    $payment_status = payment_status_from_amount($paid_amount, $total);

    $allowedMethods = ['cash','card','transfer'];
    if (!in_array($payment_method, $allowedMethods, true)) {
        $payment_method = 'cash';
    }

    // Vehicle status warning (NOT blocking)
    if (!$errors && $vehicle_id > 0) {
        $stmt = $pdo->prepare("SELECT status, brand, model, plate_number FROM vehicles WHERE id = :vid AND company_id = :cid LIMIT 1");
        $stmt->execute(['vid' => $vehicle_id, 'cid' => $companyId]);
        $veh = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($veh) {
            $st = (string)($veh['status'] ?? '');
            if ($st !== '' && $st !== 'in_park') {
                $warnings[] = "⚠️ Vehicle is currently '{$st}' (Out now / will return). Booking is allowed only if dates don't overlap.";
            }
        }
    }

    // Validate vehicle availability (BLOCK)
    if (!$errors) {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM bookings
            WHERE company_id = :cid
              AND vehicle_id = :vid
              AND status IN ('yet_to_start','ongoing')
              AND (start_datetime < :end_dt AND end_datetime > :start_dt)
        ");
        $stmt->execute([
            'cid' => $companyId,
            'vid' => $vehicle_id,
            'start_dt' => $start_datetime,
            'end_dt' => $end_datetime,
        ]);
        $overlaps = (int)$stmt->fetchColumn();
        if ($overlaps > 0) {
            $errors[] = 'This vehicle is not available for the selected period (already booked).';
        }
    }

    // Validate driver legal rules
    // - blocked/expired/under18 => BLOCK
    // - license <2 years => WARNING ONLY
    if (!$errors) {
        $stmt = $pdo->prepare("
            SELECT birth_date, license_issue_date, license_expiry_date, status
            FROM drivers
            WHERE id = :id AND company_id = :cid
            LIMIT 1
        ");
        $stmt->execute(['id' => $driver_id, 'cid' => $companyId]);
        $drv = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$drv) {
            $errors[] = 'Selected driver not found.';
        } else {
            if (($drv['status'] ?? '') === 'blocked') {
                $errors[] = 'Driver is blocked.';
            }

            $birthTs = strtotime($drv['birth_date'] ?? '');
            if ($birthTs && (time() - $birthTs) < (86400 * 365 * 18)) {
                $errors[] = 'Driver must be at least 18 years old.';
            }

            $expTs = strtotime($drv['license_expiry_date'] ?? '');
            if ($expTs && $expTs < time()) {
                $errors[] = 'Driver license is expired.';
            }

            $w = driver_license_recent_warning($drv['license_issue_date'] ?? null);
            if ($w) $warnings[] = $w;
        }
    }

    // Save
    if (!$errors) {
        try {
            $pdo->beginTransaction();

            $reference = 'BK' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));

            $stmt = $pdo->prepare("
                INSERT INTO bookings
                    (company_id, reference, vehicle_id, start_datetime, end_datetime,
                     pickup_place_id, dropoff_place_id,
                     start_mileage, start_fuel_level,
                     daily_price, total_days, total_price,
                     status, paid_amount, payment_status, addon, notes)
                VALUES
                    (:company_id, :reference, :vehicle_id, :start_dt, :end_dt,
                     :pickup_id, :dropoff_id,
                     :start_mileage, :start_fuel_level,
                     :daily_price, :total_days, :total_price,
                     :status, :paid_amount, :payment_status, :addon, :notes)
            ");

            $stmt->execute([
                'company_id'       => $companyId,
                'reference'        => $reference,
                'vehicle_id'       => $vehicle_id,
                'start_dt'         => $start_datetime,
                'end_dt'           => $end_datetime,
                'pickup_id'        => $pickup_place_id,
                'dropoff_id'       => $dropoff_place_id,
                'start_mileage'    => $start_mileage,
                'start_fuel_level' => $start_fuel_level,
                'daily_price'      => $daily_price,
                'total_days'       => $days,
                'total_price'      => $total,
                'status'           => 'yet_to_start',
                'paid_amount'      => $paid_amount,
                'payment_status'   => $payment_status,
                'addon'            => null,
                'notes'            => $notes ?: null,
            ]);

            $bookingId = (int)$pdo->lastInsertId();

            $stmt = $pdo->prepare("
                INSERT INTO booking_drivers (booking_id, driver_id, role)
                VALUES (:bid, :did, 'principal')
            ");
            $stmt->execute(['bid' => $bookingId, 'did' => $driver_id]);

            $additional_driver_id = (int)($_POST['additional_driver_id'] ?? 0);
            if ($additional_driver_id > 0 && $additional_driver_id !== $driver_id) {
                $stmt = $pdo->prepare("
                    INSERT INTO booking_drivers (booking_id, driver_id, role)
                    VALUES (:bid, :did, 'additional')
                ");
                $stmt->execute(['bid' => $bookingId, 'did' => $additional_driver_id]);
            }

            if ($paid_amount > 0) {
                $stmt = $pdo->prepare("
                    INSERT INTO incomes (company_id, booking_id, amount, type, date, description)
                    VALUES (:cid, :bid, :amount, 'rental', :d, :desc)
                ");
                $stmt->execute([
                    'cid' => $companyId,
                    'bid' => $bookingId,
                    'amount' => $paid_amount,
                    'd' => date('Y-m-d'),
                    'desc' => 'First payment (' . $payment_method . ')',
                ]);
            }

            // Vehicle status update (simple)
            $now = time();
            $startTs = strtotime($start_datetime);
            if ($startTs && $startTs <= $now) {
                $stmt = $pdo->prepare("
                    UPDATE vehicles
                    SET status = 'on_rent'
                    WHERE id = :vid AND company_id = :cid
                ");
                $stmt->execute(['vid' => $vehicle_id, 'cid' => $companyId]);
            }

            $pdo->commit();
            header('Location: booking_view.php?id=' . $bookingId);
            exit;

        } catch (Throwable $e) {
            $pdo->rollBack();
            $errors[] = 'DB error: ' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<!-- Flatpickr CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">



<div class="col-md-10 p-4">

  <div class="topbar d-flex justify-content-between align-items-center px-3 py-2 mb-3">
      <div>
          <h5 class="mb-0">Create Booking</h5>
          <div class="small text-muted">One-page form • Ultra date picker • Auto-calc days & total • Add Driver popup</div>
      </div>
      <div class="small text-muted">Required fields are marked <span class="text-danger">*</span></div>
  </div>

  <?php if (!empty($warnings)): ?>
      <div class="alert alert-warning">
          <div class="fw-semibold mb-1">Warnings (booking will still be created):</div>
          <ul class="mb-0">
              <?php foreach ($warnings as $w): ?>
                  <li><?= htmlspecialchars($w) ?></li>
              <?php endforeach; ?>
          </ul>
      </div>
  <?php endif; ?>

  <?php if (!empty($errors)): ?>
      <div class="alert alert-danger">
          <div class="fw-semibold mb-1">Please fix the following:</div>
          <ul class="mb-0">
              <?php foreach ($errors as $e): ?>
                  <li><?= htmlspecialchars($e) ?></li>
              <?php endforeach; ?>
          </ul>
      </div>
  <?php endif; ?>

  <form method="post" id="bookingForm" class="row g-3" novalidate>
      <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrfToken) ?>">

      <!-- LEFT -->
      <div class="col-lg-8">

          <!-- VEHICLE & DRIVERS -->
          <div class="card shadow-sm mb-3">
              <div class="card-body">
                  <div class="text-uppercase small fw-bold text-muted mb-3">Vehicle & Drivers</div>

                  <div class="row g-3 align-items-end">
                      <div class="col-md-6">
                          <label class="form-label">Vehicle <span class="text-danger">*</span></label>
                          <select class="form-select" name="vehicle_id" id="vehicle_id" required>
                              <option value="">-- Select vehicle --</option>
                              <?php foreach ($vehicles as $v): ?>
                                  <option
                                      value="<?= (int)$v['id'] ?>"
                                      data-status="<?= htmlspecialchars($v['status'] ?? '') ?>"
                                      data-label="<?= htmlspecialchars(($v['brand'] ?? '') . ' ' . ($v['model'] ?? '') . ' • ' . ($v['plate_number'] ?? '')) ?>"
                                      <?= (isset($_POST['vehicle_id']) && (int)$_POST['vehicle_id'] === (int)$v['id']) ? 'selected' : '' ?>>
                                      <?= htmlspecialchars(($v['brand'] ?? '') . ' ' . ($v['model'] ?? '') . ' • ' . ($v['plate_number'] ?? '')) ?>
                                      <?= ($v['status'] ?? '') !== 'in_park' ? ' — (' . htmlspecialchars($v['status'] ?? '') . ')' : '' ?>
                                  </option>
                              <?php endforeach; ?>
                          </select>
                          <div class="form-text d-flex align-items-center gap-2">
                            <span>Availability is checked on save (prevents double booking).</span>
                            <span id="vehStatusBadge" class="badge text-bg-secondary d-none"></span>
                          </div>
                      </div>

                      <div class="col-md-6">
                          <label class="form-label">Driver (Customer) <span class="text-danger">*</span></label>
                          <div class="d-flex gap-2">
                              <select class="form-select" name="driver_id" id="driver_id" required>
                                  <option value="">-- Select driver --</option>
                                  <?php foreach ($drivers as $d): ?>
                                      <option
                                          value="<?= (int)$d['id'] ?>"
                                          data-lic-issue="<?= htmlspecialchars($d['license_issue_date'] ?? '') ?>"
                                          data-lic-exp="<?= htmlspecialchars($d['license_expiry_date'] ?? '') ?>"
                                          data-status="<?= htmlspecialchars($d['status'] ?? '') ?>"
                                          <?= (isset($_POST['driver_id']) && (int)$_POST['driver_id'] === (int)$d['id']) ? 'selected' : '' ?>>
                                          <?= htmlspecialchars(trim(($d['first_name'] ?? '') . ' ' . ($d['last_name'] ?? '')) . ' — ' . ($d['phone'] ?? '')) ?>
                                      </option>
                                  <?php endforeach; ?>
                              </select>

                              <button type="button" class="btn btn-outline-primary" id="openDriverModal">
                                  <span class="fw-bold">+</span> Add
                              </button>
                          </div>
                          <div class="small text-muted mt-1">If driver not found, add instantly without leaving this page.</div>
                          <div id="driverWarnInline" class="small text-warning mt-1 d-none"></div>
                      </div>

                      <div class="col-md-6">
                          <label class="form-label">Second Driver (optional)</label>
                          <select class="form-select" name="additional_driver_id" id="additional_driver_id">
                              <option value="">-- None --</option>
                              <?php foreach ($drivers as $d): ?>
                                  <option value="<?= (int)$d['id'] ?>"
                                      <?= (isset($_POST['additional_driver_id']) && (int)$_POST['additional_driver_id'] === (int)$d['id']) ? 'selected' : '' ?>>
                                      <?= htmlspecialchars(trim(($d['first_name'] ?? '') . ' ' . ($d['last_name'] ?? '')) . ' — ' . ($d['phone'] ?? '')) ?>
                                  </option>
                              <?php endforeach; ?>
                          </select>
                      </div>

                      <div class="col-md-6">
                          <div class="form-check mt-4">
                              <input class="form-check-input" type="checkbox" value="1" id="same_client_driver" name="same_client_driver"
                                  <?= isset($_POST['same_client_driver']) ? 'checked' : '' ?>>
                              <label class="form-check-label" for="same_client_driver">
                                  Client is the same as Driver
                              </label>
                          </div>
                          <div class="small text-muted">If checked, principal driver will be set to selected client (MVP mode).</div>
                      </div>
                  </div>
              </div>
          </div>

          <!-- RENTAL DETAILS -->
          <div class="card shadow-sm mb-3">
              <div class="card-body">
                  <div class="text-uppercase small fw-bold text-muted mb-3">Rental Details</div>

                  <div class="row g-3">
                      <div class="col-md-6">
                          <label class="form-label">Pickup <span class="text-danger">*</span></label>
                          <select class="form-select" name="pickup_place_id">
                              <option value="">-- Select --</option>
                              <?php foreach ($places as $p): ?>
                                  <option value="<?= (int)$p['id'] ?>"
                                      <?= (isset($_POST['pickup_place_id']) && (int)$_POST['pickup_place_id'] === (int)$p['id']) ? 'selected' : '' ?>>
                                      <?= htmlspecialchars($p['name'] . (!empty($p['city']) ? ' • ' . $p['city'] : '')) ?>
                                  </option>
                              <?php endforeach; ?>
                          </select>
                      </div>

                      <div class="col-md-6">
                          <label class="form-label">Dropoff <span class="text-danger">*</span></label>
                          <select class="form-select" name="dropoff_place_id">
                              <option value="">-- Select --</option>
                              <?php foreach ($places as $p): ?>
                                  <option value="<?= (int)$p['id'] ?>"
                                      <?= (isset($_POST['dropoff_place_id']) && (int)$_POST['dropoff_place_id'] === (int)$p['id']) ? 'selected' : '' ?>>
                                      <?= htmlspecialchars($p['name'] . (!empty($p['city']) ? ' • ' . $p['city'] : '')) ?>
                                  </option>
                              <?php endforeach; ?>
                          </select>
                      </div>

                      <div class="col-md-6">
                          <label class="form-label">Start <span class="text-danger">*</span></label>
                          <input type="text" class="form-control" name="start_datetime" id="start_datetime" required
                                 value="<?= htmlspecialchars($_POST['start_datetime'] ?? '') ?>" placeholder="Select start date & time">
                      </div>

                      <div class="col-md-6">
                          <label class="form-label">End <span class="text-danger">*</span></label>
                          <input type="text" class="form-control" name="end_datetime" id="end_datetime" required
                                 value="<?= htmlspecialchars($_POST['end_datetime'] ?? '') ?>" placeholder="Select end date & time">
                      </div>
                  </div>
              </div>
          </div>

          <!-- CLIENT -->
          <div class="card shadow-sm mb-3">
              <div class="card-body">
                  <div class="text-uppercase small fw-bold text-muted mb-3">Client (Payer)</div>

                  <div class="row g-3 align-items-end">
                      <div class="col-md-12">
                          <label class="form-label">Client <span class="text-danger">*</span></label>
                          <input type="text" class="form-control mb-2" id="clientSearch" placeholder="Search by name or phone...">
                          <select class="form-select" name="client_id" id="client_id" required>
                              <option value="">-- Select client --</option>
                              <?php foreach ($clients as $c): ?>
                                  <option value="<?= (int)$c['id'] ?>"
                                      <?= (isset($_POST['client_id']) && (int)$_POST['client_id'] === (int)$c['id']) ? 'selected' : '' ?>>
                                      <?= htmlspecialchars(($c['full_name'] ?? '') . ' — ' . ($c['phone'] ?? '')) ?>
                                  </option>
                              <?php endforeach; ?>
                          </select>

                          <div class="form-text">
                              <?php if ($hasClientsTable): ?>
                                  Using <code>clients</code> table.
                              <?php else: ?>
                                  No <code>clients</code> table detected → using <code>drivers</code> as clients (MVP mode).
                              <?php endif; ?>
                          </div>
                      </div>
                  </div>

              </div>
          </div>

          <!-- FUEL & MILEAGE -->
          <div class="card shadow-sm mb-3">
              <div class="card-body">
                  <div class="text-uppercase small fw-bold text-muted mb-3">Fuel & Mileage</div>

                  <div class="row g-3">
                      <div class="col-md-6">
                          <label class="form-label">Fuel level (Start) <span class="text-danger">*</span></label>
                          <select class="form-select" name="start_fuel_level" required>
                              <?php
                              $fuelVal = $_POST['start_fuel_level'] ?? 'full';
                              foreach (['empty','quarter','half','three_quarter','full'] as $f):
                              ?>
                                  <option value="<?= $f ?>" <?= $fuelVal === $f ? 'selected' : '' ?>>
                                      <?= ucfirst(str_replace('_', ' ', $f)) ?>
                                  </option>
                              <?php endforeach; ?>
                          </select>
                      </div>

                      <div class="col-md-6">
                          <label class="form-label">Start mileage (km)</label>
                          <input type="number" class="form-control" name="start_mileage" min="0"
                                 value="<?= htmlspecialchars($_POST['start_mileage'] ?? '') ?>">
                      </div>
                  </div>
              </div>
          </div>

          <!-- NOTES -->
          <div class="card shadow-sm">
              <div class="card-body">
                  <div class="text-uppercase small fw-bold text-muted mb-3">Notes (Optional)</div>
                  <textarea class="form-control" name="notes" rows="3" placeholder="Internal notes / special conditions..."><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
              </div>
          </div>

      </div>

      <!-- RIGHT -->
      <div class="col-lg-4">
          <!-- PRICING -->
          <div class="card shadow-sm mb-3">
              <div class="card-body">
                  <div class="text-uppercase small fw-bold text-muted mb-3">Billing Summary</div>

                  <div class="row g-2">
                      <div class="col-6">
                          <div class="p-3 rounded border bg-light">
                              <div class="small text-muted">TOTAL DAYS</div>
                              <div class="fs-3 fw-bold" id="ui_days">0</div>
                              <div class="small text-muted">Any part of a day counts as 1 full day.</div>
                          </div>
                      </div>

                      <div class="col-6">
                          <div class="p-3 rounded border bg-light">
                              <div class="small text-muted">TOTAL (MAD)</div>
                              <div class="fs-3 fw-bold" id="ui_total">0.00</div>
                              <div class="small text-muted">Total = days × daily price − discount</div>
                          </div>
                      </div>
                  </div>

                  <hr>

                  <div class="mb-2">
                      <label class="form-label">Daily Price (MAD) <span class="text-danger">*</span></label>
                      <input type="number" step="0.01" min="0" class="form-control" name="daily_price" id="daily_price" required
                             value="<?= htmlspecialchars($_POST['daily_price'] ?? '') ?>">
                  </div>

                  <div class="mb-2">
                      <label class="form-label">Discount (MAD)</label>
                      <input type="number" step="0.01" min="0" class="form-control" name="discount" id="discount"
                             value="<?= htmlspecialchars($_POST['discount'] ?? '0') ?>">
                  </div>

                  <div class="mb-2">
                      <label class="form-label">Deposit Amount (MAD) <span class="text-danger">*</span></label>
                      <input type="number" step="0.01" min="0" class="form-control" name="deposit_amount" id="deposit_amount" required
                             value="<?= htmlspecialchars($_POST['deposit_amount'] ?? '0') ?>">
                  </div>

                  <input type="hidden" name="total_days" id="total_days_hidden" value="">
                  <input type="hidden" name="total_price" id="total_price_hidden" value="">
              </div>
          </div>

          <!-- PAYMENT -->
          <div class="card shadow-sm mb-3">
              <div class="card-body">
                  <div class="text-uppercase small fw-bold text-muted mb-3">Payment</div>

                  <div class="mb-2">
                      <label class="form-label">Payment Method <span class="text-danger">*</span></label>
                      <?php $pm = $_POST['payment_method'] ?? 'cash'; ?>
                      <select class="form-select" name="payment_method" id="payment_method" required>
                          <option value="cash" <?= $pm === 'cash' ? 'selected' : '' ?>>Cash</option>
                          <option value="card" <?= $pm === 'card' ? 'selected' : '' ?>>Card</option>
                          <option value="transfer" <?= $pm === 'transfer' ? 'selected' : '' ?>>Transfer</option>
                      </select>
                  </div>

                  <div class="mb-2">
                      <label class="form-label">Paid Amount (MAD)</label>
                      <input type="number" step="0.01" min="0" class="form-control" name="paid_amount" id="paid_amount"
                             value="<?= htmlspecialchars($_POST['paid_amount'] ?? '0') ?>">
                      <div class="small text-muted mt-1" id="payHint"></div>
                  </div>
              </div>
          </div>

          <!-- SUBMIT -->
          <div class="d-grid">
              <button type="submit" class="btn btn-primary btn-lg" id="submitBtn">
                  Create Booking
              </button>
              <a href="bookings.php" class="btn btn-link mt-2">Cancel</a>
          </div>
      </div>
  </form>
</div>

<!-- DRIVER MODAL -->
<div class="modal fade" id="driverModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Driver</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div id="driverModalAlert" class="alert alert-danger d-none"></div>
        <div id="driverModalWarn" class="alert alert-warning d-none"></div>

        <form id="driverForm">
          <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrfToken) ?>">

          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">First name <span class="text-danger">*</span></label>
              <input type="text" name="first_name" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Last name <span class="text-danger">*</span></label>
              <input type="text" name="last_name" class="form-control" required>
            </div>

            <div class="col-md-6">
              <label class="form-label">Birth date <span class="text-danger">*</span></label>
              <input type="date" name="birth_date" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Nationality <span class="text-danger">*</span></label>
              <input type="text" name="nationality" class="form-control" placeholder="Moroccan, French, ..." required>
            </div>

            <div class="col-md-6">
              <label class="form-label">Phone <span class="text-danger">*</span></label>
              <input type="text" name="phone" class="form-control" required>
              <div class="form-check mt-2">
                <input class="form-check-input" type="checkbox" name="has_whatsapp" id="has_whatsapp" checked>
                <label class="form-check-label" for="has_whatsapp">Has WhatsApp</label>
              </div>
            </div>

            <div class="col-md-6">
              <label class="form-label">Status</label>
              <select class="form-select" name="status">
                <option value="under_review" selected>Under review</option>
                <option value="active">Active</option>
                <option value="blocked">Blocked</option>
              </select>
            </div>

            <div class="col-md-6">
              <label class="form-label">License number <span class="text-danger">*</span></label>
              <input type="text" name="license_number" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">License country <span class="text-danger">*</span></label>
              <input type="text" name="license_country" class="form-control" placeholder="MA, FR, ES..." required>
            </div>

            <div class="col-md-6">
              <label class="form-label">License issue date <span class="text-danger">*</span></label>
              <input type="date" name="license_issue_date" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">License expiry date <span class="text-danger">*</span></label>
              <input type="date" name="license_expiry_date" class="form-control" required>
            </div>

            <div class="col-md-6">
              <label class="form-label">License category</label>
              <input type="text" name="license_category" class="form-control" value="B">
            </div>

            <div class="col-md-12">
              <label class="form-label">Notes</label>
              <textarea name="notes" class="form-control" rows="2"></textarea>
            </div>
          </div>
        </form>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="saveDriverBtn">Save Driver</button>
      </div>
    </div>
  </div>
</div>

<!-- Flatpickr JS -->
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {

  const startEl = document.getElementById('start_datetime');
  const endEl   = document.getElementById('end_datetime');

  const dailyEl    = document.getElementById('daily_price');
  const discountEl = document.getElementById('discount');
  const paidEl     = document.getElementById('paid_amount');

  const uiDays   = document.getElementById('ui_days');
  const uiTotal  = document.getElementById('ui_total');
  const hiddenDays  = document.getElementById('total_days_hidden');
  const hiddenTotal = document.getElementById('total_price_hidden');
  const payHint  = document.getElementById('payHint');

  const clientSearch = document.getElementById('clientSearch');
  const clientSelect = document.getElementById('client_id');

  const driverSelect = document.getElementById('driver_id');
  const sameCb       = document.getElementById('same_client_driver');
  const addDriverBtn = document.getElementById('openDriverModal');
  const driverWarnInline = document.getElementById('driverWarnInline');

  const vehicleSelect = document.getElementById('vehicle_id');
  const vehStatusBadge = document.getElementById('vehStatusBadge');

  const driverModalEl = document.getElementById('driverModal');
  const openBtn = document.getElementById('openDriverModal');
  const saveBtn = document.getElementById('saveDriverBtn');
  const alertBox = document.getElementById('driverModalAlert');
  const warnBox  = document.getElementById('driverModalWarn');

  function parseDT(v){
    if(!v) return null;
    const d = new Date(String(v).replace(' ', 'T'));
    return isNaN(d.getTime()) ? null : d;
  }

  function calcDaysAnyPart(start, end){
    if(!start || !end) return 0;
    if(end <= start) return 0;
    const diffMs = end - start;
    return Math.max(1, Math.ceil(diffMs / 86400000));
  }

  function money(n){ return Number(n || 0).toFixed(2); }

  function recalc(){
    const s = parseDT(startEl?.value || '');
    const e = parseDT(endEl?.value || '');
    const days = calcDaysAnyPart(s,e);

    const daily = Number(dailyEl?.value || 0);
    const disc  = Math.max(0, Number(discountEl?.value || 0));
    const total = Math.max(0, (days * daily) - disc);

    if(uiDays) uiDays.textContent = String(days || 0);
    if(uiTotal) uiTotal.textContent = money(total);

    if(hiddenDays) hiddenDays.value = String(days || 0);
    if(hiddenTotal) hiddenTotal.value = money(total);

    const paid = Math.max(0, Number(paidEl?.value || 0));
    if(payHint){
      if(paid > total + 0.0001){
        payHint.textContent = "Paid amount cannot exceed total.";
        payHint.className = "small text-danger mt-1";
      } else {
        const st = paid <= 0 ? "Unpaid" : (paid + 0.0001 >= total ? "Paid" : "Partial");
        payHint.textContent = "Payment status (auto): " + st;
        payHint.className = "small text-muted mt-1";
      }
    }
  }

  // ✅ Flatpickr Init (Disable past dates + only open future dates)
  if (window.flatpickr && startEl && endEl) {
    const now = new Date();

    const fpEnd = flatpickr(endEl, {
      enableTime: true,
      time_24hr: true,
      dateFormat: "Y-m-d H:i",
      minDate: now,
      onChange: function(){ recalc(); }
    });

    const fpStart = flatpickr(startEl, {
      enableTime: true,
      time_24hr: true,
      dateFormat: "Y-m-d H:i",
      minDate: now,
      onChange: function(selectedDates){
        const s = selectedDates[0];
        if(!s) return;

        fpEnd.set("minDate", s);

        const e = fpEnd.selectedDates[0];
        if(e && e <= s){
          const ne = new Date(s.getTime());
          ne.setDate(ne.getDate() + 1);
          fpEnd.setDate(ne, true);
        }
        recalc();
      }
    });

    // Defaults
    if(!startEl.value){
      const s = new Date();
      s.setHours(s.getHours() + 1);
      fpStart.setDate(s, true);
    }
    if(!endEl.value){
      const s = fpStart.selectedDates[0] || new Date();
      const e = new Date(s.getTime());
      e.setDate(e.getDate() + 1);
      fpEnd.setDate(e, true);
    }
  } else {
    console.warn("Flatpickr not loaded or date inputs not found.");
  }

  ['change','keyup','input'].forEach(evt=>{
    dailyEl?.addEventListener(evt, recalc);
    discountEl?.addEventListener(evt, recalc);
    paidEl?.addEventListener(evt, recalc);
  });

  // ✅ Client Search filter
  if(clientSearch && clientSelect){
    const placeholderOpt = clientSelect.querySelector('option[value=""]');
    clientSearch.addEventListener('keyup', function(){
      const q = this.value.toLowerCase().trim();
      const opts = Array.from(clientSelect.querySelectorAll('option'));
      let visibleCount = 0;

      opts.forEach((o, idx)=>{
        if(idx === 0) return;
        const text = (o.textContent || '').toLowerCase();
        const show = !q || text.includes(q);
        o.hidden = !show;
        if(show) visibleCount++;
      });

      if(placeholderOpt){
        placeholderOpt.textContent = visibleCount ? "-- Select client --" : "No results…";
      }
    });
  }

  // ✅ Same client = driver
  function syncClientDriverState(){
    if(!sameCb || !clientSelect || !driverSelect) return;

    if(sameCb.checked){
      if(clientSelect.value) driverSelect.value = clientSelect.value;
      driverSelect.disabled = true;
      if(addDriverBtn) addDriverBtn.disabled = true;
    }else{
      driverSelect.disabled = false;
      if(addDriverBtn) addDriverBtn.disabled = false;
    }
    checkDriverLicenseWarning();
  }
  sameCb?.addEventListener('change', syncClientDriverState);
  clientSelect?.addEventListener('change', function(){
    if(sameCb?.checked) driverSelect.value = clientSelect.value;
    checkDriverLicenseWarning();
  });

  // ✅ Vehicle status warning badge
  function updateVehicleBadge(){
    if(!vehicleSelect || !vehStatusBadge) return;
    const opt = vehicleSelect.options[vehicleSelect.selectedIndex];
    const st = (opt && opt.dataset && opt.dataset.status) ? opt.dataset.status : '';
    if(st && st !== 'in_park'){
      vehStatusBadge.textContent = "Vehicle: " + st;
      vehStatusBadge.classList.remove('d-none');
      vehStatusBadge.className = "badge text-bg-warning";
    }else{
      vehStatusBadge.classList.add('d-none');
    }
  }
  vehicleSelect?.addEventListener('change', updateVehicleBadge);
  updateVehicleBadge();

  // ✅ Driver license <2 years warning (inline)
  function diffDays(a,b){ return Math.floor((a-b) / 86400000); }
  function checkDriverLicenseWarning(){
    if(!driverSelect || !driverWarnInline) return;
    const opt = driverSelect.options[driverSelect.selectedIndex];
    const issue = (opt && opt.dataset) ? (opt.dataset.licIssue || '') : '';
    if(!issue){
      driverWarnInline.classList.add('d-none');
      driverWarnInline.textContent = '';
      return;
    }
    const issueDate = new Date(issue + "T00:00:00");
    if(isNaN(issueDate.getTime())){
      driverWarnInline.classList.add('d-none');
      driverWarnInline.textContent = '';
      return;
    }
    const days = diffDays(new Date(), issueDate);
    if(days < 365*2){
      driverWarnInline.textContent = "⚠️ License less than 2 years (warning only).";
      driverWarnInline.classList.remove('d-none');
    }else{
      driverWarnInline.classList.add('d-none');
      driverWarnInline.textContent = '';
    }
  }
  driverSelect?.addEventListener('change', checkDriverLicenseWarning);
  checkDriverLicenseWarning();

  syncClientDriverState();

  // ✅ Bootstrap Modal
  const hasBootstrap = (typeof window.bootstrap !== 'undefined' && window.bootstrap.Modal);
  const driverModal = (driverModalEl && hasBootstrap) ? new window.bootstrap.Modal(driverModalEl) : null;

  if(openBtn){
    openBtn.addEventListener('click', function(e){
      e.preventDefault();
      if(!driverModal){
        alert("Bootstrap Modal is not loaded. Please include bootstrap.bundle.min.js in footer.");
        console.error("Missing bootstrap.bundle.min.js (Modal).");
        return;
      }
      if(alertBox){ alertBox.classList.add('d-none'); alertBox.textContent = ''; }
      if(warnBox){ warnBox.classList.add('d-none'); warnBox.textContent = ''; }
      const form = document.getElementById('driverForm');
      form?.reset();
      const wa = document.getElementById('has_whatsapp');
      if(wa) wa.checked = true;
      driverModal.show();
    });
  }

  // ✅ Save driver via AJAX
  if(saveBtn){
    saveBtn.addEventListener('click', async function(){
      const form = document.getElementById('driverForm');
      if(!form) return;

      if(!form.checkValidity()){
        form.reportValidity();
        return;
      }

      const fd = new FormData(form);

      if(alertBox){ alertBox.classList.add('d-none'); alertBox.textContent = ''; }
      if(warnBox){ warnBox.classList.add('d-none'); warnBox.textContent = ''; }

      const oldText = saveBtn.textContent;
      saveBtn.disabled = true;
      saveBtn.textContent = 'Saving...';

      try{
        const res = await fetch('booking_create.php?ajax=create_driver', {
          method: 'POST',
          body: fd,
          headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });

        const data = await res.json().catch(()=>null);

        if(!res.ok || !data || !data.ok){
          const msg = (data && (data.message || 'Error')) || ('HTTP ' + res.status);
          const errors = (data && data.errors) ? data.errors : [];
          if(alertBox){
            alertBox.classList.remove('d-none');
            alertBox.innerHTML =
              '<div class="fw-semibold mb-1">'+msg+'</div>' +
              (errors.length ? '<ul class="mb-0">'+errors.map(e=>'<li>'+e+'</li>').join('')+'</ul>' : '');
          }
          return;
        }

        // warnings
        if(data.warnings && data.warnings.length && warnBox){
          warnBox.classList.remove('d-none');
          warnBox.innerHTML = '<div class="fw-semibold mb-1">Warning:</div><ul class="mb-0">' +
            data.warnings.map(w => '<li>'+w+'</li>').join('') + '</ul>';
        }

        // Add to driver select
        if(driverSelect){
          const opt = document.createElement('option');
          opt.value = data.driver.id;
          opt.textContent = data.driver.label;
          opt.selected = true;
          driverSelect.appendChild(opt);
        }

        // Add to additional driver select
        const addSelect = document.getElementById('additional_driver_id');
        if(addSelect){
          const opt2 = document.createElement('option');
          opt2.value = data.driver.id;
          opt2.textContent = data.driver.label;
          addSelect.appendChild(opt2);
        }

        // Add to client select (safe)
        const cSel = document.getElementById('client_id');
        if(cSel){
          const exists = !!cSel.querySelector('option[value="'+data.driver.id+'"]');
          if(!exists){
            const copt = document.createElement('option');
            copt.value = data.driver.id;
            copt.textContent = data.driver.label;
            cSel.appendChild(copt);
          }
        }

        syncClientDriverState();
        checkDriverLicenseWarning();

        // close modal after a short moment if there was a warning
        if(driverModal){
          driverModal.hide();
        }

      }catch(e){
        if(alertBox){
          alertBox.classList.remove('d-none');
          alertBox.textContent = 'Network error. Please try again.';
        }
      }finally{
        saveBtn.disabled = false;
        saveBtn.textContent = oldText;
      }
    });
  }

  // Hard stop submit if paid > total (client-side)
  const bookingForm = document.getElementById('bookingForm');
  bookingForm?.addEventListener('submit', function(e){
    const total = Number(hiddenTotal?.value || 0);
    const paid = Math.max(0, Number(paidEl?.value || 0));
    if(paid > total + 0.0001){
      e.preventDefault();
      alert("Paid amount cannot exceed total.");
      return false;
    }
  });

  recalc();
});
</script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
