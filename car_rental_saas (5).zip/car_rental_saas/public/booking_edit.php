<?php
// public/booking_edit.php

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$page_title = 'Edit Booking – Car Rental SaaS';

$companyId = current_company_id();
if (!$companyId) {
    die('Company ID not found in session.');
}

if (!isset($_GET['id']) || !ctype_digit($_GET['id'])) {
    die('Invalid booking ID.');
}
$bookingId = (int)$_GET['id'];

function column_exists(PDO $pdo, string $table, string $column): bool
{
    $sql = "
        SELECT COUNT(*) 
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = :t
          AND COLUMN_NAME = :c
        LIMIT 1
    ";
    $st = $pdo->prepare($sql);
    $st->execute(['t' => $table, 'c' => $column]);
    return (int)$st->fetchColumn() > 0;
}

$hasPaymentMethod = column_exists($pdo, 'bookings', 'payment_method');

$errors = [];
$success = '';

/* =========================
   Fetch booking
   ========================= */
$stmt = $pdo->prepare("SELECT * FROM bookings WHERE id = :id AND company_id = :cid LIMIT 1");
$stmt->execute(['id' => $bookingId, 'cid' => $companyId]);
$booking = $stmt->fetch();
if (!$booking) {
    die('Booking not found or not accessible.');
}

/* =========================
   Fetch principal/additional drivers (booking_drivers)
   ========================= */
$principalDriverId = null;
$additionalDriverId = null;

$stmt = $pdo->prepare("
    SELECT driver_id, role
    FROM booking_drivers
    WHERE booking_id = :bid
");
$stmt->execute(['bid' => $bookingId]);
$rows = $stmt->fetchAll();
foreach ($rows as $r) {
    if (($r['role'] ?? '') === 'principal') $principalDriverId = (int)$r['driver_id'];
    if (($r['role'] ?? '') === 'additional') $additionalDriverId = (int)$r['driver_id'];
}

/* =========================
   Lists: vehicles / drivers / places
   ========================= */
$stmt = $pdo->prepare("SELECT id, brand, model, plate_number, year, status FROM vehicles WHERE company_id = :cid ORDER BY id DESC");
$stmt->execute(['cid' => $companyId]);
$vehicles = $stmt->fetchAll();

$stmt = $pdo->prepare("
    SELECT id, first_name, last_name, phone, status, license_expiry_date
    FROM drivers
    WHERE company_id = :cid
    ORDER BY id DESC
");
$stmt->execute(['cid' => $companyId]);
$drivers = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT id, name, type, city FROM places WHERE company_id = :cid ORDER BY id DESC");
$stmt->execute(['cid' => $companyId]);
$places = $stmt->fetchAll();

/* =========================
   Helpers
   ========================= */
function calc_days(string $start, string $end): int
{
    $ts1 = strtotime($start);
    $ts2 = strtotime($end);
    if (!$ts1 || !$ts2 || $ts2 <= $ts1) return 0;

    $diff = (int)ceil(($ts2 - $ts1) / 86400);
    return max(1, $diff);
}

function vehicle_is_available(PDO $pdo, int $companyId, int $vehicleId, string $start, string $end, int $excludeBookingId): bool
{
    // Check overlapping bookings on same vehicle (exclude current booking)
    $sql = "
        SELECT COUNT(*)
        FROM bookings b
        WHERE b.company_id = :cid
          AND b.vehicle_id = :vid
          AND b.id <> :bid
          AND b.status <> 'cancelled'
          AND (
                (b.start_datetime < :end_dt AND b.end_datetime > :start_dt)
              )
    ";
    $st = $pdo->prepare($sql);
    $st->execute([
        'cid' => $companyId,
        'vid' => $vehicleId,
        'bid' => $excludeBookingId,
        'start_dt' => $start,
        'end_dt'   => $end,
    ]);
    return ((int)$st->fetchColumn()) === 0;
}

function driver_is_valid(PDO $pdo, int $companyId, int $driverId): bool
{
    // Minimal: must belong to company + not blocked + license not expired
    $sql = "
        SELECT status, license_expiry_date
        FROM drivers
        WHERE id = :id AND company_id = :cid
        LIMIT 1
    ";
    $st = $pdo->prepare($sql);
    $st->execute(['id' => $driverId, 'cid' => $companyId]);
    $d = $st->fetch();
    if (!$d) return false;

    if (($d['status'] ?? '') === 'blocked') return false;

    $exp = $d['license_expiry_date'] ?? null;
    if ($exp && strtotime($exp) < strtotime(date('Y-m-d'))) return false;

    return true;
}

/* =========================
   POST (Update)
   ========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $vehicle_id = isset($_POST['vehicle_id']) ? (int)$_POST['vehicle_id'] : 0;

    $pickup_place_id  = isset($_POST['pickup_place_id']) && $_POST['pickup_place_id'] !== '' ? (int)$_POST['pickup_place_id'] : null;
    $dropoff_place_id = isset($_POST['dropoff_place_id']) && $_POST['dropoff_place_id'] !== '' ? (int)$_POST['dropoff_place_id'] : null;

    $start_datetime = trim($_POST['start_datetime'] ?? '');
    $end_datetime   = trim($_POST['end_datetime'] ?? '');

    $principal_driver_id  = isset($_POST['principal_driver_id']) ? (int)$_POST['principal_driver_id'] : 0;
    $additional_driver_id = isset($_POST['additional_driver_id']) && $_POST['additional_driver_id'] !== '' ? (int)$_POST['additional_driver_id'] : null;

    $start_fuel_level = $_POST['start_fuel_level'] ?? ($booking['start_fuel_level'] ?? 'full');
    $start_mileage    = isset($_POST['start_mileage']) && $_POST['start_mileage'] !== '' ? (int)$_POST['start_mileage'] : null;

    $daily_price = isset($_POST['daily_price']) ? (float)$_POST['daily_price'] : 0;
    $discount    = isset($_POST['discount']) ? (float)$_POST['discount'] : 0;

    $addon = trim($_POST['addon'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    // Payment (optional: only if column exists)
    $payment_method = $hasPaymentMethod ? ($_POST['payment_method'] ?? ($booking['payment_method'] ?? 'cash')) : null;
    $paid_amount    = isset($_POST['paid_amount']) ? (float)$_POST['paid_amount'] : (float)($booking['paid_amount'] ?? 0);

    // Basic validations
    if ($vehicle_id <= 0) $errors[] = 'Vehicle is required.';
    if ($principal_driver_id <= 0) $errors[] = 'Principal driver is required.';
    if ($start_datetime === '' || $end_datetime === '') $errors[] = 'Start and End are required.';

    // datetime-local returns "YYYY-MM-DDTHH:MM"
    // Convert to "YYYY-MM-DD HH:MM:SS"
    $start_datetime_db = str_replace('T', ' ', $start_datetime);
    $end_datetime_db   = str_replace('T', ' ', $end_datetime);

    if (strlen($start_datetime_db) === 16) $start_datetime_db .= ':00';
    if (strlen($end_datetime_db) === 16)   $end_datetime_db   .= ':00';

    if (!$errors) {
        $ts1 = strtotime($start_datetime_db);
        $ts2 = strtotime($end_datetime_db);
        if (!$ts1 || !$ts2) {
            $errors[] = 'Invalid date/time format.';
        } elseif ($ts2 <= $ts1) {
            $errors[] = 'End must be after Start.';
        }
    }

    // Check vehicle availability for new dates
    if (!$errors && !vehicle_is_available($pdo, $companyId, $vehicle_id, $start_datetime_db, $end_datetime_db, $bookingId)) {
        $errors[] = 'This vehicle is not available for the selected period.';
    }

    // Driver validations
    if (!$errors && !driver_is_valid($pdo, $companyId, $principal_driver_id)) {
        $errors[] = 'Principal driver is not valid (blocked or license expired).';
    }
    if (!$errors && $additional_driver_id) {
        if ($additional_driver_id === $principal_driver_id) {
            $additional_driver_id = null; // prevent duplicates
        } elseif (!driver_is_valid($pdo, $companyId, $additional_driver_id)) {
            $errors[] = 'Additional driver is not valid (blocked or license expired).';
        }
    }

    // Fuel level validation
    $allowedFuel = ['empty','quarter','half','three_quarter','full'];
    if (!in_array($start_fuel_level, $allowedFuel, true)) $start_fuel_level = 'full';

    // Pricing
    $total_days = calc_days($start_datetime_db, $end_datetime_db);
    if ($total_days <= 0) $errors[] = 'Total days could not be calculated.';
    if ($daily_price < 0) $daily_price = 0;
    if ($discount < 0) $discount = 0;

    $subtotal = $total_days * $daily_price;
    $total_price = max(0, $subtotal - $discount);

    // Payment status
    if ($paid_amount < 0) $paid_amount = 0;
    if ($paid_amount > $total_price) $errors[] = 'Paid amount cannot exceed total amount.';

    $payment_status = 'unpaid';
    if ($paid_amount <= 0) $payment_status = 'unpaid';
    elseif ($paid_amount >= $total_price && $total_price > 0) $payment_status = 'paid';
    else $payment_status = 'partial';

    if (!$errors) {
        // Update bookings
        $fields = "
            vehicle_id = :vehicle_id,
            start_datetime = :start_datetime,
            end_datetime = :end_datetime,
            pickup_place_id = :pickup_place_id,
            dropoff_place_id = :dropoff_place_id,
            start_fuel_level = :start_fuel_level,
            start_mileage = :start_mileage,
            daily_price = :daily_price,
            total_days = :total_days,
            total_price = :total_price,
            paid_amount = :paid_amount,
            payment_status = :payment_status,
            addon = :addon,
            notes = :notes,
            updated_at = NOW()
        ";

        if ($hasPaymentMethod) {
            $fields .= ", payment_method = :payment_method ";
        }

        $sql = "UPDATE bookings SET $fields WHERE id = :id AND company_id = :company_id";
        $st = $pdo->prepare($sql);

        $params = [
            'vehicle_id'       => $vehicle_id,
            'start_datetime'   => $start_datetime_db,
            'end_datetime'     => $end_datetime_db,
            'pickup_place_id'  => $pickup_place_id,
            'dropoff_place_id' => $dropoff_place_id,
            'start_fuel_level' => $start_fuel_level,
            'start_mileage'    => $start_mileage,
            'daily_price'      => $daily_price,
            'total_days'       => $total_days,
            'total_price'      => $total_price,
            'paid_amount'      => $paid_amount,
            'payment_status'   => $payment_status,
            'addon'            => $addon ?: null,
            'notes'            => $notes ?: null,
            'id'               => $bookingId,
            'company_id'       => $companyId,
        ];

        if ($hasPaymentMethod) {
            $allowedMethods = ['cash','card','transfer'];
            if (!in_array($payment_method, $allowedMethods, true)) $payment_method = 'cash';
            $params['payment_method'] = $payment_method;
        }

        $st->execute($params);

        // Update booking_drivers: reset then insert principal / additional
        $pdo->prepare("DELETE FROM booking_drivers WHERE booking_id = :bid")->execute(['bid' => $bookingId]);

        $pdo->prepare("
            INSERT INTO booking_drivers (booking_id, driver_id, role)
            VALUES (:bid, :did, 'principal')
        ")->execute(['bid' => $bookingId, 'did' => $principal_driver_id]);

        if ($additional_driver_id) {
            $pdo->prepare("
                INSERT INTO booking_drivers (booking_id, driver_id, role)
                VALUES (:bid, :did, 'additional')
            ")->execute(['bid' => $bookingId, 'did' => $additional_driver_id]);
        }

        redirect('booking_view.php?id=' . $bookingId);
    }
}

/* =========================
   Prepare form values
   ========================= */
function to_datetime_local(?string $dt): string
{
    if (!$dt) return '';
    // dt in "YYYY-MM-DD HH:MM:SS" -> "YYYY-MM-DDTHH:MM"
    $dt = str_replace(' ', 'T', $dt);
    return substr($dt, 0, 16);
}

$form_vehicle_id = (int)($booking['vehicle_id'] ?? 0);
$form_pickup_id  = $booking['pickup_place_id'] ?? '';
$form_dropoff_id = $booking['dropoff_place_id'] ?? '';
$form_start      = to_datetime_local($booking['start_datetime'] ?? '');
$form_end        = to_datetime_local($booking['end_datetime'] ?? '');
$form_daily      = (float)($booking['daily_price'] ?? 0);
$form_paid       = (float)($booking['paid_amount'] ?? 0);
$form_pm         = $hasPaymentMethod ? ($booking['payment_method'] ?? 'cash') : 'cash';

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-md-10 p-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h5 class="mb-0">Edit Booking</h5>
            <div class="small text-muted">Booking: <?= htmlspecialchars($booking['reference'] ?? '') ?></div>
        </div>
        <div>
            <a href="booking_view.php?id=<?= (int)$bookingId ?>" class="btn btn-sm btn-outline-secondary">← Back</a>
        </div>
    </div>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" class="row g-3">

        <!-- LEFT -->
        <div class="col-lg-8">

            <!-- VEHICLE & DRIVERS -->
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="mb-3">Vehicle & Drivers</h6>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Vehicle *</label>
                            <select name="vehicle_id" class="form-select" required>
                                <option value="">-- Select vehicle --</option>
                                <?php foreach ($vehicles as $v): ?>
                                    <?php
                                    $label = trim(($v['brand'] ?? '') . ' ' . ($v['model'] ?? ''));
                                    $label .= !empty($v['year']) ? (' ' . $v['year']) : '';
                                    $label .= ' • ' . ($v['plate_number'] ?? '');
                                    ?>
                                    <option value="<?= (int)$v['id'] ?>" <?= ((int)$v['id'] === $form_vehicle_id) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($label) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text">Availability is checked on save.</div>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Driver (Principal) *</label>
                            <select name="principal_driver_id" class="form-select" required>
                                <option value="">-- Select driver --</option>
                                <?php foreach ($drivers as $d): ?>
                                    <?php
                                    $dn = trim(($d['first_name'] ?? '').' '.($d['last_name'] ?? ''));
                                    $phone = $d['phone'] ?? '';
                                    ?>
                                    <option value="<?= (int)$d['id'] ?>" <?= ((int)$d['id'] === (int)$principalDriverId) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($dn . ($phone ? " • $phone" : '')) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Second Driver (optional)</label>
                            <select name="additional_driver_id" class="form-select">
                                <option value="">-- None --</option>
                                <?php foreach ($drivers as $d): ?>
                                    <?php
                                    $dn = trim(($d['first_name'] ?? '').' '.($d['last_name'] ?? ''));
                                    $phone = $d['phone'] ?? '';
                                    ?>
                                    <option value="<?= (int)$d['id'] ?>" <?= ((int)$d['id'] === (int)$additionalDriverId) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($dn . ($phone ? " • $phone" : '')) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                    </div>
                </div>
            </div>

            <!-- RENTAL DETAILS -->
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="mb-3">Rental Details</h6>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Pickup</label>
                            <select name="pickup_place_id" class="form-select">
                                <option value="">-- Select --</option>
                                <?php foreach ($places as $p): ?>
                                    <option value="<?= (int)$p['id'] ?>" <?= ((string)$p['id'] === (string)$form_pickup_id) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars(($p['name'] ?? '') . (!empty($p['city']) ? (' • '.$p['city']) : '')) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Dropoff</label>
                            <select name="dropoff_place_id" class="form-select">
                                <option value="">-- Select --</option>
                                <?php foreach ($places as $p): ?>
                                    <option value="<?= (int)$p['id'] ?>" <?= ((string)$p['id'] === (string)$form_dropoff_id) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars(($p['name'] ?? '') . (!empty($p['city']) ? (' • '.$p['city']) : '')) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Start *</label>
                            <input type="datetime-local" class="form-control" name="start_datetime" value="<?= htmlspecialchars($form_start) ?>" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">End *</label>
                            <input type="datetime-local" class="form-control" name="end_datetime" value="<?= htmlspecialchars($form_end) ?>" required>
                        </div>
                    </div>
                </div>
            </div>

            <!-- FUEL & MILEAGE -->
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="mb-3">Fuel & Mileage</h6>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Fuel level (Start)</label>
                            <?php $fuel = $booking['start_fuel_level'] ?? 'full'; ?>
                            <select name="start_fuel_level" class="form-select">
                                <option value="empty" <?= $fuel==='empty'?'selected':'' ?>>Empty</option>
                                <option value="quarter" <?= $fuel==='quarter'?'selected':'' ?>>1/4</option>
                                <option value="half" <?= $fuel==='half'?'selected':'' ?>>1/2</option>
                                <option value="three_quarter" <?= $fuel==='three_quarter'?'selected':'' ?>>3/4</option>
                                <option value="full" <?= $fuel==='full'?'selected':'' ?>>Full</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Start mileage (km)</label>
                            <input type="number" min="0" class="form-control" name="start_mileage"
                                   value="<?= htmlspecialchars((string)($booking['start_mileage'] ?? '')) ?>">
                        </div>
                    </div>
                </div>
            </div>

            <!-- ADDONS & NOTES -->
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="mb-3">Addons & Notes</h6>

                    <div class="mb-3">
                        <label class="form-label">Addons</label>
                        <textarea name="addon" rows="3" class="form-control"><?= htmlspecialchars($booking['addon'] ?? '') ?></textarea>
                    </div>

                    <div>
                        <label class="form-label">Notes</label>
                        <textarea name="notes" rows="3" class="form-control"><?= htmlspecialchars($booking['notes'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>

        </div>

        <!-- RIGHT -->
        <div class="col-lg-4">

            <!-- BILLING -->
            <div class="card shadow-sm mb-3">
                <div class="card-body">
                    <h6 class="mb-3">Billing</h6>

                    <div class="mb-3">
                        <label class="form-label">Daily Price (MAD) *</label>
                        <input type="number" step="0.01" min="0" class="form-control" name="daily_price"
                               value="<?= htmlspecialchars((string)$form_daily) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Discount (MAD)</label>
                        <input type="number" step="0.01" min="0" class="form-control" name="discount" value="0">
                        <div class="form-text">Discount is used to recalc total on save.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Paid Amount (MAD)</label>
                        <input type="number" step="0.01" min="0" class="form-control" name="paid_amount"
                               value="<?= htmlspecialchars((string)$form_paid) ?>">
                    </div>

                    <?php if ($hasPaymentMethod): ?>
                        <div class="mb-3">
                            <label class="form-label">Payment Method</label>
                            <select name="payment_method" class="form-select">
                                <option value="cash" <?= $form_pm==='cash'?'selected':'' ?>>Cash</option>
                                <option value="card" <?= $form_pm==='card'?'selected':'' ?>>Card</option>
                                <option value="transfer" <?= $form_pm==='transfer'?'selected':'' ?>>Transfer</option>
                            </select>
                        </div>
                    <?php endif; ?>

                    <button type="submit" class="btn btn-primary w-100">Save changes</button>
                    <a href="booking_view.php?id=<?= (int)$bookingId ?>" class="btn btn-link w-100 mt-2">Cancel</a>
                </div>
            </div>

            <div class="alert alert-info small">
                On save we validate:
                <ul class="mb-0">
                    <li>End > Start</li>
                    <li>Vehicle availability (no overlap)</li>
                    <li>Driver not blocked + license not expired</li>
                    <li>Total = days × daily − discount</li>
                    <li>Payment status auto (unpaid/partial/paid)</li>
                </ul>
            </div>

        </div>

    </form>

</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
