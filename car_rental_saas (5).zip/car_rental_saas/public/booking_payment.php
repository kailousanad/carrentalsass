<?php
// public/booking_payment.php  (MULTI-PAYMENTS + HISTORY)

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$page_title = 'Payments – Car Rental SaaS';

$companyId = current_company_id();
if (!$companyId) {
    die('Company ID not found in session.');
}

if (!isset($_GET['id']) || !ctype_digit($_GET['id'])) {
    die('Invalid booking id.');
}
$bookingId = (int)$_GET['id'];

/* =========================================================
   Helpers
   ========================================================= */
function table_exists(PDO $pdo, string $table): bool {
    $st = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = :t");
    $st->execute(['t' => $table]);
    return (int)$st->fetchColumn() > 0;
}
function payment_status_from_amount(float $paid, float $total): string {
    if ($total <= 0) return 'unpaid';
    if ($paid <= 0) return 'unpaid';
    if ($paid + 0.00001 >= $total) return 'paid';
    return 'partial';
}
function normalize_datetime_input(string $v): string {
    $v = trim($v);
    if ($v === '') return '';
    $v = str_replace('T', ' ', $v);
    if (preg_match('/^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}$/', $v)) $v .= ':00';
    return $v;
}

/* =========================================================
   CSRF
   ========================================================= */
if (empty($_SESSION['_csrf'])) {
    $_SESSION['_csrf'] = bin2hex(random_bytes(16));
}
$csrfToken = $_SESSION['_csrf'];

/* =========================================================
   Check required table
   ========================================================= */
$hasPaymentsTable = table_exists($pdo, 'booking_payments');

if (!$hasPaymentsTable) {
    require_once __DIR__ . '/../templates/header.php';
    require_once __DIR__ . '/../templates/sidebar.php';
    ?>
    <div class="col-md-10 p-4">
        <div class="alert alert-warning">
            <div class="fw-semibold mb-1">booking_payments table not found.</div>
            <div class="small">
                Run the migration SQL first (booking_payments table), then refresh this page.
            </div>
        </div>
        <a class="btn btn-outline-secondary" href="booking_view.php?id=<?= (int)$bookingId ?>">← Back to booking</a>
    </div>
    <?php
    require_once __DIR__ . '/../templates/footer.php';
    exit;
}

/* =========================================================
   Fetch booking
   ========================================================= */
$st = $pdo->prepare("
    SELECT b.*, v.brand, v.model, v.plate_number
    FROM bookings b
    LEFT JOIN vehicles v ON v.id = b.vehicle_id
    WHERE b.id = :id AND b.company_id = :cid
    LIMIT 1
");
$st->execute(['id' => $bookingId, 'cid' => $companyId]);
$booking = $st->fetch(PDO::FETCH_ASSOC);

if (!$booking) {
    die('Booking not found.');
}

/* =========================================================
   Handle POST: add payment (append)
   ========================================================= */
$errors = [];
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['_csrf'] ?? '';
    if (!hash_equals($csrfToken, $csrf)) {
        $errors[] = 'Unauthorized (CSRF). Refresh the page.';
    } else {
        $amount  = isset($_POST['amount']) ? (float)$_POST['amount'] : 0;
        $method  = trim($_POST['method'] ?? 'cash');
        $paid_at = normalize_datetime_input($_POST['paid_at'] ?? '');
        $note    = trim($_POST['note'] ?? '');

        $allowed = ['cash','card','transfer'];
        if (!in_array($method, $allowed, true)) $errors[] = 'Invalid payment method.';
        if ($amount <= 0) $errors[] = 'Amount must be > 0.';
        if ($paid_at === '' || !strtotime($paid_at)) $errors[] = 'Paid at datetime is invalid.';

        if (!$errors) {
            try {
                $pdo->beginTransaction();

                // 1) Insert payment row
                $st = $pdo->prepare("
                    INSERT INTO booking_payments (company_id, booking_id, amount, method, paid_at, note)
                    VALUES (:cid, :bid, :amount, :method, :paid_at, :note)
                ");
                $st->execute([
                    'cid'    => $companyId,
                    'bid'    => $bookingId,
                    'amount' => $amount,
                    'method' => $method,
                    'paid_at'=> $paid_at,
                    'note'   => $note !== '' ? $note : null,
                ]);

                // 2) Recompute paid sum
                $st = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM booking_payments WHERE company_id=:cid AND booking_id=:bid");
                $st->execute(['cid'=>$companyId,'bid'=>$bookingId]);
                $paidSum = (float)$st->fetchColumn();

                $total = (float)($booking['total_price'] ?? 0);
                $payment_status = payment_status_from_amount($paidSum, $total);

                // 3) Update booking cache fields
                $st = $pdo->prepare("
                    UPDATE bookings
                    SET paid_amount = :paid,
                        payment_status = :ps,
                        payment_method = :pm
                    WHERE id = :id AND company_id = :cid
                ");
                $st->execute([
                    'paid' => $paidSum,
                    'ps'   => $payment_status,
                    'pm'   => $method, // last method
                    'id'   => $bookingId,
                    'cid'  => $companyId,
                ]);

                // 4) Optional: Finance incomes per payment
                if (table_exists($pdo, 'incomes')) {
                    $st = $pdo->prepare("
                        INSERT INTO incomes (company_id, booking_id, amount, type, date, description)
                        VALUES (:cid, :bid, :amount, 'rental', :d, :desc)
                    ");
                    $st->execute([
                        'cid'    => $companyId,
                        'bid'    => $bookingId,
                        'amount' => $amount,
                        'd'      => date('Y-m-d', strtotime($paid_at)),
                        'desc'   => 'Payment (' . $method . ') - ' . ($booking['reference'] ?? ('#'.$bookingId)),
                    ]);
                }

                $pdo->commit();
                header('Location: booking_payment.php?id='.$bookingId.'&ok=1');
                exit;

            } catch (Throwable $e) {
                $pdo->rollBack();
                $errors[] = 'DB error: ' . $e->getMessage();
            }
        }
    }
}

/* =========================================================
   Fetch payments history + sums
   ========================================================= */
$st = $pdo->prepare("
    SELECT id, amount, method, paid_at, note, created_at
    FROM booking_payments
    WHERE company_id = :cid AND booking_id = :bid
    ORDER BY paid_at DESC, id DESC
");
$st->execute(['cid'=>$companyId,'bid'=>$bookingId]);
$payments = $st->fetchAll(PDO::FETCH_ASSOC);

$st = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM booking_payments WHERE company_id=:cid AND booking_id=:bid");
$st->execute(['cid'=>$companyId,'bid'=>$bookingId]);
$paidSum = (float)$st->fetchColumn();

$total   = (float)($booking['total_price'] ?? 0);
$balance = max(0, $total - $paidSum);

if (isset($_GET['ok'])) $success = 'Payment added successfully.';

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<div class="col-md-10 p-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h5 class="mb-1">Payments – Booking <?= htmlspecialchars($booking['reference'] ?? ('#'.$bookingId)) ?></h5>
            <div class="small text-muted">
                Vehicle: <?= htmlspecialchars(trim(($booking['brand'] ?? '').' '.($booking['model'] ?? '').' • '.($booking['plate_number'] ?? ''))) ?>
            </div>
        </div>
        <div class="d-flex gap-2">
            <a class="btn btn-outline-secondary" href="booking_view.php?id=<?= (int)$bookingId ?>">← Back</a>
            <a class="btn btn-dark" href="contract_generate.php?booking_id=<?= (int)$bookingId ?>">Invoice / Contract</a>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success py-2"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <div class="fw-semibold mb-1">Please fix:</div>
            <ul class="mb-0">
                <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="row g-3">
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="text-uppercase small fw-bold text-muted mb-3">Summary</div>

                    <div class="mb-2">
                        <div class="small text-muted">Total (MAD)</div>
                        <div class="fs-4 fw-bold"><?= number_format($total, 2) ?></div>
                    </div>

                    <div class="mb-2">
                        <div class="small text-muted">Paid (MAD)</div>
                        <div class="fs-4 fw-bold"><?= number_format($paidSum, 2) ?></div>
                    </div>

                    <div class="mb-0">
                        <div class="small text-muted">Balance (MAD)</div>
                        <div class="fs-4 fw-bold"><?= number_format($balance, 2) ?></div>
                    </div>

                    <hr>

                    <div class="small text-muted">
                        Status updates automatically after every payment.
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="text-uppercase small fw-bold text-muted mb-3">Add Payment</div>

                    <form method="post" class="row g-3">
                        <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrfToken) ?>">

                        <div class="col-md-4">
                            <label class="form-label">Amount (MAD) <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" min="0" name="amount" class="form-control" required>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Method <span class="text-danger">*</span></label>
                            <select name="method" class="form-select" required>
                                <option value="cash">Cash</option>
                                <option value="card">Card</option>
                                <option value="transfer">Transfer</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Paid at <span class="text-danger">*</span></label>
                            <input type="text" name="paid_at" id="paid_at" class="form-control"
                                   value="<?= htmlspecialchars(date('Y-m-d H:i')) ?>" required>
                        </div>

                        <div class="col-12">
                            <label class="form-label">Note (optional)</label>
                            <input type="text" name="note" class="form-control" placeholder="e.g. Advance / Balance / Ref...">
                        </div>

                        <div class="col-12 d-grid">
                            <button class="btn btn-success btn-lg">Add Payment</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div class="text-uppercase small fw-bold text-muted">Payments history</div>
                        <div class="small text-muted"><?= count($payments) ?> payment(s)</div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-sm align-middle">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Method</th>
                                    <th class="text-end">Amount</th>
                                    <th>Note</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!$payments): ?>
                                    <tr><td colspan="4" class="text-center text-muted">No payments yet.</td></tr>
                                <?php else: ?>
                                    <?php foreach ($payments as $p): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($p['paid_at'] ?? '') ?></td>
                                            <td><span class="badge bg-light text-dark"><?= htmlspecialchars(strtoupper($p['method'] ?? '')) ?></span></td>
                                            <td class="text-end fw-semibold"><?= number_format((float)$p['amount'], 2) ?> MAD</td>
                                            <td class="small text-muted"><?= htmlspecialchars($p['note'] ?? '') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <hr>
                    <div class="small text-muted">
                        استعمل هاد الصفحة لكل دفعة (advance / balance / تمديد / extra...).
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
(function(){
  if (window.flatpickr) {
    flatpickr("#paid_at", { enableTime: true, time_24hr: true, dateFormat: "Y-m-d H:i" });
  }
})();
</script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
