<?php
// public/booking_return.php

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$page_title = 'Return booking – Car Rental SaaS';

$companyId = current_company_id();
if (!$companyId) die('Company ID not found in session.');

if (!isset($_GET['id']) || !ctype_digit($_GET['id'])) {
    die('Invalid booking ID.');
}
$bookingId = (int)$_GET['id'];

$errors = [];
$success = '';

/** Create notification with basic anti-spam (no duplicates in last 3 days for same vehicle+type) */
function create_notification(PDO $pdo, int $companyId, string $type, array $data, int $vehicleId): void
{
    // Anti-spam: if same type exists in last 3 days for this vehicle => skip
    $chk = $pdo->prepare("
        SELECT id
        FROM notifications
        WHERE company_id = :cid
          AND type = :type
          AND created_at >= (NOW() - INTERVAL 3 DAY)
          AND data LIKE :likeVehicle
        ORDER BY id DESC
        LIMIT 1
    ");
    $chk->execute([
        'cid' => $companyId,
        'type' => $type,
        'likeVehicle' => '%"vehicle_id":' . $vehicleId . '%'
    ]);
    if ($chk->fetch()) return;

    $pdo->prepare("
        INSERT INTO notifications (company_id, user_id, type, data, is_read, created_at)
        VALUES (:cid, NULL, :type, :data, 0, NOW())
    ")->execute([
        'cid' => $companyId,
        'type' => $type,
        'data' => json_encode($data, JSON_UNESCAPED_UNICODE),
    ]);
}

/** Maintenance check after updating mileage */
function check_oil_maintenance_and_notify(PDO $pdo, int $companyId, int $vehicleId, int $vehicleKm, array $vehicleMeta): void
{
    // Get latest ACTIVE maintenance for this vehicle
    $stmt = $pdo->prepare("
        SELECT id, oil_interval_km, km_at_service, next_service_km, status
        FROM vehicle_maintenances
        WHERE company_id=:cid AND vehicle_id=:vid AND status='active'
        ORDER BY id DESC
        LIMIT 1
    ");
    $stmt->execute(['cid'=>$companyId,'vid'=>$vehicleId]);
    $m = $stmt->fetch();

    if (!$m) return;

    $remaining = (int)$m['next_service_km'] - $vehicleKm;

    // Build payload
    $payload = [
        'vehicle_id' => $vehicleId,
        'plate' => $vehicleMeta['plate_number'] ?? null,
        'vehicle' => trim(($vehicleMeta['brand'] ?? '') . ' ' . ($vehicleMeta['model'] ?? '')),
        'current_km' => $vehicleKm,
        'next_service_km' => (int)$m['next_service_km'],
        'remaining_km' => $remaining,
        'interval_km' => (int)$m['oil_interval_km'],
        'maintenance_id' => (int)$m['id'],
        'kind' => 'oil_change'
    ];

    // Decide notification type
    if ($remaining <= 0) {
        create_notification($pdo, $companyId, 'oil_change_due', $payload, $vehicleId);
    } elseif ($remaining <= 200) {
        create_notification($pdo, $companyId, 'oil_change_urgent', $payload, $vehicleId);
    } elseif ($remaining <= 500) {
        create_notification($pdo, $companyId, 'oil_change_soon', $payload, $vehicleId);
    }
}

// Load booking + vehicle
$sql = "
    SELECT b.*,
           v.brand, v.model, v.plate_number, v.status AS vehicle_status, v.mileage_current
    FROM bookings b
    JOIN vehicles v ON v.id = b.vehicle_id
    WHERE b.id = :id AND b.company_id = :cid
    LIMIT 1
";
$stmt = $pdo->prepare($sql);
$stmt->execute(['id'=>$bookingId,'cid'=>$companyId]);
$booking = $stmt->fetch();

if (!$booking) die('Booking not found or not accessible.');

if (in_array($booking['status'], ['cancelled','completed'], true)) {
    die('This booking is already closed.');
}

// Handle POST (return)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $end_mileage = isset($_POST['end_mileage']) && $_POST['end_mileage'] !== '' ? (int)$_POST['end_mileage'] : null;
    $end_fuel    = $_POST['end_fuel_level'] ?? null;
    $return_note = trim($_POST['return_note'] ?? '');

    $allowedFuel = ['empty','quarter','half','three_quarter','full'];

    if ($end_mileage === null || $end_mileage < 0) $errors[] = 'End mileage is required.';
    if ($booking['start_mileage'] !== null && $end_mileage !== null && $end_mileage < (int)$booking['start_mileage']) {
        $errors[] = 'End mileage must be >= start mileage.';
    }
    if ($end_fuel !== null && $end_fuel !== '' && !in_array($end_fuel, $allowedFuel, true)) {
        $errors[] = 'Invalid fuel level.';
    }

    if (!$errors) {
        $pdo->beginTransaction();
        try {
            $vehicleId = (int)$booking['vehicle_id'];

            // 1) Update booking (close)
            $up = $pdo->prepare("
                UPDATE bookings
                SET end_mileage = :end_mileage,
                    end_fuel_level = :end_fuel,
                    status = 'completed',
                    notes = CASE 
                              WHEN :note = '' OR :note IS NULL THEN notes
                              WHEN notes IS NULL OR notes = '' THEN :note
                              ELSE CONCAT(notes, '\n', :note)
                            END
                WHERE id=:id AND company_id=:cid
                LIMIT 1
            ");
            $up->execute([
                'end_mileage' => $end_mileage,
                'end_fuel'    => ($end_fuel !== '' ? $end_fuel : null),
                'note'        => ($return_note ?: null),
                'id'          => $bookingId,
                'cid'         => $companyId
            ]);

            // 2) Update vehicle mileage_current = end_mileage
            $pdo->prepare("
                UPDATE vehicles
                SET mileage_current = :km
                WHERE id=:vid AND company_id=:cid
                LIMIT 1
            ")->execute([
                'km'  => $end_mileage,
                'vid' => $vehicleId,
                'cid' => $companyId
            ]);

            // 3) Return vehicle to in_park unless sold
            if (($booking['vehicle_status'] ?? '') !== 'sold') {
                $pdo->prepare("
                    UPDATE vehicles
                    SET status='in_park'
                    WHERE id=:vid AND company_id=:cid AND status!='sold'
                    LIMIT 1
                ")->execute([
                    'vid' => $vehicleId,
                    'cid' => $companyId
                ]);
            }

            // 4) Maintenance check + notifications
            check_oil_maintenance_and_notify(
                $pdo,
                $companyId,
                $vehicleId,
                (int)$end_mileage,
                [
                    'brand' => $booking['brand'] ?? '',
                    'model' => $booking['model'] ?? '',
                    'plate_number' => $booking['plate_number'] ?? ''
                ]
            );

            $pdo->commit();

            header('Location: booking_view.php?id=' . $bookingId);
            exit;

        } catch (Throwable $e) {
            $pdo->rollBack();
            $errors[] = 'Error: ' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-md-10 p-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h5 class="mb-1">Return booking #<?= htmlspecialchars($booking['reference'] ?? '') ?></h5>
            <div class="small text-muted">
                Vehicle: <?= htmlspecialchars(($booking['brand'] ?? '').' '.($booking['model'] ?? '').' ('.$booking['plate_number'].')') ?>
            </div>
        </div>
        <div class="text-end">
            <a href="booking_view.php?id=<?= (int)$bookingId ?>" class="btn btn-sm btn-outline-secondary">← Back</a>
        </div>
    </div>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $e): ?>
                <div><?= htmlspecialchars($e) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <h6 class="mb-3">Return details</h6>

            <div class="row g-3 mb-2">
                <div class="col-md-4">
                    <div class="p-2 bg-light rounded">
                        <div class="small text-muted">Start mileage</div>
                        <div class="fw-semibold">
                            <?= ($booking['start_mileage'] !== null) ? (int)$booking['start_mileage'].' km' : '—' ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="p-2 bg-light rounded">
                        <div class="small text-muted">Current vehicle KM</div>
                        <div class="fw-semibold"><?= (int)($booking['mileage_current'] ?? 0) ?> km</div>
                    </div>
                </div>
            </div>

            <form method="post" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">End mileage (km) *</label>
                    <input type="number" min="0" class="form-control" name="end_mileage" required>
                    <div class="form-text">This will update the vehicle mileage automatically.</div>
                </div>

                <div class="col-md-4">
                    <label class="form-label">End fuel level</label>
                    <select name="end_fuel_level" class="form-select">
                        <option value="">—</option>
                        <option value="empty">Empty</option>
                        <option value="quarter">1/4</option>
                        <option value="half">1/2</option>
                        <option value="three_quarter">3/4</option>
                        <option value="full">Full</option>
                    </select>
                </div>

                <div class="col-md-12">
                    <label class="form-label">Return note</label>
                    <textarea name="return_note" rows="3" class="form-control" placeholder="Optional..."></textarea>
                </div>

                <div class="col-md-12 text-end">
                    <button class="btn btn-success" onclick="return confirm('Close this booking? This will update vehicle KM and create maintenance alerts if needed.')">
                        Close booking
                    </button>
                </div>
            </form>

        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
