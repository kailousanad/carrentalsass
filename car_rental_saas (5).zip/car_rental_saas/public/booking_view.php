<?php
// public/booking_view.php

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$page_title = 'Booking details – Car Rental SaaS';

$companyId = current_company_id();
if (!$companyId) {
    die('Company ID not found in session.');
}

if (!isset($_GET['id']) || !ctype_digit($_GET['id'])) {
    die('Invalid booking ID.');
}
$bookingId = (int)$_GET['id'];

if (empty($_SESSION['_csrf'])) {
    $_SESSION['_csrf'] = bin2hex(random_bytes(16));
}
$csrfToken = $_SESSION['_csrf'];

$errors = [];
$success = '';

function table_exists(PDO $pdo, string $table): bool {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = :t");
    $stmt->execute(['t' => $table]);
    return (int)$stmt->fetchColumn() > 0;
}

function booking_status_badge($status): string
{
    $badgeClass = 'bg-secondary';
    $label = $status;

    switch ($status) {
        case 'yet_to_start':
            $badgeClass = 'bg-warning text-dark';
            $label = 'Yet to start';
            break;
        case 'ongoing':
            $badgeClass = 'bg-primary';
            $label = 'Ongoing';
            break;
        case 'completed':
            $badgeClass = 'bg-success';
            $label = 'Completed';
            break;
        case 'cancelled':
            $badgeClass = 'bg-danger';
            $label = 'Cancelled';
            break;
    }

    return '<span class="badge '.$badgeClass.'">'.htmlspecialchars($label).'</span>';
}

function fuel_label($value): string
{
    switch ($value) {
        case 'empty':         return 'Empty';
        case 'quarter':       return '1/4';
        case 'half':          return '1/2';
        case 'three_quarter': return '3/4';
        case 'full':          return 'Full';
        default:              return '—';
    }
}

function normalize_fuel($value): string {
    $allowed = ['empty','quarter','half','three_quarter','full'];
    return in_array($value, $allowed, true) ? $value : 'full';
}

function calc_extra_days(string $plannedEnd, string $actualReturn): int {
    $p = strtotime($plannedEnd);
    $a = strtotime($actualReturn);
    if (!$p || !$a) return 0;
    if ($a <= $p) return 0;

    $diff = $a - $p;
    // Any part of a day counts as 1
    $days = (int)ceil($diff / 86400);
    return max(1, $days);
}

/**
 * Load booking + vehicle + places
 */
$sql = "
    SELECT 
        b.*,
        v.brand, v.model, v.plate_number, v.color, v.mileage_current AS vehicle_mileage_current, v.status AS vehicle_status,
        p1.name AS pickup_name,
        p2.name AS dropoff_name
    FROM bookings b
    LEFT JOIN vehicles v ON b.vehicle_id = v.id
    LEFT JOIN places  p1 ON b.pickup_place_id = p1.id
    LEFT JOIN places  p2 ON b.dropoff_place_id = p2.id
    WHERE b.id = :id AND b.company_id = :company_id
    LIMIT 1
";
$stmt = $pdo->prepare($sql);
$stmt->execute([
    'id' => $bookingId,
    'company_id' => $companyId
]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$booking) {
    die('Booking not found or not accessible.');
}

/**
 * Load closure data if exists
 */
$hasClosures = table_exists($pdo, 'booking_closures');
$closure = null;
if ($hasClosures) {
    $stmt = $pdo->prepare("SELECT * FROM booking_closures WHERE booking_id = :bid AND company_id = :cid LIMIT 1");
    $stmt->execute(['bid' => $bookingId, 'cid' => $companyId]);
    $closure = $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Handle Start / End actions
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['_csrf'] ?? '';
    if (!hash_equals($csrfToken, $csrf)) {
        $errors[] = 'Unauthorized (CSRF). Please refresh the page.';
    } else {

        $action = $_POST['action'] ?? '';

        // Reload booking fresh
        $stmt = $pdo->prepare("SELECT * FROM bookings WHERE id = :id AND company_id = :cid LIMIT 1");
        $stmt->execute(['id' => $bookingId, 'cid' => $companyId]);
        $fresh = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$fresh) {
            $errors[] = 'Booking not found.';
        } else {

            /* =======================
               START RENTAL
               ======================= */
            if ($action === 'start_rental') {
                if (($fresh['status'] ?? '') !== 'yet_to_start') {
                    $errors[] = 'You can only start a booking that is Yet to start.';
                } else {

                    $start_mileage = ($_POST['start_mileage'] ?? '') !== '' ? (int)$_POST['start_mileage'] : null;
                    $start_fuel = normalize_fuel($_POST['start_fuel_level'] ?? ($fresh['start_fuel_level'] ?? 'full'));

                    // fallback to vehicle current mileage
                    if ($start_mileage === null) {
                        $start_mileage = ($booking['vehicle_mileage_current'] ?? null) !== null ? (int)$booking['vehicle_mileage_current'] : null;
                    }

                    if ($start_mileage !== null && $start_mileage < 0) {
                        $errors[] = 'Start mileage must be >= 0.';
                    }

                    if (!$errors) {
                        try {
                            $pdo->beginTransaction();

                            $stmt = $pdo->prepare("
                                UPDATE bookings
                                SET start_mileage = :sm,
                                    start_fuel_level = :sf,
                                    status = 'ongoing'
                                WHERE id = :id AND company_id = :cid
                            ");
                            $stmt->execute([
                                'sm' => $start_mileage,
                                'sf' => $start_fuel,
                                'id' => $bookingId,
                                'cid' => $companyId,
                            ]);

                            $stmt = $pdo->prepare("
                                UPDATE vehicles
                                SET status = 'on_rent'
                                WHERE id = :vid AND company_id = :cid
                            ");
                            $stmt->execute([
                                'vid' => (int)$fresh['vehicle_id'],
                                'cid' => $companyId,
                            ]);

                            // Sync mileage_current if provided
                            if ($start_mileage !== null) {
                                $stmt = $pdo->prepare("
                                    UPDATE vehicles
                                    SET mileage_current = GREATEST(COALESCE(mileage_current,0), :m)
                                    WHERE id = :vid AND company_id = :cid
                                ");
                                $stmt->execute([
                                    'm' => $start_mileage,
                                    'vid' => (int)$fresh['vehicle_id'],
                                    'cid' => $companyId,
                                ]);
                            }

                            $pdo->commit();
                            header('Location: booking_view.php?id=' . $bookingId . '&ok=started');
                            exit;

                        } catch (Throwable $e) {
                            $pdo->rollBack();
                            $errors[] = 'DB error: ' . $e->getMessage();
                        }
                    }
                }
            }

            /* =======================
               END RENTAL PRO
               ======================= */
            if ($action === 'end_rental_pro') {
                if (($fresh['status'] ?? '') !== 'ongoing') {
                    $errors[] = 'You can only end a booking that is Ongoing.';
                } else {
                    $end_mileage = ($_POST['end_mileage'] ?? '') !== '' ? (int)$_POST['end_mileage'] : null;
                    $end_fuel = normalize_fuel($_POST['end_fuel_level'] ?? 'full');

                    $actual_return_datetime = trim($_POST['actual_return_datetime'] ?? '');
                    if ($actual_return_datetime === '') {
                        // default now if missing
                        $actual_return_datetime = date('Y-m-d H:i:s');
                    } else {
                        // accept datetime-local format too
                        $ts = strtotime($actual_return_datetime);
                        if (!$ts) {
                            $errors[] = 'Invalid actual return date/time.';
                        } else {
                            $actual_return_datetime = date('Y-m-d H:i:s', $ts);
                        }
                    }

                    $fuel_charge   = (float)($_POST['fuel_charge'] ?? 0);
                    $damage_charge = (float)($_POST['damage_charge'] ?? 0);
                    $damage_notes  = trim($_POST['damage_notes'] ?? '');

                    if ($end_mileage === null) {
                        $errors[] = 'End mileage is required to close the rental.';
                    } elseif ($end_mileage < 0) {
                        $errors[] = 'End mileage must be >= 0.';
                    }

                    $startMileage = ($fresh['start_mileage'] ?? null) !== null ? (int)$fresh['start_mileage'] : null;
                    if ($startMileage !== null && $end_mileage !== null && $end_mileage < $startMileage) {
                        $errors[] = 'End mileage cannot be less than start mileage.';
                    }

                    if ($fuel_charge < 0)   $errors[] = 'Fuel charge cannot be negative.';
                    if ($damage_charge < 0) $errors[] = 'Damage charge cannot be negative.';

                    // compute extra days + charges
                    $plannedEnd = $fresh['end_datetime'] ?? '';
                    $extra_days = ($plannedEnd && $actual_return_datetime) ? calc_extra_days($plannedEnd, $actual_return_datetime) : 0;
                    $daily = (float)($fresh['daily_price'] ?? 0);
                    $extra_day_charge = $extra_days > 0 ? ($extra_days * $daily) : 0;

                    $base_total = (float)($fresh['total_price'] ?? 0);
                    $total_extra = max(0, $extra_day_charge) + max(0, $fuel_charge) + max(0, $damage_charge);
                    $final_total = $base_total + $total_extra;

                    if (!$errors) {
                        try {
                            $pdo->beginTransaction();

                            // Update booking end data
                            $stmt = $pdo->prepare("
                                UPDATE bookings
                                SET end_mileage = :em,
                                    end_fuel_level = :ef,
                                    status = 'completed'
                                WHERE id = :id AND company_id = :cid
                            ");
                            $stmt->execute([
                                'em' => $end_mileage,
                                'ef' => $end_fuel,
                                'id' => $bookingId,
                                'cid' => $companyId,
                            ]);

                            // Update vehicle back to park + set mileage_current
                            $stmt = $pdo->prepare("
                                UPDATE vehicles
                                SET status = 'in_park',
                                    mileage_current = :m
                                WHERE id = :vid AND company_id = :cid
                            ");
                            $stmt->execute([
                                'm' => $end_mileage,
                                'vid' => (int)$fresh['vehicle_id'],
                                'cid' => $companyId,
                            ]);

                            // Save closure (if table exists)
                            if ($hasClosures) {
                                $stmt = $pdo->prepare("
                                    INSERT INTO booking_closures
                                        (company_id, booking_id, actual_return_datetime, extra_days,
                                         extra_day_charge, fuel_charge, damage_charge, damage_notes,
                                         total_extra, final_total)
                                    VALUES
                                        (:cid, :bid, :ard, :ed,
                                         :edc, :fc, :dc, :dn,
                                         :te, :ft)
                                    ON DUPLICATE KEY UPDATE
                                        actual_return_datetime = VALUES(actual_return_datetime),
                                        extra_days = VALUES(extra_days),
                                        extra_day_charge = VALUES(extra_day_charge),
                                        fuel_charge = VALUES(fuel_charge),
                                        damage_charge = VALUES(damage_charge),
                                        damage_notes = VALUES(damage_notes),
                                        total_extra = VALUES(total_extra),
                                        final_total = VALUES(final_total)
                                ");
                                $stmt->execute([
                                    'cid' => $companyId,
                                    'bid' => $bookingId,
                                    'ard' => $actual_return_datetime,
                                    'ed'  => (int)$extra_days,
                                    'edc' => (float)$extra_day_charge,
                                    'fc'  => (float)$fuel_charge,
                                    'dc'  => (float)$damage_charge,
                                    'dn'  => $damage_notes ?: null,
                                    'te'  => (float)$total_extra,
                                    'ft'  => (float)$final_total,
                                ]);
                            } else {
                                // fallback: append to notes if closures table missing
                                $extraText = "\n\n[Closure]\nActual return: {$actual_return_datetime}\nExtra days: {$extra_days}\nExtra day charge: {$extra_day_charge}\nFuel charge: {$fuel_charge}\nDamage charge: {$damage_charge}\nDamage notes: {$damage_notes}\nFinal total: {$final_total}\n";
                                $stmt = $pdo->prepare("UPDATE bookings SET notes = CONCAT(COALESCE(notes,''), :t) WHERE id = :id AND company_id = :cid");
                                $stmt->execute(['t' => $extraText, 'id' => $bookingId, 'cid' => $companyId]);
                            }

                            // Optional: record extra income (type extra)
                            if ($total_extra > 0.00001) {
                                // incomes table exists in your schema (used already in booking_create)
                                $stmt = $pdo->prepare("
                                    INSERT INTO incomes (company_id, booking_id, amount, type, date, description)
                                    VALUES (:cid, :bid, :amount, 'extra', :d, :desc)
                                ");
                                $stmt->execute([
                                    'cid' => $companyId,
                                    'bid' => $bookingId,
                                    'amount' => $total_extra,
                                    'd' => date('Y-m-d'),
                                    'desc' => 'Extra charges (late/fuel/damage)',
                                ]);
                            }

                            $pdo->commit();
                            header('Location: booking_view.php?id=' . $bookingId . '&ok=ended_pro');
                            exit;

                        } catch (Throwable $e) {
                            $pdo->rollBack();
                            $errors[] = 'DB error: ' . $e->getMessage();
                        }
                    }
                }
            }
        }
    }
}

// Reload booking again
$stmt = $pdo->prepare($sql);
$stmt->execute(['id' => $bookingId, 'company_id' => $companyId]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);

// Reload closure
$closure = null;
if ($hasClosures) {
    $stmt = $pdo->prepare("SELECT * FROM booking_closures WHERE booking_id = :bid AND company_id = :cid LIMIT 1");
    $stmt->execute(['bid' => $bookingId, 'cid' => $companyId]);
    $closure = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Drivers
$sqlDrivers = "
    SELECT bd.role, d.*
    FROM booking_drivers bd
    JOIN drivers d ON d.id = bd.driver_id
    WHERE bd.booking_id = :booking_id
";
$stmt = $pdo->prepare($sqlDrivers);
$stmt->execute(['booking_id' => $bookingId]);
$driversRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$principalDriver = null;
$additionalDrivers = [];
foreach ($driversRows as $row) {
    if (($row['role'] ?? '') === 'principal') {
        $principalDriver = $row;
    } else {
        $additionalDrivers[] = $row;
    }
}
$additionalDriver = $additionalDrivers[0] ?? null;

// success flags
if (isset($_GET['ok']) && $_GET['ok'] === 'started') $success = 'Rental started successfully.';
if (isset($_GET['ok']) && $_GET['ok'] === 'ended_pro') $success = 'Rental closed successfully (extras saved).';

// KM driven
$kmDriven = null;
if (($booking['start_mileage'] ?? null) !== null && ($booking['end_mileage'] ?? null) !== null) {
    $kmDriven = (int)$booking['end_mileage'] - (int)$booking['start_mileage'];
    if ($kmDriven < 0) $kmDriven = null;
}

// totals
$baseTotal = (float)($booking['total_price'] ?? 0);
$totalExtra = $closure ? (float)($closure['total_extra'] ?? 0) : 0.0;
$finalTotal = $closure ? (float)($closure['final_total'] ?? ($baseTotal + $totalExtra)) : ($baseTotal);
$plannedEnd = $booking['end_datetime'] ?? '';
$actualReturnDefault = date('Y-m-d\TH:i', time()); // for datetime-local

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-md-10 p-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h5 class="mb-1">Booking #<?= htmlspecialchars($booking['reference'] ?? '') ?></h5>
            <div class="small text-muted">Created at: <?= htmlspecialchars($booking['created_at'] ?? '') ?></div>
        </div>
        <div class="text-end">
            <?= booking_status_badge($booking['status'] ?? '') ?><br>
            <a href="bookings.php" class="btn btn-sm btn-outline-secondary mt-2">← Back to list</a>
            <a href="contract_generate.php?booking_id=<?= (int)$booking['id'] ?>" class="btn btn-sm btn-dark mt-2">
                Generate Contract
            </a>

            <?php if (($booking['status'] ?? '') === 'yet_to_start'): ?>
                <button class="btn btn-sm btn-primary mt-2" data-bs-toggle="modal" data-bs-target="#startRentalModal">
                    Start Rental
                </button>
            <?php elseif (($booking['status'] ?? '') === 'ongoing'): ?>
                <button class="btn btn-sm btn-success mt-2" data-bs-toggle="modal" data-bs-target="#endRentalProModal">
                    End Rental (Pro)
                </button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <div class="fw-semibold mb-1">Please fix the following:</div>
            <ul class="mb-0">
                <?php foreach ($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="row g-3">

        <!-- VEHICLE -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="card-title mb-2">Vehicle</h6>
                    <hr class="mt-1 mb-2">

                    <?php if (!empty($booking['brand'])): ?>
                        <p class="mb-1">
                            <strong><?= htmlspecialchars(($booking['brand'] ?? '').' '.($booking['model'] ?? '')) ?></strong>
                        </p>
                        <p class="mb-1 small text-muted">
                            Plate: <?= htmlspecialchars($booking['plate_number'] ?? '') ?>
                            <?php if (!empty($booking['color'])): ?>
                                – Color: <?= htmlspecialchars($booking['color']) ?>
                            <?php endif; ?>
                        </p>
                        <p class="mb-0 small text-muted">
                            Vehicle status: <strong><?= htmlspecialchars($booking['vehicle_status'] ?? '—') ?></strong>
                            <?php if (($booking['vehicle_mileage_current'] ?? null) !== null): ?>
                                • Current KM: <strong><?= (int)$booking['vehicle_mileage_current'] ?></strong>
                            <?php endif; ?>
                        </p>
                    <?php else: ?>
                        <p class="mb-0 text-muted">Vehicle not found (maybe deleted).</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- DRIVERS -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="card-title mb-2">Drivers</h6>
                    <hr class="mt-1 mb-2">

                    <?php
                    $d1name = $principalDriver ? trim(($principalDriver['first_name'] ?? '').' '.($principalDriver['last_name'] ?? '')) : '';
                    $d2name = $additionalDriver ? trim(($additionalDriver['first_name'] ?? '').' '.($additionalDriver['last_name'] ?? '')) : '';
                    ?>

                    <p class="mb-1">
                        <strong>Driver 1 (Principal):</strong><br>
                        <?= $d1name ? htmlspecialchars($d1name) : '<span class="text-muted">—</span>' ?>
                    </p>

                    <p class="mb-0">
                        <strong>Driver 2 (Additional):</strong><br>
                        <?= $d2name ? htmlspecialchars($d2name) : '<span class="text-muted">—</span>' ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- RENTAL DETAILS -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="card-title mb-2">Rental details</h6>
                    <hr class="mt-1 mb-2">

                    <p class="mb-1"><strong>Pickup:</strong>
                        <?= !empty($booking['pickup_name']) ? htmlspecialchars($booking['pickup_name']) : '<span class="text-muted">—</span>' ?>
                    </p>
                    <p class="mb-1"><strong>Dropoff:</strong>
                        <?= !empty($booking['dropoff_name']) ? htmlspecialchars($booking['dropoff_name']) : '<span class="text-muted">—</span>' ?>
                    </p>
                    <p class="mb-1"><strong>Start:</strong>
                        <?= !empty($booking['start_datetime']) ? htmlspecialchars($booking['start_datetime']) : '<span class="text-muted">—</span>' ?>
                    </p>
                    <p class="mb-0"><strong>Planned end:</strong>
                        <?= !empty($booking['end_datetime']) ? htmlspecialchars($booking['end_datetime']) : '<span class="text-muted">—</span>' ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- PRICING -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="card-title mb-2">Pricing</h6>
                    <hr class="mt-1 mb-2">

                    <div class="row">
                        <div class="col-sm-6">
                            <p class="mb-1"><strong>Daily price:</strong> <?= number_format((float)($booking['daily_price'] ?? 0), 2) ?> MAD</p>
                            <p class="mb-1"><strong>Total days:</strong> <?= (int)($booking['total_days'] ?? 0) ?></p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-1"><strong>Base total:</strong> <?= number_format($baseTotal, 2) ?> MAD</p>
                            <?php if ($closure): ?>
                                <p class="mb-1"><strong>Extras:</strong> <?= number_format($totalExtra, 2) ?> MAD</p>
                                <p class="mb-0"><strong>Final total:</strong> <span class="fw-bold"><?= number_format($finalTotal, 2) ?> MAD</span></p>
                            <?php else: ?>
                                <p class="mb-0 small text-muted">No closure extras recorded yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <p class="mb-0 small text-muted mt-2">
                        Payment: <?= htmlspecialchars(strtoupper((string)($booking['payment_method'] ?? 'cash'))) ?> —
                        Paid: <?= number_format((float)($booking['paid_amount'] ?? 0), 2) ?> MAD —
                        Status: <?= htmlspecialchars($booking['payment_status'] ?? 'unpaid') ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- FUEL & MILEAGE -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="card-title mb-2">Fuel & Mileage</h6>
                    <hr class="mt-1 mb-2">

                    <div class="row">
                        <div class="col-sm-6">
                            <p class="mb-1"><strong>Start fuel:</strong> <?= htmlspecialchars(fuel_label($booking['start_fuel_level'] ?? '')) ?></p>
                            <p class="mb-1"><strong>End fuel:</strong> <?= htmlspecialchars(fuel_label($booking['end_fuel_level'] ?? '')) ?></p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-1"><strong>Start mileage:</strong>
                                <?= ($booking['start_mileage'] ?? null) !== null ? (int)$booking['start_mileage'].' km' : '<span class="text-muted">—</span>' ?>
                            </p>
                            <p class="mb-1"><strong>End mileage:</strong>
                                <?= ($booking['end_mileage'] ?? null) !== null ? (int)$booking['end_mileage'].' km' : '<span class="text-muted">—</span>' ?>
                            </p>
                            <p class="mb-0"><strong>KM driven:</strong>
                                <?= $kmDriven !== null ? '<span class="fw-bold">'.(int)$kmDriven.' km</span>' : '<span class="text-muted">—</span>' ?>
                            </p>
                        </div>
                    </div>

                    <?php if ($closure): ?>
                        <hr>
                        <div class="small">
                            <div><strong>Actual return:</strong> <?= htmlspecialchars($closure['actual_return_datetime'] ?? '') ?></div>
                            <div><strong>Late days:</strong> <?= (int)($closure['extra_days'] ?? 0) ?></div>
                            <div><strong>Extra day charge:</strong> <?= number_format((float)($closure['extra_day_charge'] ?? 0), 2) ?> MAD</div>
                            <div><strong>Fuel charge:</strong> <?= number_format((float)($closure['fuel_charge'] ?? 0), 2) ?> MAD</div>
                            <div><strong>Damage charge:</strong> <?= number_format((float)($closure['damage_charge'] ?? 0), 2) ?> MAD</div>
                            <?php if (!empty($closure['damage_notes'])): ?>
                                <div class="mt-2"><strong>Damage notes:</strong><br><?= nl2br(htmlspecialchars($closure['damage_notes'])) ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>

        <!-- NOTES -->
        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="card-title mb-2">Notes</h6>
                    <hr class="mt-1 mb-2">
                    <?= !empty($booking['notes']) ? nl2br(htmlspecialchars($booking['notes'])) : '<span class="text-muted">—</span>' ?>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- START RENTAL MODAL -->
<div class="modal fade" id="startRentalModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-md modal-dialog-centered">
    <div class="modal-content">
      <form method="post">
        <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrfToken) ?>">
        <input type="hidden" name="action" value="start_rental">

        <div class="modal-header">
          <h5 class="modal-title">Start Rental</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
          <div class="alert alert-info py-2">
            Tip: إذا خليتي Start mileage فارغ، غادي نعتمدو على Current KM ديال السيارة.
          </div>

          <div class="mb-2">
            <label class="form-label">Start mileage (km)</label>
            <input type="number" class="form-control" name="start_mileage" min="0"
                   value="<?= htmlspecialchars(($booking['start_mileage'] ?? null) !== null ? (int)$booking['start_mileage'] : (($booking['vehicle_mileage_current'] ?? null) !== null ? (int)$booking['vehicle_mileage_current'] : '')) ?>">
          </div>

          <div class="mb-2">
            <label class="form-label">Fuel level (Start)</label>
            <?php $sf = $booking['start_fuel_level'] ?? 'full'; ?>
            <select class="form-select" name="start_fuel_level">
              <option value="empty" <?= $sf==='empty'?'selected':''; ?>>Empty</option>
              <option value="quarter" <?= $sf==='quarter'?'selected':''; ?>>1/4</option>
              <option value="half" <?= $sf==='half'?'selected':''; ?>>1/2</option>
              <option value="three_quarter" <?= $sf==='three_quarter'?'selected':''; ?>>3/4</option>
              <option value="full" <?= $sf==='full'?'selected':''; ?>>Full</option>
            </select>
          </div>

        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Start</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- END RENTAL PRO MODAL -->
<div class="modal fade" id="endRentalProModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <form method="post" id="endRentalProForm">
        <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrfToken) ?>">
        <input type="hidden" name="action" value="end_rental_pro">

        <div class="modal-header">
          <h5 class="modal-title">End Rental (Pro)</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
          <div class="alert alert-warning py-2">
            Planned end: <strong><?= htmlspecialchars($plannedEnd ?: '—') ?></strong><br>
            Any late time counts as a full extra day.
          </div>

          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Actual return date/time</label>
              <input type="datetime-local" class="form-control" name="actual_return_datetime" id="actual_return_datetime"
                     value="<?= htmlspecialchars($actualReturnDefault) ?>">
              <div class="form-text">Default is now. Change it if needed.</div>
            </div>

            <div class="col-md-6">
              <label class="form-label">End mileage (km) <span class="text-danger">*</span></label>
              <input type="number" class="form-control" name="end_mileage" id="end_mileage" min="0" required
                     value="<?= htmlspecialchars(($booking['end_mileage'] ?? null) !== null ? (int)$booking['end_mileage'] : '') ?>">
              <?php if (($booking['start_mileage'] ?? null) !== null): ?>
                <div class="form-text">Start mileage: <?= (int)$booking['start_mileage'] ?> km</div>
              <?php endif; ?>
            </div>

            <div class="col-md-6">
              <label class="form-label">Fuel level (End)</label>
              <?php $ef = $booking['end_fuel_level'] ?? 'full'; ?>
              <select class="form-select" name="end_fuel_level">
                <option value="empty" <?= $ef==='empty'?'selected':''; ?>>Empty</option>
                <option value="quarter" <?= $ef==='quarter'?'selected':''; ?>>1/4</option>
                <option value="half" <?= $ef==='half'?'selected':''; ?>>1/2</option>
                <option value="three_quarter" <?= $ef==='three_quarter'?'selected':''; ?>>3/4</option>
                <option value="full" <?= $ef==='full'?'selected':''; ?>>Full</option>
              </select>
            </div>

            <div class="col-md-6">
              <label class="form-label">Fuel charge (MAD)</label>
              <input type="number" step="0.01" min="0" class="form-control" name="fuel_charge" id="fuel_charge" value="0">
              <div class="form-text">If the customer returns with less fuel, add the fee.</div>
            </div>

            <div class="col-md-6">
              <label class="form-label">Damage charge (MAD)</label>
              <input type="number" step="0.01" min="0" class="form-control" name="damage_charge" id="damage_charge" value="0">
            </div>

            <div class="col-md-6">
              <label class="form-label">Damage notes</label>
              <textarea class="form-control" name="damage_notes" id="damage_notes" rows="3" placeholder="Scratches, dents, missing items, etc..."></textarea>
            </div>
          </div>

          <hr>

          <div class="row g-3">
            <div class="col-md-3">
              <div class="p-3 rounded border bg-light">
                <div class="small text-muted">EXTRA DAYS</div>
                <div class="fs-4 fw-bold" id="ui_extra_days">0</div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="p-3 rounded border bg-light">
                <div class="small text-muted">EXTRA DAY CHARGE</div>
                <div class="fs-5 fw-bold" id="ui_extra_day_charge">0.00</div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="p-3 rounded border bg-light">
                <div class="small text-muted">TOTAL EXTRAS</div>
                <div class="fs-5 fw-bold" id="ui_total_extras">0.00</div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="p-3 rounded border bg-light">
                <div class="small text-muted">FINAL TOTAL</div>
                <div class="fs-5 fw-bold" id="ui_final_total"><?= number_format($baseTotal, 2) ?></div>
              </div>
            </div>
          </div>

          <div class="small text-muted mt-2">
            Base total: <?= number_format($baseTotal, 2) ?> MAD • Daily price: <?= number_format((float)($booking['daily_price'] ?? 0), 2) ?> MAD
          </div>

        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success">Close Rental & Save Extras</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
(function(){
  const plannedEndStr = <?= json_encode($plannedEnd ?: '') ?>;
  const dailyPrice = Number(<?= json_encode((float)($booking['daily_price'] ?? 0)) ?>);
  const baseTotal = Number(<?= json_encode((float)$baseTotal) ?>);

  const actualEl = document.getElementById('actual_return_datetime');
  const fuelEl = document.getElementById('fuel_charge');
  const dmgEl = document.getElementById('damage_charge');

  const uiExtraDays = document.getElementById('ui_extra_days');
  const uiExtraDayCharge = document.getElementById('ui_extra_day_charge');
  const uiTotalExtras = document.getElementById('ui_total_extras');
  const uiFinalTotal = document.getElementById('ui_final_total');

  function parseDTLocal(v){
    if(!v) return null;
    const d = new Date(v);
    return isNaN(d.getTime()) ? null : d;
  }

  function parseMySQL(v){
    if(!v) return null;
    // "YYYY-MM-DD HH:MM:SS" -> Date
    const s = v.replace(' ', 'T');
    const d = new Date(s);
    return isNaN(d.getTime()) ? null : d;
  }

  function calcExtraDays(plannedEnd, actualReturn){
    if(!plannedEnd || !actualReturn) return 0;
    const p = plannedEnd.getTime();
    const a = actualReturn.getTime();
    if(a <= p) return 0;
    const diff = a - p;
    const days = Math.ceil(diff / (1000*60*60*24));
    return Math.max(1, days);
  }

  function money(n){
    return Number(n || 0).toFixed(2);
  }

  function recalc(){
    const planned = parseMySQL(plannedEndStr);
    const actual = parseDTLocal(actualEl.value);

    const extraDays = calcExtraDays(planned, actual);
    const extraDayCharge = extraDays > 0 ? (extraDays * dailyPrice) : 0;

    const fuelCharge = Math.max(0, Number(fuelEl.value || 0));
    const dmgCharge  = Math.max(0, Number(dmgEl.value || 0));

    const totalExtras = extraDayCharge + fuelCharge + dmgCharge;
    const finalTotal = baseTotal + totalExtras;

    uiExtraDays.textContent = String(extraDays);
    uiExtraDayCharge.textContent = money(extraDayCharge);
    uiTotalExtras.textContent = money(totalExtras);
    uiFinalTotal.textContent = money(finalTotal);
  }

  ['change','keyup'].forEach(evt=>{
    actualEl && actualEl.addEventListener(evt, recalc);
    fuelEl && fuelEl.addEventListener(evt, recalc);
    dmgEl && dmgEl.addEventListener(evt, recalc);
  });

  recalc();
})();
</script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
