<?php
// public/bookings.php - ULTRA Pro UX + All Original Features (CSS/JS enhanced)

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$page_title = 'Bookings – Car Rental SaaS';

$companyId = current_company_id();
if (!$companyId) {
    die('Company ID not found in session.');
}

/**
 * Fallback for e() if not defined
 */
if (!function_exists('e')) {
    function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

/**
 * Badges
 */
function booking_status_badge($status): string
{
    $badgeClass = 'bg-secondary';
    $label = (string)$status;

    switch ($status) {
        case 'yet_to_start':
            $badgeClass = 'bg-warning text-dark';
            $label = 'YET_TO_START';
            break;
        case 'ongoing':
            $badgeClass = 'bg-primary';
            $label = 'ONGOING';
            break;
        case 'completed':
            $badgeClass = 'bg-success';
            $label = 'COMPLETED';
            break;
        case 'cancelled':
            $badgeClass = 'bg-dark';
            $label = 'CANCELLED';
            break;
    }
    return '<span class="badge rounded-pill '.$badgeClass.' fs-7">'.e($label).'</span>';
}

function payment_badge($status): string
{
    $badgeClass = 'bg-danger';
    $label = strtoupper((string)$status);

    switch ((string)$status) {
        case 'paid':
            $badgeClass = 'bg-success';
            break;
        case 'partial':
            $badgeClass = 'bg-warning text-dark';
            break;
        case 'unpaid':
        default:
            $badgeClass = 'bg-danger';
            break;
    }
    return '<span class="badge rounded-pill '.$badgeClass.' fs-7">'.e($label).'</span>';
}

function urgency_badge(bool $overdue, bool $dueSoon): string
{
    if ($overdue) {
        return '<span class="badge rounded-pill bg-danger fs-7"><i class="bi bi-exclamation-triangle-fill me-1"></i>OVERDUE</span>';
    }
    if ($dueSoon) {
        return '<span class="badge rounded-pill bg-warning text-dark fs-7"><i class="bi bi-alarm me-1"></i>DUE SOON</span>';
    }
    return '';
}

/**
 * Filters (GET)
 */
$q = trim((string)($_GET['q'] ?? ''));
$statusFilter  = (string)($_GET['status'] ?? '');
$payFilter     = (string)($_GET['payment'] ?? '');
$export        = (string)($_GET['export'] ?? '');

$allowedStatus = ['yet_to_start','ongoing','completed','cancelled'];
$allowedPay    = ['paid','partial','unpaid'];

if ($statusFilter && !in_array($statusFilter, $allowedStatus, true)) $statusFilter = '';
if ($payFilter && !in_array($payFilter, $allowedPay, true)) $payFilter = '';

/**
 * Pagination
 */
$perPage = (int)($_GET['per_page'] ?? 20);
if (!in_array($perPage, [10,20,30,50,100], true)) $perPage = 20;

$page = (int)($_GET['page'] ?? 1);
if ($page < 1) $page = 1;
$offset = ($page - 1) * $perPage;

$nowSql = date('Y-m-d H:i:s');

/**
 * Build WHERE
 */
$where = " WHERE b.company_id = :company_id ";
$params = ['company_id' => $companyId];

if ($q !== '') {
    $where .= " AND (
        b.reference LIKE :q
        OR v.plate_number LIKE :q
        OR CONCAT(COALESCE(v.brand,''),' ',COALESCE(v.model,'')) LIKE :q
        OR COALESCE(p1.name,'') LIKE :q
        OR COALESCE(p2.name,'') LIKE :q
        OR CONCAT(COALESCE(d1.first_name,''),' ',COALESCE(d1.last_name,'')) LIKE :q
        OR COALESCE(d1.phone,'') LIKE :q
    )";
    $params['q'] = "%{$q}%";
}

if ($statusFilter !== '') {
    $where .= " AND b.status = :st ";
    $params['st'] = $statusFilter;
}

if ($payFilter !== '') {
    $where .= " AND COALESCE(b.payment_status,'unpaid') = :ps ";
    $params['ps'] = $payFilter;
}

/**
 * COUNT
 */
$countSql = "
  SELECT COUNT(*)
  FROM bookings b
  LEFT JOIN vehicles v ON v.id = b.vehicle_id
  LEFT JOIN places p1 ON p1.id = b.pickup_place_id
  LEFT JOIN places p2 ON p2.id = b.dropoff_place_id
  LEFT JOIN booking_drivers bd1 ON bd1.booking_id = b.id AND bd1.role = 'principal'
  LEFT JOIN drivers d1 ON d1.id = bd1.driver_id
  $where
";
$stCount = $pdo->prepare($countSql);
$stCount->execute($params);
$totalRows = (int)$stCount->fetchColumn();
$totalPages = max(1, (int)ceil($totalRows / $perPage));
if ($page > $totalPages) { $page = $totalPages; $offset = ($page - 1) * $perPage; }

/**
 * SELECT
 */
$selectSql = "
    SELECT 
        b.*,
        v.brand, v.model, v.plate_number,
        p1.name AS pickup_name,
        p2.name AS dropoff_name,
        d1.first_name AS driver_first_name,
        d1.last_name  AS driver_last_name,
        d1.phone      AS driver_phone
    FROM bookings b
    LEFT JOIN vehicles v ON v.id = b.vehicle_id
    LEFT JOIN places p1 ON p1.id = b.pickup_place_id
    LEFT JOIN places p2 ON p2.id = b.dropoff_place_id
    LEFT JOIN booking_drivers bd1 
        ON bd1.booking_id = b.id AND bd1.role = 'principal'
    LEFT JOIN drivers d1 
        ON d1.id = bd1.driver_id
    $where
    ORDER BY b.id DESC
";

/**
 * CSV Export
 */
if ($export === 'csv') {
    $st = $pdo->prepare($selectSql);
    $st->execute($params);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="bookings_export.csv"');
    echo "\xEF\xBB\xBF"; // UTF-8 BOM

    $out = fopen('php://output', 'w');
    fputcsv($out, [
        'ID','Reference','Status','Payment',
        'Vehicle','Plate',
        'Start','End',
        'Pickup','Dropoff',
        'Driver','Driver Phone',
        'Total','Paid','Remaining'
    ]);

    foreach ($rows as $b) {
        $vehicle = trim(($b['brand'] ?? '').' '.($b['model'] ?? ''));
        $plate   = (string)($b['plate_number'] ?? '');
        $driver  = trim(($b['driver_first_name'] ?? '').' '.($b['driver_last_name'] ?? ''));
        $total   = (float)($b['total_price'] ?? 0);
        $paid    = (float)($b['paid_amount'] ?? 0);
        $remain  = max(0, $total - $paid);

        fputcsv($out, [
            (int)$b['id'],
            (string)($b['reference'] ?? ''),
            (string)($b['status'] ?? ''),
            (string)($b['payment_status'] ?? 'unpaid'),
            $vehicle,
            $plate,
            (string)($b['start_datetime'] ?? ''),
            (string)($b['end_datetime'] ?? ''),
            (string)($b['pickup_name'] ?? ''),
            (string)($b['dropoff_name'] ?? ''),
            $driver,
            (string)($b['driver_phone'] ?? ''),
            number_format($total, 2, '.', ''),
            number_format($paid, 2, '.', ''),
            number_format($remain, 2, '.', ''),
        ]);
    }
    fclose($out);
    exit;
}

// Paged query
$selectSqlPaged = $selectSql . " LIMIT :limit OFFSET :offset";
$st = $pdo->prepare($selectSqlPaged);
foreach ($params as $k => $v) {
    $st->bindValue(':'.$k, $v);
}
$st->bindValue(':limit', (int)$perPage, PDO::PARAM_INT);
$st->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
$st->execute();
$bookings = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

// QS helper
function qs(array $override = []): string {
    $q = array_merge($_GET, $override);
    foreach ($q as $k => $v) {
        if ($v === '' || $v === null) unset($q[$k]);
    }
    return http_build_query($q);
}

// Quick counts for chips (optional but helpful UX)
$counts = [
  'all' => $totalRows,
  'yet_to_start' => 0,
  'ongoing' => 0,
  'completed' => 0,
  'cancelled' => 0,
];
try {
  $stc = $pdo->prepare("
    SELECT status, COUNT(*) AS c
    FROM bookings
    WHERE company_id=:cid
    GROUP BY status
  ");
  $stc->execute(['cid'=>$companyId]);
  $rows = $stc->fetchAll(PDO::FETCH_ASSOC) ?: [];
  foreach ($rows as $r) {
    $s = (string)($r['status'] ?? '');
    if (isset($counts[$s])) $counts[$s] = (int)($r['c'] ?? 0);
  }
} catch (Throwable $e) {}

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<link rel="stylesheet" href="assets/css/bookings.css?v=<?= time() ?>">

<main class="col-12 col-lg-10 p-4 ultra-bookings">

  <!-- Header -->
  <div class="ub-topbar mb-3">
    <div>
      <div class="ub-title">Bookings</div>
      <div class="ub-sub">
        <span class="me-2"><i class="bi bi-list-check me-1"></i><?= (int)$totalRows ?> total</span>
        <span class="text-muted">• Page <?= (int)$page ?> / <?= (int)$totalPages ?></span>
      </div>
    </div>

    <div class="ub-actions">
      <a href="booking_create.php" class="btn btn-primary rounded-pill px-4">
        <i class="bi bi-plus-circle me-2"></i>New Booking
      </a>
      <a href="bookings.php?<?= e(qs(['export'=>'csv'])) ?>" class="btn btn-outline-secondary rounded-pill">
        <i class="bi bi-download me-2"></i>Export CSV
      </a>
    </div>
  </div>

  <!-- Sticky filters -->
  <div class="ub-sticky">
    <div class="card ub-filters-card mb-3">
      <div class="card-body">

        <!-- Quick status chips -->
        <div class="ub-chips mb-3">
          <?php
            $chip = function(string $label, string $key, int $count) use ($statusFilter) {
              $active = ($key === 'all' && $statusFilter === '') || ($key !== 'all' && $statusFilter === $key);
              $href = 'bookings.php?'.e(qs(['status' => ($key === 'all' ? '' : $key), 'page' => 1]));
              $cls = $active ? 'ub-chip is-active' : 'ub-chip';
              echo '<a class="'.$cls.'" href="'.$href.'">'.e($label).'<span>'.(int)$count.'</span></a>';
            };
            $chip('All','all',$counts['all']);
            $chip('Yet to start','yet_to_start',$counts['yet_to_start']);
            $chip('Ongoing','ongoing',$counts['ongoing']);
            $chip('Completed','completed',$counts['completed']);
            $chip('Cancelled','cancelled',$counts['cancelled']);
          ?>
        </div>

        <form method="get" class="row g-3 align-items-end ub-filter-form" id="filtersForm">
          <div class="col-12 col-md-6 col-lg-4">
            <label class="form-label">Search</label>
            <div class="position-relative">
              <i class="bi bi-search ub-ico"></i>
              <input id="qInput" type="text" name="q" class="form-control ps-5"
                     placeholder="Reference, plate, driver, places..."
                     value="<?= e($q) ?>" autocomplete="off">
            </div>
          </div>

          <div class="col-6 col-md-3 col-lg-2">
            <label class="form-label">Status</label>
            <select name="status" class="form-select" id="statusSelect">
              <option value="">All</option>
              <?php foreach (['yet_to_start'=>'Yet to start','ongoing'=>'Ongoing','completed'=>'Completed','cancelled'=>'Cancelled'] as $k=>$v): ?>
                <option value="<?= e($k) ?>" <?= $statusFilter===$k?'selected':'' ?>><?= e($v) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-6 col-md-3 col-lg-2">
            <label class="form-label">Payment</label>
            <select name="payment" class="form-select" id="paymentSelect">
              <option value="">All</option>
              <?php foreach (['unpaid'=>'Unpaid','partial'=>'Partial','paid'=>'Paid'] as $k=>$v): ?>
                <option value="<?= e($k) ?>" <?= $payFilter===$k?'selected':'' ?>><?= e($v) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-6 col-md-3 col-lg-2">
            <label class="form-label">Per page</label>
            <select name="per_page" class="form-select" id="perPageSelect">
              <?php foreach ([10,20,30,50,100] as $n): ?>
                <option value="<?= (int)$n ?>" <?= $perPage===$n?'selected':'' ?>><?= (int)$n ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-12 col-md-6 col-lg-2 d-grid">
            <button type="submit" class="btn btn-primary" id="applyBtn">
              <i class="bi bi-funnel me-2"></i>Apply
            </button>
          </div>

          <div class="col-12">
            <div class="ub-filter-footer">
              <a class="btn btn-sm btn-outline-secondary" href="bookings.php">
                <i class="bi bi-x-circle me-1"></i>Clear filters
              </a>

              <div class="ub-hints">
                <span class="badge text-bg-light"><i class="bi bi-lightning-charge me-1"></i>Tip: type then wait 600ms to auto-search</span>
                <span class="badge text-bg-light"><i class="bi bi-mouse me-1"></i>Tip: click any row to open “View”</span>
              </div>
            </div>
          </div>

        </form>
      </div>
    </div>
  </div>

  <!-- Desktop Table -->
  <div class="card ub-table-card d-none d-lg-block">
    <div class="table-responsive">
      <table class="table table-hover mb-0 ub-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Reference</th>
            <th>Vehicle</th>
            <th>Dates</th>
            <th>Pickup / Dropoff</th>
            <th>Driver</th>
            <th>Billing</th>
            <th>Status</th>
            <th class="text-end">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!$bookings): ?>
            <tr>
              <td colspan="9" class="text-center py-5 text-muted">
                <i class="bi bi-inbox fs-1 d-block mb-3"></i>
                No bookings found.
              </td>
            </tr>
          <?php else: ?>
            <?php foreach ($bookings as $b): ?>
              <?php
                $bid = (int)$b['id'];
                $vehicleLabel = trim(($b['brand'] ?? '').' '.($b['model'] ?? ''));
                $plate = (string)($b['plate_number'] ?? '');
                $driverName = trim(($b['driver_first_name'] ?? '').' '.($b['driver_last_name'] ?? ''));
                $driverPhone = (string)($b['driver_phone'] ?? '');

                $total = (float)($b['total_price'] ?? 0);
                $paid  = (float)($b['paid_amount'] ?? 0);
                $remaining = max(0, $total - $paid);

                $startTs = !empty($b['start_datetime']) ? strtotime((string)$b['start_datetime']) : 0;
                $endTs   = !empty($b['end_datetime']) ? strtotime((string)$b['end_datetime']) : 0;
                $nowTs   = time();

                $status = (string)($b['status'] ?? '');
                $isActive = in_array($status, ['ongoing','yet_to_start'], true);
                $overdue = $isActive && $endTs > 0 && ($endTs < $nowTs);
                $dueSoon = $isActive && $endTs > 0 && ($endTs >= $nowTs) && ($endTs <= ($nowTs + 86400));

                $days = (int)($b['total_days'] ?? 0);
                if ($days <= 0 && $startTs && $endTs && $endTs > $startTs) {
                    $days = max(1, (int)ceil(($endTs - $startTs) / 86400));
                }

                $startTxt = $startTs ? date('d/m/Y H:i', $startTs) : '—';
                $endTxt   = $endTs ? date('d/m/Y H:i', $endTs) : '—';

                $ref = (string)($b['reference'] ?? '');
                $rowUrl = "booking_view.php?id=".$bid;
              ?>
              <tr class="ub-row <?= $overdue ? 'is-overdue' : ($dueSoon ? 'is-soon' : '') ?>"
                  data-href="<?= e($rowUrl) ?>"
                  data-ref="<?= e($ref) ?>">
                <td class="fw-bold">#<?= $bid ?></td>

                <td>
                  <div class="d-flex align-items-center gap-2">
                    <span class="ub-ref"><?= e($ref) ?></span>
                    <?php if ($ref !== ''): ?>
                      <button class="btn btn-sm btn-light ub-copy" type="button" data-copy="<?= e($ref) ?>" title="Copy reference">
                        <i class="bi bi-clipboard"></i>
                      </button>
                    <?php endif; ?>
                  </div>
                  <?php if ($overdue): ?>
                    <div class="small text-danger">Late return</div>
                  <?php endif; ?>
                </td>

                <td>
                  <div class="fw-semibold"><?= e($vehicleLabel) ?: '—' ?></div>
                  <div class="small text-muted"><?= e($plate) ?></div>
                </td>

                <td class="small">
                  <div><span class="text-muted">Start:</span> <?= e($startTxt) ?></div>
                  <div><span class="text-muted">End:</span> <?= e($endTxt) ?></div>
                  <div class="mt-1">
                    <span class="badge bg-light text-dark fs-7">
                      <i class="bi bi-hourglass-split me-1"></i><?= (int)$days ?> day(s)
                    </span>
                  </div>
                </td>

                <td class="small">
                  <div><span class="text-muted">P:</span> <?= e((string)($b['pickup_name'] ?? '—')) ?></div>
                  <div><span class="text-muted">D:</span> <?= e((string)($b['dropoff_name'] ?? '—')) ?></div>
                </td>

                <td>
                  <div class="fw-semibold"><?= e($driverName) ?: '—' ?></div>
                  <div class="small text-muted"><?= e($driverPhone) ?></div>
                </td>

                <td class="small">
                  <div><span class="text-muted">Total:</span> <?= number_format($total, 2) ?> MAD</div>
                  <div>
                    <span class="text-muted">Paid:</span> <?= number_format($paid, 2) ?>
                    <span class="text-muted">• Remain:</span>
                    <span class="<?= $remaining > 0 ? 'text-danger fw-semibold' : 'text-success fw-semibold' ?>">
                      <?= number_format($remaining, 2) ?> MAD
                    </span>
                  </div>
                  <div class="mt-2 d-flex flex-wrap gap-1">
                    <?= payment_badge($b['payment_status'] ?? 'unpaid') ?>
                    <?= urgency_badge($overdue, $dueSoon) ?>
                  </div>
                </td>

                <td>
                  <div class="d-flex flex-wrap gap-1">
                    <?= booking_status_badge($status) ?>
                    <?= urgency_badge($overdue, $dueSoon) ?>
                  </div>
                </td>

                <td class="text-end">
                  <div class="dropdown">
                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown" onclick="event.stopPropagation();">
                      <i class="bi bi-three-dots"></i>
                    </button>
                    <ul class="dropdown-menu">
                      <li><a class="dropdown-item" href="booking_view.php?id=<?= $bid ?>" onclick="event.stopPropagation();"><i class="bi bi-eye me-2"></i>View</a></li>
                      <li><a class="dropdown-item" href="booking_edit.php?id=<?= $bid ?>" onclick="event.stopPropagation();"><i class="bi bi-pencil-square me-2"></i>Edit</a></li>
                      <li><a class="dropdown-item" href="booking_payment.php?id=<?= $bid ?>" onclick="event.stopPropagation();"><i class="bi bi-cash-coin me-2"></i>Update payment</a></li>
                      <li><hr class="dropdown-divider"></li>
                      <?php if ($status !== 'cancelled'): ?>
                        <li>
                          <a class="dropdown-item text-danger" href="#"
                             onclick="event.stopPropagation(); confirmAction('booking_cancel.php?id=<?= $bid ?>','Cancel booking','Do you really want to cancel booking #<?= $bid ?>?'); return false;">
                            <i class="bi bi-x-octagon me-2"></i>Cancel
                          </a>
                        </li>
                      <?php endif; ?>
                    </ul>
                  </div>
                </td>

              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Pagination (Desktop) -->
    <?php if ($totalRows > $perPage): ?>
      <div class="card-footer bg-transparent">
        <nav>
          <ul class="pagination justify-content-center mb-0">
            <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
              <a class="page-link" href="bookings.php?<?= e(qs(['page' => max(1, $page-1)])) ?>">Previous</a>
            </li>
            <?php for ($i = max(1, $page-2); $i <= min($totalPages, $page+2); $i++): ?>
              <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                <a class="page-link" href="bookings.php?<?= e(qs(['page' => $i])) ?>"><?= (int)$i ?></a>
              </li>
            <?php endfor; ?>
            <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
              <a class="page-link" href="bookings.php?<?= e(qs(['page' => min($totalPages, $page+1)])) ?>">Next</a>
            </li>
          </ul>
        </nav>
      </div>
    <?php endif; ?>
  </div>

  <!-- Mobile Cards -->
  <div class="d-lg-none">
    <?php if (!$bookings): ?>
      <div class="text-center py-5 text-muted">
        <i class="bi bi-inbox display-6 mb-3"></i>
        <div>No bookings found.</div>
      </div>
    <?php else: ?>
      <?php foreach ($bookings as $b): ?>
        <?php
          $bid = (int)$b['id'];
          $status = (string)($b['status'] ?? '');

          $vehicleLabel = trim(($b['brand'] ?? '').' '.($b['model'] ?? ''));
          $plate = (string)($b['plate_number'] ?? '');
          $driverName = trim(($b['driver_first_name'] ?? '').' '.($b['driver_last_name'] ?? ''));

          $total = (float)($b['total_price'] ?? 0);
          $paid  = (float)($b['paid_amount'] ?? 0);
          $remaining = max(0, $total - $paid);

          $startTs = !empty($b['start_datetime']) ? strtotime((string)$b['start_datetime']) : 0;
          $endTs   = !empty($b['end_datetime']) ? strtotime((string)$b['end_datetime']) : 0;
          $nowTs   = time();
          $isActive = in_array($status, ['ongoing','yet_to_start'], true);
          $overdue = $isActive && $endTs > 0 && ($endTs < $nowTs);
          $dueSoon = $isActive && $endTs > 0 && ($endTs >= $nowTs) && ($endTs <= ($nowTs + 86400));

          $startTxt = $startTs ? date('d/m/Y H:i', $startTs) : '—';
          $endTxt   = $endTs ? date('d/m/Y H:i', $endTs) : '—';
          $ref = (string)($b['reference'] ?? '');
        ?>
        <a class="card ub-mobile-card mb-3 <?= $overdue ? 'is-overdue' : ($dueSoon ? 'is-soon' : '') ?>"
           href="booking_view.php?id=<?= $bid ?>">
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-start mb-3">
              <div>
                <div class="fw-bold fs-5">#<?= $bid ?></div>
                <div class="text-muted small"><?= e($ref) ?></div>
              </div>
              <div class="d-flex flex-column gap-1 align-items-end">
                <?= booking_status_badge($status) ?>
                <?= payment_badge($b['payment_status'] ?? 'unpaid') ?>
                <?= urgency_badge($overdue, $dueSoon) ?>
              </div>
            </div>

            <div class="small mb-3">
              <div class="fw-semibold"><?= e($vehicleLabel) ?: '—' ?> • <?= e($plate) ?></div>
              <div class="text-muted">Driver: <?= e($driverName) ?: '—' ?></div>
            </div>

            <div class="row g-2 small text-muted mb-3">
              <div class="col-6">
                <div>Start</div>
                <div class="fw-semibold"><?= e($startTxt) ?></div>
              </div>
              <div class="col-6">
                <div>End</div>
                <div class="fw-semibold"><?= e($endTxt) ?></div>
              </div>
              <div class="col-12">
                <div>Pickup: <?= e((string)($b['pickup_name'] ?? '—')) ?></div>
                <div>Dropoff: <?= e((string)($b['dropoff_name'] ?? '—')) ?></div>
              </div>
            </div>

            <div class="border-top pt-3">
              <div class="d-flex justify-content-between mb-2">
                <span>Total</span>
                <span class="fw-bold"><?= number_format($total, 2) ?> MAD</span>
              </div>
              <div class="d-flex justify-content-between mb-3">
                <span>Remaining</span>
                <span class="fw-bold <?= $remaining > 0 ? 'text-danger' : 'text-success' ?>">
                  <?= number_format($remaining, 2) ?> MAD
                </span>
              </div>

              <div class="d-grid gap-2 d-md-flex">
                <span class="btn btn-outline-primary btn-sm">View</span>
                <a href="booking_payment.php?id=<?= $bid ?>" class="btn btn-outline-success btn-sm" onclick="event.stopPropagation();">Payment</a>
                <a href="booking_edit.php?id=<?= $bid ?>" class="btn btn-outline-secondary btn-sm" onclick="event.stopPropagation();">Edit</a>
                <?php if ($status !== 'cancelled'): ?>
                  <a href="#" class="btn btn-outline-danger btn-sm"
                     onclick="event.preventDefault(); event.stopPropagation();
                              confirmAction('booking_cancel.php?id=<?= $bid ?>','Cancel booking','Do you really want to cancel booking #<?= $bid ?>?');">
                    Cancel
                  </a>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </a>
      <?php endforeach; ?>
    <?php endif; ?>

    <!-- Mobile Pagination -->
    <?php if ($totalRows > $perPage): ?>
      <div class="d-flex justify-content-between align-items-center mt-4">
        <a href="bookings.php?<?= e(qs(['page'=>max(1,$page-1)])) ?>" class="btn btn-outline-secondary <?= $page<=1?'disabled':'' ?>">
          Prev
        </a>
        <span class="text-muted">Page <?= (int)$page ?> / <?= (int)$totalPages ?></span>
        <a href="bookings.php?<?= e(qs(['page'=>min($totalPages,$page+1)])) ?>" class="btn btn-outline-secondary <?= $page>=$totalPages?'disabled':'' ?>">
          Next
        </a>
      </div>
    <?php endif; ?>
  </div>

</main>

<!-- Confirm Modal (Bootstrap) -->
<div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title" id="confirmTitle">Confirm</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="confirmBody">Are you sure?</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
        <a href="#" class="btn btn-danger" id="confirmGo">Yes, continue</a>
      </div>
    </div>
  </div>
</div>

<!-- Toast -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
  <div id="ubToast" class="toast align-items-center text-bg-dark border-0" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body" id="ubToastBody">Copied</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  </div>
</div>

<!-- Loading overlay -->
<div class="ub-loading" id="ubLoading" aria-hidden="true">
  <div class="ub-loading__card">
    <div class="spinner-border" role="status" aria-hidden="true"></div>
    <div class="ms-3">
      <div class="fw-semibold">Loading…</div>
      <div class="text-muted small">Applying filters</div>
    </div>
  </div>
</div>

<script src="assets/js/bookings.js?v=<?= time() ?>"></script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
