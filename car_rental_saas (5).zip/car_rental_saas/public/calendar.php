<?php
// public/calendar.php
require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
  redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$page_title = 'Calendar – Car Rental SaaS';

$companyId = current_company_id();
if (!$companyId) {
  die('Company ID not found in session.');
}

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-md-10 p-4">
  <div class="topbar d-flex justify-content-between align-items-center px-3 py-2 mb-3">
    <div>
      <h5 class="mb-0">Bookings Calendar</h5>
      <div class="small text-muted">Month / Week / Day • Drag & drop • Status colors</div>
    </div>
    <div class="d-flex gap-2">
      <button class="btn btn-outline-secondary btn-sm" id="btnToday">Today</button>
      <button class="btn btn-outline-secondary btn-sm" id="btnMonth">Month</button>
      <button class="btn btn-outline-secondary btn-sm" id="btnWeek">Week</button>
      <button class="btn btn-outline-secondary btn-sm" id="btnDay">Day</button>
    </div>
  </div>

  <div class="card shadow-sm">
    <div class="card-body">
      <div id="calendar"></div>
    </div>
  </div>
</div>

<!-- FullCalendar (CDN) -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.css">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"></script>

<style>
  /* Polish look */
  #calendar { min-height: 720px; }
  .fc .fc-toolbar-title { font-size: 18px; font-weight: 700; }
  .fc .fc-button { border-radius: 10px; }
  .fc .fc-daygrid-event { border-radius: 10px; padding: 2px 6px; }
  .fc .fc-timegrid-event { border-radius: 12px; }
  .fc .fc-event-title { font-weight: 700; }
  .fc .fc-event-time { font-weight: 600; opacity: .9; }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const calEl = document.getElementById('calendar');

  const calendar = new FullCalendar.Calendar(calEl, {
    initialView: 'dayGridMonth',
    height: 'auto',
    nowIndicator: true,
    firstDay: 1, // Monday
    selectable: true,
    editable: true, // drag/drop enabled
    eventDisplay: 'block',
    dayMaxEvents: true,

    headerToolbar: {
      left: 'prev,next',
      center: 'title',
      right: '' // we use custom buttons
    },

    events: {
      url: 'ajax_calendar_events.php',
      method: 'GET',
      failure: function() {
        alert('Failed to load calendar events.');
      }
    },

    eventClick: function(info) {
      // open booking view
      const id = info.event.extendedProps.booking_id;
      if (id) window.location.href = 'booking_view.php?id=' + id;
    },

    eventDrop: async function(info) {
      // when user drags booking to different day
      // we will call a small update endpoint (optional)
      // For now: revert (safe) unless you want update logic
      info.revert();
      alert('Drag/drop is enabled visually. If you want to save changes, tell me and I will add the update endpoint.');
    },

    eventResize: function(info) {
      info.revert();
      alert('Resize is enabled visually. If you want to save changes, tell me and I will add the update endpoint.');
    },

    eventDidMount: function(arg){
      // Tooltip (simple)
      const p = arg.event.extendedProps;
      const tip = [
        `Ref: ${p.reference || ''}`,
        `Car: ${p.vehicle || ''}`,
        `Client: ${p.client || ''}`,
        `Status: ${p.status || ''}`,
        `Total: ${p.total_price || ''} MAD`
      ].filter(Boolean).join('\n');
      arg.el.title = tip;
    }
  });

  calendar.render();

  // Custom controls
  document.getElementById('btnToday').addEventListener('click', () => calendar.today());
  document.getElementById('btnMonth').addEventListener('click', () => calendar.changeView('dayGridMonth'));
  document.getElementById('btnWeek').addEventListener('click', () => calendar.changeView('timeGridWeek'));
  document.getElementById('btnDay').addEventListener('click', () => calendar.changeView('timeGridDay'));
});
</script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
