<?php
// public/companies.php

require_once __DIR__ . '/../includes/auth.php';
require_super_admin();              // فقط السوبر أدمن يشوف هاد الصفحة

require_once __DIR__ . '/../config/config.php';

$page_title = 'Companies – Car Rental SaaS';

// ----- معالجة العمليات (إضافة / تعديل / تفعيل) -----

$errors = [];
$success = '';

// تفعيل / تعطيل شركة
if (isset($_GET['toggle']) && ctype_digit($_GET['toggle'])) {
    $id = (int) $_GET['toggle'];

    $stmt = $pdo->prepare("UPDATE companies SET is_active = 1 - is_active WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $success = 'Company status updated.';
}

// جلب بيانات شركة للتعديل
$edit_company = null;
if (isset($_GET['edit']) && ctype_digit($_GET['edit'])) {
    $id = (int) $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = :id LIMIT 1");
    $stmt->execute(['id' => $id]);
    $edit_company = $stmt->fetch();
}

// إضافة / تعديل عبر POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id                     = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $name                   = trim($_POST['name'] ?? '');
    $email                  = trim($_POST['email'] ?? '');
    $phone                  = trim($_POST['phone'] ?? '');
    $address                = trim($_POST['address'] ?? '');
    $tax_number             = trim($_POST['tax_number'] ?? '');
    $subscription_start_at  = trim($_POST['subscription_start_at'] ?? '');
    $subscription_end_at    = trim($_POST['subscription_end_at'] ?? '');
    $is_active              = isset($_POST['is_active']) ? 1 : 0;

    if ($name === '') {
        $errors[] = 'Le nom de la société est obligatoire.';
    }

    // صيغة التاريخ اختيارية، MySQL يقبل 'YYYY-MM-DD'
    if ($subscription_start_at !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $subscription_start_at)) {
        $errors[] = 'Date de début d\'abonnement invalide (format: YYYY-MM-DD).';
    }
    if ($subscription_end_at !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $subscription_end_at)) {
        $errors[] = 'Date de fin d\'abonnement invalide (format: YYYY-MM-DD).';
    }

    if (empty($errors)) {
        if ($id > 0) {
            // UPDATE
            $sql = "UPDATE companies SET 
                        name = :name,
                        email = :email,
                        phone = :phone,
                        address = :address,
                        tax_number = :tax_number,
                        subscription_start_at = :subscription_start_at,
                        subscription_end_at = :subscription_end_at,
                        is_active = :is_active
                    WHERE id = :id";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                'name'                  => $name,
                'email'                 => $email ?: null,
                'phone'                 => $phone ?: null,
                'address'               => $address ?: null,
                'tax_number'            => $tax_number ?: null,
                'subscription_start_at' => $subscription_start_at ?: null,
                'subscription_end_at'   => $subscription_end_at ?: null,
                'is_active'             => $is_active,
                'id'                    => $id,
            ]);

            $success = 'Company updated successfully.';
        } else {
            // INSERT
            $sql = "INSERT INTO companies 
                        (name, email, phone, address, tax_number, subscription_start_at, subscription_end_at, is_active)
                    VALUES
                        (:name, :email, :phone, :address, :tax_number, :subscription_start_at, :subscription_end_at, :is_active)";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                'name'                  => $name,
                'email'                 => $email ?: null,
                'phone'                 => $phone ?: null,
                'address'               => $address ?: null,
                'tax_number'            => $tax_number ?: null,
                'subscription_start_at' => $subscription_start_at ?: null,
                'subscription_end_at'   => $subscription_end_at ?: null,
                'is_active'             => $is_active,
            ]);

            $newCompanyId = (int)$pdo->lastInsertId();

            // إدخال إعدادات افتراضية للشركة
            $pdo->prepare("INSERT INTO company_settings (company_id) VALUES (:company_id)")
                ->execute(['company_id' => $newCompanyId]);

            $success = 'New company created successfully.';
        }

        // إعادة التوجيه باش مايتعاودش POST فـ refresh
        header('Location: companies.php?success=1');
        exit;
    }
}

// رسالة النجاح بعد redirect
if (isset($_GET['success'])) {
    $success = 'Changes saved successfully.';
}

// ----- جلب قائمة الشركات -----
$stmt = $pdo->query("SELECT * FROM companies ORDER BY id DESC");
$companies = $stmt->fetchAll();

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-md-10 p-4">

    <div class="topbar d-flex justify-content-between align-items-center px-3 py-2 mb-3">
        <h5 class="mb-0">Gestion des agences (Companies)</h5>
    </div>

    <div class="row g-3">
        <!-- Formulaire ajout / édition -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="card-title mb-3">
                        <?= $edit_company ? 'Modifier la société' : 'Ajouter une nouvelle société' ?>
                    </h6>

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger py-2">
                            <?php foreach ($errors as $err): ?>
                                <div><?= htmlspecialchars($err) ?></div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($success && empty($errors) && !isset($_GET['success'])): ?>
                        <div class="alert alert-success py-2"><?= htmlspecialchars($success) ?></div>
                    <?php endif; ?>

                    <form method="post" action="companies.php<?= $edit_company ? '?edit=' . (int)$edit_company['id'] : '' ?>">
                        <input type="hidden" name="id" value="<?= $edit_company ? (int)$edit_company['id'] : 0 ?>">

                        <div class="mb-2">
                            <label class="form-label">Nom de la société *</label>
                            <input type="text" name="name" class="form-control"
                                   value="<?= htmlspecialchars($edit_company['name'] ?? '') ?>" required>
                        </div>

                        <div class="mb-2">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control"
                                   value="<?= htmlspecialchars($edit_company['email'] ?? '') ?>">
                        </div>

                        <div class="mb-2">
                            <label class="form-label">Téléphone</label>
                            <input type="text" name="phone" class="form-control"
                                   value="<?= htmlspecialchars($edit_company['phone'] ?? '') ?>">
                        </div>

                        <div class="mb-2">
                            <label class="form-label">Adresse</label>
                            <input type="text" name="address" class="form-control"
                                   value="<?= htmlspecialchars($edit_company['address'] ?? '') ?>">
                        </div>

                        <div class="mb-2">
                            <label class="form-label">N° fiscal / ICE</label>
                            <input type="text" name="tax_number" class="form-control"
                                   value="<?= htmlspecialchars($edit_company['tax_number'] ?? '') ?>">
                        </div>

                        <div class="mb-2">
                            <label class="form-label">Début abonnement</label>
                            <input type="date" name="subscription_start_at" class="form-control"
                                   value="<?= htmlspecialchars($edit_company['subscription_start_at'] ?? '') ?>">
                        </div>

                        <div class="mb-2">
                            <label class="form-label">Fin abonnement</label>
                            <input type="date" name="subscription_end_at" class="form-control"
                                   value="<?= htmlspecialchars($edit_company['subscription_end_at'] ?? '') ?>">
                        </div>

                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="is_active" id="is_active"
                                   <?= (isset($edit_company['is_active']) ? $edit_company['is_active'] : 1) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="is_active">
                                Société active
                            </label>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">
                            <?= $edit_company ? 'Enregistrer les modifications' : 'Ajouter la société' ?>
                        </button>

                        <?php if ($edit_company): ?>
                            <a href="companies.php" class="btn btn-link w-100 mt-1">Annuler l’édition</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

        <!-- Liste des sociétés -->
        <div class="col-md-8">
            <?php if ($success && isset($_GET['success'])): ?>
                <div class="alert alert-success py-2"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>

            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="card-title mb-3">Liste des sociétés</h6>

                    <div class="table-responsive">
                        <table class="table table-sm align-middle">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nom</th>
                                <th>Contact</th>
                                <th>Abonnement</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if (!$companies): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted">Aucune société enregistrée.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($companies as $c): ?>
                                    <tr>
                                        <td><?= (int)$c['id'] ?></td>
                                        <td><?= htmlspecialchars($c['name']) ?></td>
                                        <td>
                                            <?php if ($c['email']): ?>
                                                <div class="small"><?= htmlspecialchars($c['email']) ?></div>
                                            <?php endif; ?>
                                            <?php if ($c['phone']): ?>
                                                <div class="small text-muted"><?= htmlspecialchars($c['phone']) ?></div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="small">
                                            <?php if ($c['subscription_start_at'] || $c['subscription_end_at']): ?>
                                                <?= htmlspecialchars($c['subscription_start_at'] ?? '…') ?>
                                                →
                                                <?= htmlspecialchars($c['subscription_end_at'] ?? '…') ?>
                                            <?php else: ?>
                                                <span class="text-muted">Non défini</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($c['is_active']): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="companies.php?edit=<?= (int)$c['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                Éditer
                                            </a>
                                            <a href="companies.php?toggle=<?= (int)$c['id'] ?>" class="btn btn-sm btn-outline-warning"
                                               onclick="return confirm('Changer le statut de cette société ?');">
                                                Activer / Désactiver
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>

<?php
require_once __DIR__ . '/../templates/footer.php';
