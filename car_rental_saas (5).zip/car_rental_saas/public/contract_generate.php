<?php
// public/contract_generate.php  (PRINTABLE A4 CONTRACT - 2 PAGES + 2nd DRIVER + BILINGUAL TERMS)

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$companyId = current_company_id();
if (!$companyId) {
    die('Company ID not found in session.');
}

$bookingId = 0;
if (isset($_GET['booking_id']) && ctype_digit($_GET['booking_id'])) {
    $bookingId = (int)$_GET['booking_id'];
} elseif (isset($_GET['id']) && ctype_digit($_GET['id'])) {
    $bookingId = (int)$_GET['id'];
}
if (!$bookingId) {
    die('Invalid booking ID.');
}

function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function money($val) { return number_format((float)$val, 2, '.', ''); }

// -----------------------------
// 1) COMPANY + SETTINGS (safe: cs.* to avoid missing columns errors)
// -----------------------------
$st = $pdo->prepare("
    SELECT c.*, cs.*
    FROM companies c
    LEFT JOIN company_settings cs ON cs.company_id = c.id
    WHERE c.id = :company_id
    LIMIT 1
");
$st->execute(['company_id' => $companyId]);
$company = $st->fetch();
if (!$company) die('Company not found.');

$agencyName  = !empty($company['agency_name'])  ? $company['agency_name']  : (!empty($company['name']) ? $company['name'] : 'Agency');
$agencyICE   = $company['agency_ice']   ?? '';
$agencyIF    = $company['agency_if']    ?? '';
$agencyRC    = $company['agency_rc']    ?? '';
$agencyPAT   = $company['agency_patente'] ?? '';
$agencyCNSS  = $company['agency_cnss']  ?? '';
$agencyAddr  = !empty($company['agency_address']) ? $company['agency_address'] : ($company['address'] ?? '');
$agencyCity  = $company['agency_city']  ?? '';
$agencyPhone = !empty($company['agency_phone']) ? $company['agency_phone'] : ($company['phone'] ?? '');
$agencyEmail = !empty($company['agency_email']) ? $company['agency_email'] : ($company['email'] ?? '');
$logoPath    = $company['agency_logo_path'] ?? '';
$currency    = !empty($company['currency']) ? $company['currency'] : 'MAD';

// Optional insurance settings (if you add them later in company_settings)
$insuranceLabel = $company['insurance_label'] ?? 'Responsabilité Civile / Standard';
$franchiseLabel = $company['franchise_label'] ?? '—';

// Optional contract terms (customizable in company_settings later)
$termsText = $company['contract_terms'] ?? "Le locataire déclare avoir pris connaissance des conditions générales de location, et s'engage à respecter les règles d'utilisation du véhicule.";

// -----------------------------
// 2) BOOKING + VEHICLE + PLACES
// -----------------------------
$st = $pdo->prepare("
    SELECT 
        b.*,
        v.brand, v.model, v.plate_number, v.vin, v.year, v.color, v.fuel_type,
        p1.name AS pickup_name,
        p2.name AS dropoff_name
    FROM bookings b
    LEFT JOIN vehicles v ON v.id = b.vehicle_id
    LEFT JOIN places  p1 ON p1.id = b.pickup_place_id
    LEFT JOIN places  p2 ON p2.id = b.dropoff_place_id
    WHERE b.id = :id AND b.company_id = :company_id
    LIMIT 1
");
$st->execute(['id' => $bookingId, 'company_id' => $companyId]);
$booking = $st->fetch();
if (!$booking) die('Booking not found or not accessible.');

// -----------------------------
// 3) DRIVERS from booking_drivers (principal + additional)
// -----------------------------
$st = $pdo->prepare("
    SELECT bd.role, d.*
    FROM booking_drivers bd
    JOIN drivers d ON d.id = bd.driver_id
    WHERE bd.booking_id = :booking_id
      AND d.company_id = :company_id
    ORDER BY FIELD(bd.role,'principal','additional'), d.id ASC
");
$st->execute(['booking_id' => $bookingId, 'company_id' => $companyId]);
$drivers = $st->fetchAll();

$principal  = null;
$additional = null;

foreach ($drivers as $dr) {
    if ($dr['role'] === 'principal' && !$principal)  $principal = $dr;
    if ($dr['role'] === 'additional' && !$additional) $additional = $dr;
}

$principalName  = $principal  ? trim(($principal['first_name'] ?? '').' '.($principal['last_name'] ?? '')) : '';
$additionalName = $additional ? trim(($additional['first_name'] ?? '').' '.($additional['last_name'] ?? '')) : '';

// Principal extra fields (as per your DB: address_morocco, id_doc_type, id_doc_number)
$principalAddress = $principal['address_morocco'] ?? '';
$principalDocType = $principal['id_doc_type'] ?? '';
$principalDocNum  = $principal['id_doc_number'] ?? '';
$principalDocLabel = '—';
if (!empty($principalDocType) || !empty($principalDocNum)) {
    $t = strtoupper((string)$principalDocType);
    $principalDocLabel = trim(($t ? $t : '').' '.($principalDocNum ? $principalDocNum : ''));
    if ($principalDocLabel === '') $principalDocLabel = '—';
}

// Additional extra fields
$additionalAddress = $additional['address_morocco'] ?? '';
$additionalDocType = $additional['id_doc_type'] ?? '';
$additionalDocNum  = $additional['id_doc_number'] ?? '';
$additionalDocLabel = '—';
if (!empty($additionalDocType) || !empty($additionalDocNum)) {
    $t2 = strtoupper((string)$additionalDocType);
    $additionalDocLabel = trim(($t2 ? $t2 : '').' '.($additionalDocNum ? $additionalDocNum : ''));
    if ($additionalDocLabel === '') $additionalDocLabel = '—';
}

// -----------------------------
// 4) Ensure CONTRACT exists
// -----------------------------
$st = $pdo->prepare("
    SELECT * FROM contracts
    WHERE booking_id = :booking_id AND company_id = :company_id
    LIMIT 1
");
$st->execute(['booking_id' => $bookingId, 'company_id' => $companyId]);
$contract = $st->fetch();

if (!$contract) {
    $year = date('Y');
    $contractNumber = 'CT-' . $year . '-' . str_pad((string)$bookingId, 6, '0', STR_PAD_LEFT);

    $ins = $pdo->prepare("
        INSERT INTO contracts (company_id, booking_id, contract_number, deposit_amount, terms)
        VALUES (:company_id, :booking_id, :contract_number, :deposit_amount, :terms)
    ");
    $ins->execute([
        'company_id'      => $companyId,
        'booking_id'      => $bookingId,
        'contract_number' => $contractNumber,
        'deposit_amount'  => 0,
        'terms'           => $termsText
    ]);

    $st->execute(['booking_id' => $bookingId, 'company_id' => $companyId]);
    $contract = $st->fetch();
}

$contractNumber = $contract['contract_number'] ?? ('CT-' . date('Y') . '-' . $bookingId);
$depositAmount  = $contract['deposit_amount'] ?? 0;

// Billing
$totalDays  = $booking['total_days'] ?? '';
$dailyPrice = $booking['daily_price'] ?? 0;
$totalPrice = $booking['total_price'] ?? 0;
$paidAmount = $booking['paid_amount'] ?? 0;

// -----------------------------
// 5) BILINGUAL TERMS (fixed text)
// -----------------------------
$terms_fr = <<<FR
1. Objet du contrat
Le présent contrat définit les conditions de location d’un véhicule entre l’agence de location, ci-après désignée « le Loueur », et le client, ci-après désigné « le Locataire ».

2. Conditions d’éligibilité du locataire
Le Locataire doit :
• Être âgé d’au moins 18 ans (ou 21 ans selon la catégorie).
• Être titulaire d’un permis de conduire valide depuis au moins 12 mois.
• Présenter une pièce d’identité valide.
• Fournir un moyen de garantie accepté par l’agence.

3. Durée de la location
La durée est précisée dans le contrat.
Tout retard de restitution sera facturé une journée supplémentaire.
Aucun remboursement n’est accordé en cas de restitution anticipée.

4. Tarifs et paiement
Les tarifs sont exprimés en dirhams marocains.
Le paiement est exigé à l’avance.
Les prix varient selon la saison et la catégorie du véhicule.
La TVA est appliquée conformément à la loi marocaine.

5. Dépôt de garantie
Une caution est exigée à la prise du véhicule.
Elle est restituée après déduction des éventuels frais (dommages, amendes).

6. Assurance
Le véhicule est couvert par une assurance responsabilité civile.
Une assurance tous risques est proposée en option.
En cas d’accident, le Locataire doit informer immédiatement le Loueur.
Toute négligence engage la responsabilité du Locataire.

7. Utilisation du véhicule
Il est interdit :
• D’utiliser le véhicule à des fins illégales ou sportives.
• De conduire hors des routes autorisées.
• De confier la conduite à une personne non autorisée.
• De sortir le véhicule du Maroc sans autorisation écrite.

8. État du véhicule et carburant
Le véhicule est livré propre et en bon état.
Il doit être restitué dans le même état.
Le niveau de carburant doit être identique.
Les réparations dues à une mauvaise utilisation sont à la charge du Locataire.

9. Infractions
Le Locataire est responsable de toutes les infractions.
Les amendes peuvent être déduites de la caution.

10. Panne
En cas de panne non imputable au Locataire, une assistance sera fournie.
Aucun remboursement sans accord écrit.

11. Résiliation
Le Loueur peut résilier le contrat en cas de non-respect.
Aucun remboursement en cas de restitution anticipée.

12. Loi et juridiction
Le contrat est soumis au droit marocain.
Les litiges relèvent des tribunaux marocains compétents.
FR;

$terms_ar = <<<AR
1. موضوع العقد
يهدف هذا العقد إلى تحديد شروط كراء سيارة من طرف وكالة كراء السيارات، المشار إليها بـ المؤجّر، إلى الزبون المشار إليه بـ المكتري.

2. شروط أهلية المكتري
يشترط في المكتري:
• أن لا يقل عمره عن 18 سنة (أو 21 سنة حسب فئة السيارة).
• التوفر على رخصة سياقة سارية المفعول منذ ما لا يقل عن 12 شهرًا.
• الإدلاء ببطاقة تعريف وطنية أو جواز سفر ساري.
• تقديم وسيلة ضمان مقبولة من طرف الوكالة (بطاقة بنكية أو وديعة).

3. مدة الكراء
تُحدد مدة الكراء في العقد.
أي تأخير في إرجاع السيارة دون إشعار مسبق يُحتسب يوم كراء إضافي.
لا يحق للمكتري المطالبة باسترجاع أي مبلغ في حالة الإرجاع قبل انتهاء المدة.

4. الأسعار وطرق الأداء
تُحدد الأسعار بالدرهم المغربي وتشمل كراء السيارة فقط.
يتم الأداء مسبقًا عند توقيع العقد.
قد تختلف الأسعار حسب الموسم ونوع السيارة ومدة الكراء.
تطبق الضريبة على القيمة المضافة وفق القوانين المغربية.

5. الوديعة (الضمان)
يُلزم المكتري بإيداع وديعة ضمان عند استلام السيارة.
تُسترجع الوديعة بعد إعادة السيارة في حالتها الأصلية، بعد خصم أي أضرار أو غرامات.

6. التأمين
السيارة مؤمنة بتأمين المسؤولية المدنية.
يمكن للمكتري الاشتراك في تأمين شامل مقابل رسوم إضافية.
في حالة حادث، يجب إشعار الوكالة فورًا وإنجاز محضر رسمي عند الاقتضاء.
يتحمل المكتري المسؤولية في حالة الإهمال أو خرق شروط العقد.

7. استعمال السيارة
يُمنع:
• استعمال السيارة في أنشطة غير قانونية أو سباقات.
• القيادة خارج الطرق المسموح بها.
• السماح لشخص غير مصرح له بقيادة السيارة.
• مغادرة التراب المغربي دون إذن كتابي من الوكالة.

8. حالة السيارة والوقود
تُسلّم السيارة في حالة جيدة ونظيفة.
يجب إرجاع السيارة بنفس حالة التسليم.
الوقود يُعاد بنفس المستوى عند الاستلام.
يتحمل المكتري تكاليف الأعطال الناتجة عن سوء الاستعمال.

9. المخالفات
يتحمل المكتري جميع المخالفات المرورية خلال مدة الكراء.
يمكن خصم الغرامات من الوديعة.

10. الأعطال
في حالة عطل غير ناتج عن خطأ المكتري، تلتزم الوكالة بتقديم المساعدة أو التعويض.
لا يحق للمكتري المطالبة بتعويض دون موافقة كتابية.

11. فسخ العقد
يحق للوكالة فسخ العقد دون تعويض في حالة عدم احترام الشروط.
الإرجاع المبكر لا يمنح أي تعويض.

12. القانون والنزاعات
يخضع هذا العقد للقانون المغربي.
يتم حل النزاعات وديًا، وإن تعذر ذلك عبر المحاكم المغربية المختصة.
AR;

?><!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Contrat de location - <?= h($contractNumber) ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <style>
    /* ===== PRINT A4 ===== */
    @page { size: A4; margin: 10mm; }
    body{ font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#111; background:#f3f4f6; margin:0; }
    .page{
      width: 210mm;
      min-height: 297mm;
      margin: 10px auto;
      background:#fff;
      border:1px solid #d1d5db;
      box-shadow: 0 10px 30px rgba(0,0,0,.08);
      padding: 10mm;
      box-sizing: border-box;
    }
    .top-actions{ width:210mm; margin: 10px auto 0; display:flex; gap:10px; justify-content:flex-end; }
    .btn{
      border:1px solid #111827; background:#111827; color:#fff;
      padding:8px 12px; border-radius:8px; cursor:pointer; text-decoration:none; font-size:12px;
    }
    .btn.secondary{ background:#fff; color:#111827; }
    @media print{
      body{ background:#fff; }
      .top-actions{ display:none; }
      .page{ margin:0; border:none; box-shadow:none; }
      .page-break{ page-break-before: always; break-before: page; }
    }

    /* ===== CONTRACT LOOK ===== */
    .header{
      display:flex; align-items:flex-start; justify-content:space-between; gap:10px;
      border-bottom:2px solid #111827; padding-bottom:8px; margin-bottom:10px;
    }
    .agency{ display:flex; gap:10px; align-items:flex-start; }
    .logo{
      width:60px; height:60px; border:1px solid #e5e7eb; border-radius:10px;
      display:flex; align-items:center; justify-content:center; overflow:hidden;
    }
    .logo img{ width:100%; height:100%; object-fit:cover; }
    .agency h1{ margin:0; font-size:18px; letter-spacing:.3px; }
    .agency .meta{ margin-top:4px; font-size:11px; color:#374151; line-height:1.35; }
    .titlebox{ text-align:right; }
    .titlebox .t1{ font-size:14px; font-weight:800; margin:0; }
    .titlebox .t2{ margin:4px 0 0; font-size:11px; color:#374151; }

    .grid{ display:grid; grid-template-columns: 1fr 1fr; gap:10px; }
    .box{ border:1px solid #111827; padding:8px; border-radius:8px; }
    .box h3{
      margin:0 0 6px; font-size:12px; text-transform:uppercase; letter-spacing:.4px;
      border-bottom:1px solid #111827; padding-bottom:4px;
    }
    .row{ display:grid; grid-template-columns: 140px 1fr; gap:8px; padding:4px 0; border-bottom:1px dotted #cbd5e1; }
    .row:last-child{ border-bottom:none; }
    .lbl{ color:#111827; font-weight:700; }
    .val{ min-height:16px; }
    .small{ font-size:11px; color:#374151; }
    .twoCols{ display:grid; grid-template-columns: 1fr 1fr; gap:10px; }
    .mutedline{ border-top:1px dashed #cbd5e1; margin:8px 0; }

    .sign{ margin-top:10px; display:grid; grid-template-columns: 1fr 1fr; gap:10px; }
    .sign.three{ grid-template-columns: 1fr 1fr 1fr; }
    .sign .sigbox{ border:1px solid #111827; border-radius:8px; padding:8px; min-height:70px; }
    .footnote{ margin-top:8px; font-size:10.5px; color:#374151; line-height:1.4; }

    /* ===== TERMS PAGE ===== */
    .terms-title{
      font-weight:900; font-size:13px; margin:0 0 8px; text-align:center;
      border:1px solid #111827; padding:8px; border-radius:10px;
    }
    .terms-grid{
      display:grid; grid-template-columns: 1fr 1fr; gap:12px;
    }
    .terms-col{
      border:1px solid #111827; border-radius:10px; padding:10px;
      min-height: 240mm;
    }
    .terms-col h4{
      margin:0 0 8px; font-size:12px; text-transform:uppercase; letter-spacing:.4px;
      border-bottom:1px solid #111827; padding-bottom:6px;
    }
    .terms-text{
      font-size:11px; color:#111827; line-height:1.55; white-space:pre-line;
    }
    .rtl{ direction: rtl; text-align: right; font-family: Arial, Helvetica, sans-serif; }
  </style>
</head>

<body>

  <div class="top-actions">
    <a class="btn secondary" href="booking_view.php?id=<?= (int)$bookingId ?>">← Back</a>
    <button class="btn" onclick="window.print()">Print / Save PDF</button>
  </div>

  <!-- =======================
       PAGE 1 (Contract main)
       ======================= -->
  <div class="page">

    <!-- HEADER -->
    <div class="header">
      <div class="agency">
        <div class="logo">
          <?php if (!empty($logoPath)): ?>
            <img src="<?= h($logoPath) ?>" alt="Logo">
          <?php else: ?>
            <span class="small">LOGO</span>
          <?php endif; ?>
        </div>
        <div>
          <h1><?= h($agencyName) ?></h1>
          <div class="meta">
            <?php if($agencyAddr || $agencyCity): ?><?= h($agencyAddr) ?><?= $agencyCity ? ' - '.h($agencyCity) : '' ?><br><?php endif; ?>
            <?php if($agencyPhone): ?>Tél: <?= h($agencyPhone) ?><?php endif; ?>
            <?php if($agencyEmail): ?> — Email: <?= h($agencyEmail) ?><?php endif; ?>
            <br>
            <?php if($agencyICE): ?>ICE: <?= h($agencyICE) ?><?php endif; ?>
            <?php if($agencyIF): ?> — IF: <?= h($agencyIF) ?><?php endif; ?>
            <?php if($agencyRC): ?> — RC: <?= h($agencyRC) ?><?php endif; ?>
            <?php if($agencyPAT): ?> — Patente: <?= h($agencyPAT) ?><?php endif; ?>
            <?php if($agencyCNSS): ?> — CNSS: <?= h($agencyCNSS) ?><?php endif; ?>
          </div>
        </div>
      </div>

      <div class="titlebox">
        <p class="t1">CONTRAT DE LOCATION</p>
        <p class="t2"><strong>N°:</strong> <?= h($contractNumber) ?></p>
        <p class="t2"><strong>Réf Booking:</strong> <?= h($booking['reference'] ?? '') ?></p>
      </div>
    </div>

    <div class="grid">

      <!-- LEFT: LOCATAIRE -->
      <div class="box">
        <h3>LE LOCATAIRE</h3>

        <div class="row">
          <div class="lbl">Nom / Prénom</div>
          <div class="val"><?= $principalName ? h($principalName) : '—' ?></div>
        </div>

        <div class="row">
          <div class="lbl">Date de naissance</div>
          <div class="val"><?= !empty($principal['birth_date']) ? h($principal['birth_date']) : '—' ?></div>
        </div>

        <div class="row">
          <div class="lbl">Nationalité</div>
          <div class="val"><?= h($principal['nationality'] ?? '—') ?></div>
        </div>

        <div class="row">
          <div class="lbl">Téléphone</div>
          <div class="val">
            <?= h($principal['phone'] ?? '—') ?>
            <?php if (!empty($principal['has_whatsapp'])): ?>
              <span class="small"> (WhatsApp)</span>
            <?php endif; ?>
          </div>
        </div>

        <div class="row">
          <div class="lbl">Adresse au Maroc</div>
          <div class="val"><?= !empty($principalAddress) ? h($principalAddress) : '—' ?></div>
        </div>

        <div class="row">
          <div class="lbl">CIN / Passport</div>
          <div class="val"><?= h($principalDocLabel) ?></div>
        </div>

        <div class="row">
          <div class="lbl">Permis N°</div>
          <div class="val"><?= h($principal['license_number'] ?? '—') ?></div>
        </div>

        <div class="row">
          <div class="lbl">Délivré le</div>
          <div class="val"><?= h($principal['license_issue_date'] ?? '—') ?></div>
        </div>

        <div class="row">
          <div class="lbl">Expire le</div>
          <div class="val"><?= h($principal['license_expiry_date'] ?? '—') ?></div>
        </div>

        <div class="row">
          <div class="lbl">Délivré à (Pays)</div>
          <div class="val"><?= h($principal['license_country'] ?? '—') ?></div>
        </div>

        <div class="row">
          <div class="lbl">Catégorie</div>
          <div class="val"><?= h($principal['license_category'] ?? 'B') ?></div>
        </div>

        <div class="mutedline"></div>

        <div class="small">
          Le <?= date('Y-m-d') ?>, le locataire conducteur déclare accepter les conditions.
        </div>

        <!-- OPTIONAL: ADDITIONAL DRIVER -->
        <?php if (!empty($additional)): ?>
          <div class="mutedline"></div>
          <h3>2ème CONDUCTEUR (Optionnel)</h3>

          <div class="row">
            <div class="lbl">Nom / Prénom</div>
            <div class="val"><?= $additionalName ? h($additionalName) : '—' ?></div>
          </div>

          <div class="row">
            <div class="lbl">Date de naissance</div>
            <div class="val"><?= !empty($additional['birth_date']) ? h($additional['birth_date']) : '—' ?></div>
          </div>

          <div class="row">
            <div class="lbl">Nationalité</div>
            <div class="val"><?= h($additional['nationality'] ?? '—') ?></div>
          </div>

          <div class="row">
            <div class="lbl">Téléphone</div>
            <div class="val">
              <?= h($additional['phone'] ?? '—') ?>
              <?php if (!empty($additional['has_whatsapp'])): ?>
                <span class="small"> (WhatsApp)</span>
              <?php endif; ?>
            </div>
          </div>

          <div class="row">
            <div class="lbl">Adresse au Maroc</div>
            <div class="val"><?= !empty($additionalAddress) ? h($additionalAddress) : '—' ?></div>
          </div>

          <div class="row">
            <div class="lbl">CIN / Passport</div>
            <div class="val"><?= h($additionalDocLabel) ?></div>
          </div>

          <div class="row">
            <div class="lbl">Permis N°</div>
            <div class="val"><?= h($additional['license_number'] ?? '—') ?></div>
          </div>

          <div class="row">
            <div class="lbl">Délivré le</div>
            <div class="val"><?= h($additional['license_issue_date'] ?? '—') ?></div>
          </div>

          <div class="row">
            <div class="lbl">Expire le</div>
            <div class="val"><?= h($additional['license_expiry_date'] ?? '—') ?></div>
          </div>

          <div class="row">
            <div class="lbl">Délivré à (Pays)</div>
            <div class="val"><?= h($additional['license_country'] ?? '—') ?></div>
          </div>

          <div class="row">
            <div class="lbl">Catégorie</div>
            <div class="val"><?= h($additional['license_category'] ?? 'B') ?></div>
          </div>
        <?php endif; ?>

      </div>

      <!-- RIGHT: VEHICLE -->
      <div class="box">
        <h3>LE VEHICULE EN LOCATION</h3>

        <div class="row">
          <div class="lbl">Marque / Modèle</div>
          <div class="val"><?= h(trim(($booking['brand'] ?? '').' '.($booking['model'] ?? ''))) ?></div>
        </div>

        <div class="row">
          <div class="lbl">Immatriculation</div>
          <div class="val"><?= h($booking['plate_number'] ?? '—') ?></div>
        </div>

        <div class="row">
          <div class="lbl">Année / Couleur</div>
          <div class="val">
            <?= h($booking['year'] ?? '—') ?><?= !empty($booking['color']) ? ' / '.h($booking['color']) : '' ?>
          </div>
        </div>

        <div class="row">
          <div class="lbl">Carburant</div>
          <div class="val"><?= h($booking['fuel_type'] ?? '—') ?></div>
        </div>

        <div class="twoCols">
          <div class="row" style="border-bottom:none;">
            <div class="lbl">Km Départ</div>
            <div class="val"><?= ($booking['start_mileage'] !== null && $booking['start_mileage'] !== '') ? (int)$booking['start_mileage'] : '—' ?></div>
          </div>
          <div class="row" style="border-bottom:none;">
            <div class="lbl">Km Retour</div>
            <div class="val"><?= ($booking['end_mileage'] !== null && $booking['end_mileage'] !== '') ? (int)$booking['end_mileage'] : '—' ?></div>
          </div>
        </div>

        <div class="twoCols">
          <div class="row" style="border-bottom:none;">
            <div class="lbl">Pickup</div>
            <div class="val"><?= !empty($booking['pickup_name']) ? h($booking['pickup_name']) : '—' ?></div>
          </div>
          <div class="row" style="border-bottom:none;">
            <div class="lbl">Dropoff</div>
            <div class="val"><?= !empty($booking['dropoff_name']) ? h($booking['dropoff_name']) : '—' ?></div>
          </div>
        </div>

        <div class="twoCols">
          <div class="row" style="border-bottom:none;">
            <div class="lbl">Date départ</div>
            <div class="val"><?= h($booking['start_datetime'] ?? '—') ?></div>
          </div>
          <div class="row" style="border-bottom:none;">
            <div class="lbl">Date retour</div>
            <div class="val"><?= h($booking['end_datetime'] ?? '—') ?></div>
          </div>
        </div>

        <div class="mutedline"></div>

        <h3>ASSURANCES</h3>
        <div class="row">
          <div class="lbl">Assurance</div>
          <div class="val"><?= h($insuranceLabel) ?></div>
        </div>
        <div class="row">
          <div class="lbl">Franchise</div>
          <div class="val"><?= h($franchiseLabel) ?></div>
        </div>

        <div class="mutedline"></div>

        <h3>CAUTION</h3>
        <div class="row">
          <div class="lbl">Montant</div>
          <div class="val"><?= money($depositAmount) ?> <?= h($currency) ?></div>
        </div>

        <div class="mutedline"></div>

        <h3>REGLEMENT</h3>
        <div class="row">
          <div class="lbl">Prix / Jour</div>
          <div class="val"><?= money($dailyPrice) ?> <?= h($currency) ?></div>
        </div>
        <div class="row">
          <div class="lbl">Nb Jours</div>
          <div class="val"><?= h($totalDays ?: '—') ?></div>
        </div>
        <div class="row">
          <div class="lbl">Total</div>
          <div class="val"><?= money($totalPrice) ?> <?= h($currency) ?></div>
        </div>
        <div class="row">
          <div class="lbl">Payé</div>
          <div class="val"><?= money($paidAmount) ?> <?= h($currency) ?></div>
        </div>

      </div>
    </div>

    <!-- OBSERVATIONS -->
    <div class="box" style="margin-top:10px;">
      <h3>OBSERVATIONS / CONDITIONS</h3>
      <div class="small">
        <?= nl2br(h($contract['terms'] ?? $termsText)) ?>
      </div>
    </div>

    <!-- SIGNATURES -->
    <div class="sign <?= !empty($additional) ? 'three' : '' ?>">
      <div class="sigbox">
        <strong>Signature du client (Locataire)</strong>
        <div class="small" style="margin-top:6px;">Nom: <?= $principalName ? h($principalName) : '—' ?></div>
      </div>

      <?php if (!empty($additional)): ?>
        <div class="sigbox">
          <strong>Signature du 2ème conducteur</strong>
          <div class="small" style="margin-top:6px;">Nom: <?= $additionalName ? h($additionalName) : '—' ?></div>
        </div>
      <?php endif; ?>

      <div class="sigbox">
        <strong>Signature & cachet de l’agence</strong>
        <div class="small" style="margin-top:6px;"><?= h($agencyName) ?></div>
      </div>
    </div>

    <div class="footnote">
      <strong>Important:</strong> Ce document est conçu pour être imprimé sur A4 (صفحتين).
      يمكنك لاحقاً إضافة توليد PDF رسمي باستعمال Dompdf/TCPDF.
    </div>

  </div>

  <!-- =======================
       PAGE 2 (Bilingual Terms)
       ======================= -->
  <div class="page page-break">
    <div class="terms-title">
      الشروط العامة لكراء السيارات – المغرب<br>
      CONDITIONS GÉNÉRALES DE LOCATION DE VÉHICULES – MAROC
    </div>

    <div class="terms-grid">
      <!-- LEFT: FR -->
      <div class="terms-col">
        <h4>Français – colonne gauche</h4>
        <div class="terms-text"><?= h($terms_fr) ?></div>
      </div>

      <!-- RIGHT: AR -->
      <div class="terms-col rtl">
        <h4>العربية – العمود الأيمن</h4>
        <div class="terms-text"><?= h($terms_ar) ?></div>
      </div>
    </div>
  </div>

</body>
</html>
