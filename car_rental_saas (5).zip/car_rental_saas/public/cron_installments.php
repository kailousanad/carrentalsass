<?php
// public/cron_installments.php
// Run daily (or included once/day from index.php)

require_once __DIR__ . '/../config/config.php';

if (php_sapi_name() !== 'cli') {
  // allow include from web too
}

$today = new DateTimeImmutable('today');
$ym = $today->format('Y-m'); // current month

// Fetch all active installments
$st = $pdo->prepare("
  SELECT vi.*, v.brand, v.model, v.plate_number
  FROM vehicle_installments vi
  JOIN vehicles v ON v.id = vi.vehicle_id
  WHERE vi.status='active'
");
$st->execute();
$rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

function clampDayToMonth(DateTimeImmutable $d, int $day): DateTimeImmutable {
  $daysInMonth = (int)$d->format('t');
  $day = max(1, min($day, $daysInMonth));
  return $d->setDate((int)$d->format('Y'), (int)$d->format('m'), $day);
}

foreach ($rows as $r) {
  $companyId = (int)$r['company_id'];
  $vehicleId = (int)$r['vehicle_id'];

  // If date range is set
  if (!empty($r['start_date'])) {
    $sd = new DateTimeImmutable($r['start_date']);
    if ($today < $sd) continue;
  }
  if (!empty($r['end_date'])) {
    $ed = new DateTimeImmutable($r['end_date']);
    if ($today > $ed) continue;
  }

  $dueDay = (int)($r['due_day'] ?? 5);
  $remindDays = (int)($r['remind_days_before'] ?? 5);
  $monthly = (float)($r['monthly_amount'] ?? 0);

  if ($monthly <= 0) continue;

  // due date for current month
  $firstOfMonth = new DateTimeImmutable($today->format('Y-m-01'));
  $dueDate = clampDayToMonth($firstOfMonth, $dueDay);

  // remind date
  $remindDate = $dueDate->sub(new DateInterval('P'.max(0,$remindDays).'D'));

  $vehicleLabel = trim(($r['brand'] ?? '').' '.($r['model'] ?? ''));
  $plate = (string)($r['plate_number'] ?? '—');

  // 1) Notification (once per month) at remindDate or after, if not created
  if ($today >= $remindDate) {
    $lastNotifMonth = (string)($r['last_notif_month'] ?? '');
    if ($lastNotifMonth !== $ym) {

      $type = 'bank_installment_due';
      $data = json_encode([
        'vehicle_id' => $vehicleId,
        'vehicle' => $vehicleLabel,
        'plate' => $plate,
        'provider' => $r['provider_name'] ?? null,
        'amount' => $monthly,
        'currency' => $r['currency'] ?? 'MAD',
        'due_date' => $dueDate->format('Y-m-d'),
        'days_left' => (int)$today->diff($dueDate)->format('%r%a'),
      ], JSON_UNESCAPED_UNICODE);

      $insN = $pdo->prepare("
        INSERT INTO notifications (company_id, type, data, is_read, created_at)
        VALUES (:cid, :type, :data, 0, NOW())
      ");
      $insN->execute(['cid'=>$companyId,'type'=>$type,'data'=>$data]);

      $pdo->prepare("
        UPDATE vehicle_installments
        SET last_notif_month = :ym
        WHERE company_id=:cid AND vehicle_id=:vid
        LIMIT 1
      ")->execute(['ym'=>$ym,'cid'=>$companyId,'vid'=>$vehicleId]);
    }
  }

  // 2) Expense creation (once per month) on/after dueDate
  if ($today >= $dueDate) {
    $lastExpenseMonth = (string)($r['last_expense_month'] ?? '');
    if ($lastExpenseMonth !== $ym) {
      // create expense
      $title = "Bank installment - $vehicleLabel ($plate)";
      $note  = "Provider: ".($r['provider_name'] ?? '—')." | Due: ".$dueDate->format('Y-m-d');

      $insE = $pdo->prepare("
        INSERT INTO expenses (company_id, date, title, amount, note, source_type, source_id)
        VALUES (:cid, :date, :title, :amount, :note, 'installment', :source_id)
      ");
      $insE->execute([
        'cid'=>$companyId,
        'date'=>$dueDate->format('Y-m-d'),
        'title'=>$title,
        'amount'=>$monthly,
        'note'=>$note,
        'source_id'=>$vehicleId
      ]);

      $pdo->prepare("
        UPDATE vehicle_installments
        SET last_expense_month = :ym
        WHERE company_id=:cid AND vehicle_id=:vid
        LIMIT 1
      ")->execute(['ym'=>$ym,'cid'=>$companyId,'vid'=>$vehicleId]);
    }
  }
}
