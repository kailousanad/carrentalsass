<?php
/**
 * public/cron_insurance.php
 * Auto-create:
 *  - notifications (reminder)
 *  - expense_templates (draft)
 *
 * You can run it:
 * - manually from browser while logged in (admin)
 * - OR via server cron: php /path/to/public/cron_insurance.php
 */

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    die('Super admin not allowed.');
}

require_once __DIR__ . '/../config/config.php';

$companyId = current_company_id();
if (!$companyId) die('Company ID not found.');

$daysBefore = isset($_GET['days']) ? max(1, (int)$_GET['days']) : 30; // default 30 days
$today = date('Y-m-d');
$limitDate = date('Y-m-d', strtotime("+{$daysBefore} days"));

/**
 * 1) Get vehicles with insurance_expiry_date between today and limitDate
 */
$stmt = $pdo->prepare("
    SELECT id, brand, model, plate_number, insurance_expiry_date
    FROM vehicles
    WHERE company_id = :cid
      AND insurance_expiry_date IS NOT NULL
      AND insurance_expiry_date >= :today
      AND insurance_expiry_date <= :limitDate
    ORDER BY insurance_expiry_date ASC
");
$stmt->execute([
    'cid' => $companyId,
    'today' => $today,
    'limitDate' => $limitDate,
]);
$vehicles = $stmt->fetchAll();

$createdNotifications = 0;
$createdTemplates = 0;

foreach ($vehicles as $v) {
    $vehicleId = (int)$v['id'];
    $dueDate = $v['insurance_expiry_date'];

    // Calculate days left
    $daysLeft = (int)floor((strtotime($dueDate) - strtotime($today)) / 86400);

    /**
     * 2) Upsert vehicle_reminders (idempotency)
     */
    $pdo->prepare("
        INSERT INTO vehicle_reminders (company_id, vehicle_id, reminder_type, due_date, last_notified_at)
        VALUES (:cid, :vid, 'insurance_expiring', :due, NULL)
        ON DUPLICATE KEY UPDATE company_id = company_id
    ")->execute([
        'cid' => $companyId,
        'vid' => $vehicleId,
        'due' => $dueDate,
    ]);

    // Check if we already notified recently (today)
    $check = $pdo->prepare("
        SELECT last_notified_at
        FROM vehicle_reminders
        WHERE company_id=:cid AND vehicle_id=:vid AND reminder_type='insurance_expiring' AND due_date=:due
        LIMIT 1
    ");
    $check->execute(['cid'=>$companyId,'vid'=>$vehicleId,'due'=>$dueDate]);
    $last = $check->fetchColumn();

    $alreadyNotifiedToday = $last && (date('Y-m-d', strtotime($last)) === $today);

    /**
     * 3) Create notification once per day max for same dueDate
     */
    if (!$alreadyNotifiedToday) {
        $data = json_encode([
            'vehicle_id' => $vehicleId,
            'plate_number' => $v['plate_number'],
            'vehicle' => trim(($v['brand'] ?? '').' '.($v['model'] ?? '')),
            'expiry_date' => $dueDate,
            'days_left' => $daysLeft,
        ], JSON_UNESCAPED_UNICODE);

        $pdo->prepare("
            INSERT INTO notifications (company_id, user_id, type, data, is_read, created_at)
            VALUES (:cid, NULL, 'insurance_expiring', :data, 0, NOW())
        ")->execute([
            'cid' => $companyId,
            'data' => $data,
        ]);

        $pdo->prepare("
            UPDATE vehicle_reminders
            SET last_notified_at = NOW()
            WHERE company_id=:cid AND vehicle_id=:vid AND reminder_type='insurance_expiring' AND due_date=:due
            LIMIT 1
        ")->execute(['cid'=>$companyId,'vid'=>$vehicleId,'due'=>$dueDate]);

        $createdNotifications++;
    }

    /**
     * 4) Create/Upsert expense template draft
     */
    $pdo->prepare("
        INSERT INTO expense_templates (company_id, vehicle_id, template_type, due_date, suggested_amount, currency, status, notes)
        VALUES (:cid, :vid, 'insurance_renewal', :due, 0.00, 'MAD', 'draft', :notes)
        ON DUPLICATE KEY UPDATE
            status = IF(status='dismissed', 'draft', status),
            updated_at = NOW()
    ")->execute([
        'cid' => $companyId,
        'vid' => $vehicleId,
        'due' => $dueDate,
        'notes' => 'Insurance renewal coming soon',
    ]);

    // Count only if new row inserted is hard; keep simple:
    $createdTemplates++;
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'ok' => true,
    'company_id' => $companyId,
    'days_before' => $daysBefore,
    'vehicles_found' => count($vehicles),
    'notifications_created_today' => $createdNotifications,
    'templates_touched' => $createdTemplates
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
