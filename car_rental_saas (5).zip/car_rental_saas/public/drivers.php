<?php
// public/drivers.php - Professional Modern Version with Modal & Search

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$page_title = 'Drivers Management – Car Rental SaaS';

$companyId = current_company_id();
if (!$companyId) {
    die('Company ID not found in session.');
}

$errors = [];
$success = '';

// === Upload Helper ===
function save_driver_file(array $file, int $companyId, int $driverId): ?string
{
    if (!isset($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) return null;
    $allowed = ['jpg','jpeg','png','webp','pdf'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) return null;

    $baseDir = __DIR__ . '/uploads/drivers/' . $companyId . '/' . $driverId;
    if (!is_dir($baseDir)) @mkdir($baseDir, 0777, true);

    $safeName = 'doc_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = $baseDir . '/' . $safeName;

    if (move_uploaded_file($file['tmp_name'], $dest)) {
        return 'uploads/drivers/' . $companyId . '/' . $driverId . '/' . $safeName;
    }
    return null;
}

// === Badge Helper ===
function driver_status_badge(string $status): array
{
    return match ($status) {
        'active'       => ['bg-success', 'Active', 'Ready for bookings'],
        'blocked'      => ['bg-danger', 'Blocked', 'Cannot be assigned'],
        'under_review' => ['bg-warning text-dark', 'Under Review', 'Documents pending'],
        default        => ['bg-secondary', ucfirst($status), ''],
    };
}

function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// === AJAX Request for Edit Modal ===
if (isset($_GET['ajax']) && isset($_GET['edit']) && ctype_digit($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM drivers WHERE id = ? AND company_id = ? LIMIT 1");
    $stmt->execute([$id, $companyId]);
    $driver = $stmt->fetch();

    if (!$driver) {
        echo json_encode(['success' => false]);
        exit;
    }

    $docs = [];
    $stmt = $pdo->prepare("SELECT type, file_path FROM driver_documents WHERE driver_id = ?");
    $stmt->execute([$id]);
    foreach ($stmt->fetchAll() as $doc) {
        $docs[$doc['type']] = $doc['file_path'];
    }

    echo json_encode([
        'success' => true,
        'driver' => $driver,
        'docs' => $docs
    ]);
    exit;
}

// === Status Change ===
if (isset($_GET['status'], $_GET['id']) && ctype_digit($_GET['id'])) {
    $id = (int)$_GET['id'];
    $status = $_GET['status'];
    $allowed = ['active', 'blocked', 'under_review'];
    if (in_array($status, $allowed, true)) {
        $pdo->prepare("UPDATE drivers SET status = ? WHERE id = ? AND company_id = ?")
            ->execute([$status, $id, $companyId]);
        $success = 'Status updated successfully.';
    }
}

// === POST: Add / Edit Driver ===
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

    // Identity
    $first_name   = trim($_POST['first_name'] ?? '');
    $last_name    = trim($_POST['last_name'] ?? '');
    $birth_date   = trim($_POST['birth_date'] ?? '');
    $nationality  = trim($_POST['nationality'] ?? '');

    // Contact
    $phone        = trim($_POST['phone'] ?? '');
    $has_whatsapp = isset($_POST['has_whatsapp']) ? 1 : 0;

    // Extra legal fields
    $address_morocco = trim($_POST['address_morocco'] ?? '');
    $id_doc_type     = trim($_POST['id_doc_type'] ?? '');
    $id_doc_number   = trim($_POST['id_doc_number'] ?? '');

    // License
    $license_number      = trim($_POST['license_number'] ?? '');
    $license_country     = trim($_POST['license_country'] ?? '');
    $license_issue_date  = trim($_POST['license_issue_date'] ?? '');
    $license_expiry_date = trim($_POST['license_expiry_date'] ?? '');
    $license_category    = trim($_POST['license_category'] ?? 'B');
    if ($license_category === '') $license_category = 'B';

    // Status + notes
    $status = $_POST['status'] ?? 'under_review';
    $notes  = trim($_POST['notes'] ?? '');

    // ---------- Validations ----------
    $errors = [];
    if ($first_name === '') $errors[] = 'First name is required.';
    if ($last_name === '')  $errors[] = 'Last name is required.';
    if ($phone === '')      $errors[] = 'Phone is required.';
    if ($birth_date === '') $errors[] = 'Birth date is required.';
    if ($nationality === '') $errors[] = 'Nationality is required.';

    if ($license_number === '')  $errors[] = 'License number is required.';
    if ($license_country === '') $errors[] = 'License country is required.';
    if ($license_issue_date === '') $errors[] = 'License issue date is required.';
    if ($license_expiry_date === '') $errors[] = 'License expiry date is required.';

    foreach (['Birth date' => $birth_date, 'License issue date' => $license_issue_date, 'License expiry date' => $license_expiry_date] as $label => $dateVal) {
        if ($dateVal !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateVal)) {
            $errors[] = $label . ' is invalid (format: YYYY-MM-DD).';
        }
    }

    $allowedDocTypes = ['', 'cin', 'passport'];
    if (!in_array($id_doc_type, $allowedDocTypes, true)) {
        $id_doc_type = '';
    }

    $allowedStatus = ['active','blocked','under_review'];
    if (!in_array($status, $allowedStatus, true)) {
        $status = 'under_review';
    }

    if ($license_expiry_date !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $license_expiry_date)) {
        if (strtotime($license_expiry_date) < time()) {
            $errors[] = 'Warning: License is expired. Please update expiry date or keep driver Under review.';
        }
    }

    // إذا كانت هناك أخطاء → لا نرفع ملفات ولا نحفظ
    if (!empty($errors)) {
        // لا نفعل شيئًا هنا، فقط نعرض الأخطاء في الـ Modal (لكن في نسختنا الجديدة بالـ Modal، الأخطاء ستظهر بعد الـ redirect)
        // في النسخة بالـ Modal بدون redirect، يجب عرض الأخطاء مباشرة، لكن حاليًا نستخدم redirect
        $success = ''; // نتأكد
    } else {
        // لا أخطاء → نحفظ البيانات
        try {
            if ($id > 0) {
                // UPDATE
                $sql = "
                    UPDATE drivers SET
                        first_name = :first_name, last_name = :last_name, birth_date = :birth_date,
                        nationality = :nationality, phone = :phone, has_whatsapp = :has_whatsapp,
                        address_morocco = :address_morocco, id_doc_type = :id_doc_type, id_doc_number = :id_doc_number,
                        license_number = :license_number, license_country = :license_country,
                        license_issue_date = :license_issue_date, license_expiry_date = :license_expiry_date,
                        license_category = :license_category, status = :status, notes = :notes
                    WHERE id = :id AND company_id = :company_id
                ";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    'first_name' => $first_name, 'last_name' => $last_name, 'birth_date' => $birth_date,
                    'nationality' => $nationality, 'phone' => $phone, 'has_whatsapp' => $has_whatsapp,
                    'address_morocco' => $address_morocco !== '' ? $address_morocco : null,
                    'id_doc_type' => $id_doc_type !== '' ? $id_doc_type : null,
                    'id_doc_number' => $id_doc_number !== '' ? $id_doc_number : null,
                    'license_number' => $license_number, 'license_country' => $license_country,
                    'license_issue_date' => $license_issue_date, 'license_expiry_date' => $license_expiry_date,
                    'license_category' => $license_category, 'status' => $status,
                    'notes' => $notes !== '' ? $notes : null,
                    'id' => $id, 'company_id' => $companyId,
                ]);
                $driverIdForDocs = $id;
                $success = 'Driver updated successfully.';
            } else {
                // INSERT
                $sql = "
                    INSERT INTO drivers
                        (company_id, first_name, last_name, birth_date, nationality, phone, has_whatsapp,
                         address_morocco, id_doc_type, id_doc_number,
                         license_number, license_country, license_issue_date, license_expiry_date, license_category,
                         status, notes)
                    VALUES
                        (:company_id, :first_name, :last_name, :birth_date, :nationality, :phone, :has_whatsapp,
                         :address_morocco, :id_doc_type, :id_doc_number,
                         :license_number, :license_country, :license_issue_date, :license_expiry_date, :license_category,
                         :status, :notes)
                ";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    'company_id' => $companyId, 'first_name' => $first_name, 'last_name' => $last_name,
                    'birth_date' => $birth_date, 'nationality' => $nationality, 'phone' => $phone,
                    'has_whatsapp' => $has_whatsapp,
                    'address_morocco' => $address_morocco !== '' ? $address_morocco : null,
                    'id_doc_type' => $id_doc_type !== '' ? $id_doc_type : null,
                    'id_doc_number' => $id_doc_number !== '' ? $id_doc_number : null,
                    'license_number' => $license_number, 'license_country' => $license_country,
                    'license_issue_date' => $license_issue_date, 'license_expiry_date' => $license_expiry_date,
                    'license_category' => $license_category, 'status' => $status,
                    'notes' => $notes !== '' ? $notes : null,
                ]);
                $driverIdForDocs = (int)$pdo->lastInsertId();
                $success = 'New driver created successfully.';
            }

            // ---------- Handle documents ONLY if save was successful ----------
            $docMap = [
                'doc_license_front' => 'license_front',
                'doc_license_back'  => 'license_back',
                'doc_cin'           => 'cin',
                'doc_passport'      => 'passport',
            ];

            foreach ($docMap as $inputName => $docType) {
                if (!empty($_FILES[$inputName]['name'])) {
                    $saved = save_driver_file($_FILES[$inputName], $companyId, $driverIdForDocs);
                    if ($saved) {
                        $check = $pdo->prepare("SELECT id FROM driver_documents WHERE driver_id = :driver_id AND type = :type LIMIT 1");
                        $check->execute(['driver_id' => $driverIdForDocs, 'type' => $docType]);
                        $existing = $check->fetch();

                        if ($existing) {
                            $upd = $pdo->prepare("UPDATE driver_documents SET file_path = :file_path, uploaded_at = NOW() WHERE id = :id");
                            $upd->execute(['file_path' => $saved, 'id' => (int)$existing['id']]);
                        } else {
                            $ins = $pdo->prepare("INSERT INTO driver_documents (driver_id, type, file_path) VALUES (:driver_id, :type, :file_path)");
                            $ins->execute(['driver_id' => $driverIdForDocs, 'type' => $docType, 'file_path' => $saved]);
                        }
                    }
                }
            }

        } catch (PDOException $e) {
            $errors[] = 'Database error: ' . $e->getMessage();
        }
    }

    // إذا كانت هناك أخطاء أو نجاح → redirect لتجنب إعادة الإرسال
    if (!empty($success) || !empty($errors)) {
        $query = http_build_query(['success' => $success] + (!empty($errors) ? ['errors' => $errors] : []));
        header('Location: drivers.php?' . $query);
        exit;
    }
}

if (isset($_GET['success'])) $success = 'Operation completed successfully.';

// === Fetch Drivers with Search ===
$search = trim($_GET['q'] ?? '');
$sql = "SELECT d.*,
        (SELECT GROUP_CONCAT(type SEPARATOR ',') FROM driver_documents dd WHERE dd.driver_id = d.id) AS docs_types
        FROM drivers d
        WHERE d.company_id = :company_id";
$params = ['company_id' => $companyId];

if ($search !== '') {
    $sql .= " AND (CONCAT(d.first_name, ' ', d.last_name) LIKE :q
                  OR d.phone LIKE :q
                  OR d.license_number LIKE :q
                  OR d.nationality LIKE :q
                  OR d.id_doc_number LIKE :q)";
    $params['q'] = "%$search%";
}

$sql .= " ORDER BY d.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$drivers = $stmt->fetchAll();

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-md-10 p-4 ultra-page">
    <!-- Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <h4 class="mb-1 fw-bold">Drivers Management</h4>
            <p class="text-muted small mb-0">Add, edit, and manage your professional drivers</p>
        </div>
        <button class="btn btn-primary btn-lg shadow-sm" data-bs-toggle="modal" data-bs-target="#driverModal" onclick="resetModal()">
            <i class="bi bi-plus-circle me-2"></i> Add New Driver
        </button>
    </div>

    <!-- Search Bar -->
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-body">
            <form method="get" class="row g-3 align-items-center">
                <div class="col-lg-6">
                    <div class="input-group input-group-lg">
                        <span class="input-group-text bg-white"><i class="bi bi-search"></i></span>
                        <input type="text" name="q" class="form-control border-start-0" placeholder="Search by name, phone, license, nationality..."
                               value="<?= h($search) ?>">
                    </div>
                </div>
                <div class="col-lg-3">
                    <button type="submit" class="btn btn-primary w-100">Search</button>
                </div>
                <?php if ($search): ?>
                <div class="col-lg-3">
                    <a href="drivers.php" class="btn btn-outline-secondary w-100">Clear Search</a>
                </div>
                <?php endif; ?>
            </form>
            <div class="mt-3 text-muted small">
                <i class="bi bi-info-circle me-1"></i>
                <?= count($drivers) ?> driver<?= count($drivers) != 1 ? 's' : '' ?> found
            </div>
        </div>
    </div>

    <!-- Success Alert -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= h($success) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Drivers Cards -->
    <?php if (empty($drivers)): ?>
        <div class="text-center py-5">
            <i class="bi bi-person-slash display-1 text-muted opacity-50"></i>
            <h5 class="mt-4 text-muted">No drivers found</h5>
            <p class="text-muted">Start by adding your first driver.</p>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#driverModal" onclick="resetModal()">
                <i class="bi bi-plus-circle"></i> Add Driver
            </button>
        </div>
    <?php else: ?>
        <div class="row g-4">
            <?php foreach ($drivers as $d):
                [$bg, $label, $tip] = driver_status_badge($d['status'] ?? 'under_review');
                $name = trim($d['first_name'] . ' ' . $d['last_name']);
                $hasDocs = !empty($d['docs_types']);
            ?>
                <div class="col-md-6 col-xl-4">
                    <div class="card h-100 shadow-sm border-0 hover-lift">
                        <div class="card-body d-flex flex-column">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div>
                                    <h6 class="mb-1 fw-bold"><?= h($name ?: 'Unnamed') ?></h6>
                                    <small class="text-muted">ID: #<?= $d['id'] ?></small>
                                </div>
                                <span class="badge <?= $bg ?> px-3 py-2" title="<?= h($tip) ?>">
                                    <?= h($label) ?>
                                </span>
                            </div>

                            <div class="small text-muted flex-grow-1">
                                <div><i class="bi bi-telephone-fill text-primary me-2"></i><?= h($d['phone'] ?? '—') ?>
                                    <?php if ($d['has_whatsapp']): ?><i class="bi bi-whatsapp text-success ms-1"></i><?php endif; ?>
                                </div>
                                <div><i class="bi bi-globe me-2"></i><?= h($d['nationality'] ?? '—') ?></div>
                                <div><i class="bi bi-calendar me-2"></i>Born: <?= h($d['birth_date'] ?? '—') ?></div>
                                <div class="mt-2 fw-semibold"><i class="bi bi-card-heading me-2"></i><?= h($d['license_number'] ?? '—') ?></div>
                                <div class="text-muted ms-4">Expires: <?= h($d['license_expiry_date'] ?? '—') ?> • Cat: <?= h($d['license_category'] ?? 'B') ?></div>
                                <?php if ($hasDocs): ?>
                                    <div class="mt-3"><i class="bi bi-file-earmark-check text-success me-2"></i>Documents uploaded</div>
                                <?php endif; ?>
                            </div>

                            <div class="mt-4 d-flex gap-2">
                                <button class="btn btn-outline-primary flex-fill" onclick="loadDriver(<?= $d['id'] ?>)">
                                    <i class="bi bi-pencil"></i> Edit
                                </button>
                                <div class="btn-group flex-fill">
                                    <a href="?id=<?= $d['id'] ?>&status=active" class="btn btn-sm <?= $d['status']==='active'?'btn-success':'btn-outline-success' ?>">Active</a>
                                    <a href="?id=<?= $d['id'] ?>&status=under_review" class="btn btn-sm <?= $d['status']==='under_review'?'btn-warning':'btn-outline-warning' ?>">Review</a>
                                    <a href="?id=<?= $d['id'] ?>&status=blocked" class="btn btn-sm <?= $d['status']==='blocked'?'btn-danger':'btn-outline-danger' ?>">Block</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- ====================== DRIVER MODAL ====================== -->
<div class="modal fade" id="driverModal" tabindex="-1" aria-labelledby="driverModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <form method="post" enctype="multipart/form-data" id="driverForm">
            <div class="modal-content shadow-lg">
                <div class="modal-header bg-gradient-primary text-white">
                    <h5 class="modal-title fw-bold" id="driverModalLabel">Add New Driver</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="driver_id" value="0">

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <?php foreach ($errors as $e): ?><div><?= h($e) ?></div><?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <div class="row g-4">
                        <!-- Personal Info -->
                        <div class="col-lg-6">
                            <h6 class="fw-bold text-primary mb-3"><i class="bi bi-person me-2"></i>Personal Information</h6>
                            <div class="mb-3"><label class="form-label">First Name *</label><input type="text" name="first_name" class="form-control" required></div>
                            <div class="mb-3"><label class="form-label">Last Name *</label><input type="text" name="last_name" class="form-control" required></div>
                            <div class="mb-3"><label class="form-label">Birth Date *</label><input type="date" name="birth_date" class="form-control" required></div>
                            <div class="mb-3"><label class="form-label">Nationality *</label><input type="text" name="nationality" class="form-control" required></div>
                            <div class="mb-3"><label class="form-label">Phone *</label><input type="text" name="phone" class="form-control" required></div>
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" name="has_whatsapp" id="has_whatsapp" value="1" checked>
                                <label class="form-check-label" for="has_whatsapp">Has WhatsApp</label>
                            </div>
                            <div class="mb-3"><label class="form-label">Address in Morocco</label><input type="text" name="address_morocco" class="form-control"></div>
                        </div>

                        <!-- License & ID -->
                        <div class="col-lg-6">
                            <h6 class="fw-bold text-primary mb-3"><i class="bi bi-card-checklist me-2"></i>License & Identity</h6>
                            <div class="mb-3"><label class="form-label">License Number *</label><input type="text" name="license_number" class="form-control" required></div>
                            <div class="mb-3"><label class="form-label">License Country *</label><input type="text" name="license_country" class="form-control" required></div>
                            <div class="row">
                                <div class="col-6 mb-3"><label class="form-label">Issue Date *</label><input type="date" name="license_issue_date" class="form-control" required></div>
                                <div class="col-6 mb-3"><label class="form-label">Expiry Date *</label><input type="date" name="license_expiry_date" class="form-control" required></div>
                            </div>
                            <div class="mb-3"><label class="form-label">Category</label><input type="text" name="license_category" class="form-control" value="B"></div>

                            <div class="row mb-3">
                                <div class="col-5"><label class="form-label">ID Type</label>
                                    <select name="id_doc_type" class="form-select">
                                        <option value="">—</option>
                                        <option value="cin">CIN</option>
                                        <option value="passport">Passport</option>
                                    </select>
                                </div>
                                <div class="col-7"><label class="form-label">ID Number</label><input type="text" name="id_doc_number" class="form-control"></div>
                            </div>

                            <div class="mb-3"><label class="form-label">Status</label>
                                <select name="status" class="form-select">
                                    <option value="under_review">Under Review</option>
                                    <option value="active">Active</option>
                                    <option value="blocked">Blocked</option>
                                </select>
                            </div>

                            <div class="mb-3"><label class="form-label">Notes</label><textarea name="notes" rows="3" class="form-control"></textarea></div>
                        </div>
                    </div>

                    <hr class="my-5">

                    <!-- Documents -->
                    <h6 class="fw-bold text-primary mb-3"><i class="bi bi-cloud-upload me-2"></i>Documents (Optional)</h6>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small">License Front</label>
                            <input type="file" name="doc_license_front" class="form-control">
                            <div id="doc_license_front_preview" class="mt-2 small"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small">License Back</label>
                            <input type="file" name="doc_license_back" class="form-control">
                            <div id="doc_license_back_preview" class="mt-2 small"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small">CIN / National ID</label>
                            <input type="file" name="doc_cin" class="form-control">
                            <div id="doc_cin_preview" class="mt-2 small"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small">Passport</label>
                            <input type="file" name="doc_passport" class="form-control">
                            <div id="doc_passport_preview" class="mt-2 small"></div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-lg px-5">Save Driver</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Custom Styles -->
<style>
.hover-lift { transition: all 0.3s ease; }
.hover-lift:hover { transform: translateY(-8px); box-shadow: 0 20px 40px rgba(0,0,0,0.12) !important; }
.bg-gradient-primary { background: linear-gradient(135deg, #4f46e5, #7c3aed); }
</style>

<!-- JavaScript for Modal -->
<script>
function resetModal() {
    document.getElementById('driverModalLabel').textContent = 'Add New Driver';
    document.getElementById('driverForm').reset();
    document.getElementById('driver_id').value = '0';
    document.querySelectorAll('[id$="_preview"]').forEach(el => el.innerHTML = '');
}

function loadDriver(id) {
    fetch(`drivers.php?ajax=1&edit=${id}`)
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                const d = data.driver;
                document.getElementById('driverModalLabel').textContent = 'Edit Driver – ' + (d.first_name + ' ' + d.last_name).trim();
                document.getElementById('driver_id').value = d.id;

                // Fill fields
                document.querySelector('[name="first_name"]').value = d.first_name || '';
                document.querySelector('[name="last_name"]').value = d.last_name || '';
                document.querySelector('[name="birth_date"]').value = d.birth_date || '';
                document.querySelector('[name="nationality"]').value = d.nationality || '';
                document.querySelector('[name="phone"]').value = d.phone || '';
                document.querySelector('[name="has_whatsapp"]').checked = !!d.has_whatsapp;
                document.querySelector('[name="address_morocco"]').value = d.address_morocco || '';
                document.querySelector('[name="id_doc_type"]').value = d.id_doc_type || '';
                document.querySelector('[name="id_doc_number"]').value = d.id_doc_number || '';
                document.querySelector('[name="license_number"]').value = d.license_number || '';
                document.querySelector('[name="license_country"]').value = d.license_country || '';
                document.querySelector('[name="license_issue_date"]').value = d.license_issue_date || '';
                document.querySelector('[name="license_expiry_date"]').value = d.license_expiry_date || '';
                document.querySelector('[name="license_category"]').value = d.license_category || 'B';
                document.querySelector('[name="status"]').value = d.status || 'under_review';
                document.querySelector('[name="notes"]').value = d.notes || '';

                // Show current documents
                const docs = data.docs || {};
                if (docs.license_front) document.getElementById('doc_license_front_preview').innerHTML = `<a href="${docs.license_front}" target="_blank" class="text-success"><i class="bi bi-file-earmark-image"></i> View current</a>`;
                if (docs.license_back) document.getElementById('doc_license_back_preview').innerHTML = `<a href="${docs.license_back}" target="_blank" class="text-success"><i class="bi bi-file-earmark-image"></i> View current</a>`;
                if (docs.cin) document.getElementById('doc_cin_preview').innerHTML = `<a href="${docs.cin}" target="_blank" class="text-success"><i class="bi bi-file-earmark-text"></i> View current</a>`;
                if (docs.passport) document.getElementById('doc_passport_preview').innerHTML = `<a href="${docs.passport}" target="_blank" class="text-success"><i class="bi bi-file-earmark-text"></i> View current</a>`;

                new bootstrap.Modal(document.getElementById('driverModal')).show();
            }
        })
        .catch(() => alert('Error loading driver data.'));
}
</script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>