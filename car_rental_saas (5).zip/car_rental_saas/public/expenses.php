<?php
// public/expenses.php - Full Original Features + Beautiful Graphic Dashboard with Icons

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';

$page_title = 'Expenses Dashboard';

$companyId = current_company_id();
if (!$companyId) {
    die('Company ID not found.');
}

$types = [
    'maintenance' => ['label' => 'Maintenance', 'icon' => 'bi-tools', 'color' => 'bg-warning'],
    'fuel'        => ['label' => 'Fuel', 'icon' => 'bi-fuel-pump', 'color' => 'bg-danger'],
    'insurance'   => ['label' => 'Insurance', 'icon' => 'bi-shield-check', 'color' => 'bg-primary'],
    'tax'         => ['label' => 'Tax', 'icon' => 'bi-receipt', 'color' => 'bg-info'],
    'other'       => ['label' => 'Other', 'icon' => 'bi-three-dots', 'color' => 'bg-secondary'],
];

$errors = [];
$success = flash('success');
$errorMsg = flash('error');

/** Load vehicles */
$stmt = $pdo->prepare("SELECT id, brand, model, plate_number FROM vehicles WHERE company_id = :cid ORDER BY id DESC");
$stmt->execute(['cid' => $companyId]);
$vehicles = $stmt->fetchAll();

/** Handle POST */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['_csrf'] ?? '';
    if (!csrf_verify($csrf)) {
        $errors[] = 'Invalid CSRF token.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'create') {
            $vehicle_id  = (int)($_POST['vehicle_id'] ?? 0);
            $amount      = (float)($_POST['amount'] ?? 0);
            $type        = $_POST['type'] ?? 'other';
            $date        = $_POST['date'] ?? '';
            $description = trim($_POST['description'] ?? '');

            if ($amount <= 0) $errors[] = 'Amount must be greater than 0';
            if (empty($date)) $errors[] = 'Date is required';
            if (!array_key_exists($type, $types)) $type = 'other';
            $vehicle_id = $vehicle_id > 0 ? $vehicle_id : null;

            if (!$errors) {
                $stmt = $pdo->prepare("
                    INSERT INTO expenses (company_id, vehicle_id, amount, type, date, description)
                    VALUES (:cid, :vid, :amount, :type, :d, :desc)
                ");
                $stmt->execute([
                    'cid'    => $companyId,
                    'vid'    => $vehicle_id,
                    'amount' => $amount,
                    'type'   => $type,
                    'd'      => $date,
                    'desc'   => $description ?: null,
                ]);

                flash('success', 'Expense added successfully.');
                redirect('expenses.php');
            }
        }

        if ($action === 'update') {
            $id          = (int)($_POST['id'] ?? 0);
            $vehicle_id  = (int)($_POST['vehicle_id'] ?? 0);
            $amount      = (float)($_POST['amount'] ?? 0);
            $type        = $_POST['type'] ?? 'other';
            $date        = $_POST['date'] ?? '';
            $description = trim($_POST['description'] ?? '');

            if ($id <= 0) $errors[] = 'Invalid expense ID';
            if ($amount <= 0) $errors[] = 'Amount must be greater than 0';
            if (empty($date)) $errors[] = 'Date is required';
            if (!array_key_exists($type, $types)) $type = 'other';
            $vehicle_id = $vehicle_id > 0 ? $vehicle_id : null;

            if (!$errors) {
                $stmt = $pdo->prepare("
                    UPDATE expenses
                    SET vehicle_id = :vid, amount = :amount, type = :type, date = :d, description = :desc
                    WHERE id = :id AND company_id = :cid
                    LIMIT 1
                ");
                $stmt->execute([
                    'vid'    => $vehicle_id,
                    'amount' => $amount,
                    'type'   => $type,
                    'd'      => $date,
                    'desc'   => $description ?: null,
                    'id'     => $id,
                    'cid'    => $companyId,
                ]);

                flash('success', 'Expense updated successfully.');
                redirect('expenses.php');
            }
        }

        if ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id <= 0) $errors[] = 'Invalid expense ID';

            if (!$errors) {
                $stmt = $pdo->prepare("DELETE FROM expenses WHERE id = :id AND company_id = :cid LIMIT 1");
                $stmt->execute(['id' => $id, 'cid' => $companyId]);

                flash('success', 'Expense deleted successfully.');
                redirect('expenses.php');
            }
        }
    }
}

/** Filters */
$f_type = $_GET['type'] ?? '';
$f_vehicle = (int)($_GET['vehicle_id'] ?? 0);
$f_from = $_GET['from'] ?? '';
$f_to   = $_GET['to'] ?? '';

$where = "WHERE e.company_id = :cid";
$params = ['cid' => $companyId];

if ($f_type && array_key_exists($f_type, $types)) {
    $where .= " AND e.type = :t";
    $params['t'] = $f_type;
}
if ($f_vehicle > 0) {
    $where .= " AND e.vehicle_id = :vid";
    $params['vid'] = $f_vehicle;
}
if (!empty($f_from)) {
    $where .= " AND e.date >= :f";
    $params['f'] = $f_from;
}
if (!empty($f_to)) {
    $where .= " AND e.date <= :to";
    $params['to'] = $f_to;
}

$stmt = $pdo->prepare("
    SELECT e.*, v.brand, v.model, v.plate_number
    FROM expenses e
    LEFT JOIN vehicles v ON v.id = e.vehicle_id
    {$where}
    ORDER BY e.date DESC, e.id DESC
");
$stmt->execute($params);
$rows = $stmt->fetchAll();

/** Calculate totals and monthly data for chart */
$totalAll = 0;
$monthly = [];
foreach ($rows as $r) {
    $totalAll += (float)$r['amount'];
    $month = date('Y-m', strtotime($r['date']));
    $monthly[$month] = ($monthly[$month] ?? 0) + (float)$r['amount'];
}
ksort($monthly);
$chartLabels = json_encode(array_keys($monthly));
$chartData = json_encode(array_values($monthly));

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-md-10 p-4 ultra-page">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">Expenses Dashboard</h2>
            <p class="text-muted mb-0">Track and manage all operational costs</p>
        </div>
        <div class="text-end">
            <div class="small text-muted">Total Expenses</div>
            <h3 class="fw-bold text-danger mb-0"><?= money_fmt($totalAll) ?></h3>
        </div>
    </div>

    <!-- Alerts -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-4 shadow-sm">
            <i class="bi bi-check-circle-fill me-2"></i><?= e($success) ?>
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($errorMsg || $errors): ?>
        <div class="alert alert-danger alert-dismissible fade show rounded-4 shadow-sm">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?= e($errorMsg) ?>
            <?php foreach ($errors as $er): ?><div><?= e($er) ?></div><?php endforeach; ?>
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Stats Cards with Icons -->
    <div class="row g-4 mb-5">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-gradient-danger text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5 class="mb-1">Total Expenses</h5>
                            <h3 class="mb-0"><?= money_fmt($totalAll) ?></h3>
                        </div>
                        <i class="bi bi-currency-dollar display-4 opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-gradient-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5 class="mb-1">This Month</h5>
                            <h3 class="mb-0"><?= money_fmt($monthly[date('Y-m')] ?? 0) ?></h3>
                        </div>
                        <i class="bi bi-calendar-month display-4 opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-gradient-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5 class="mb-1">Transactions</h5>
                            <h3 class="mb-0"><?= count($rows) ?></h3>
                        </div>
                        <i class="bi bi-list-ul display-4 opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-gradient-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5 class="mb-1">Average</h5>
                            <h3 class="mb-0"><?= count($rows) > 0 ? money_fmt($totalAll / count($rows)) : money_fmt(0) ?></h3>
                        </div>
                        <i class="bi bi-graph-up display-4 opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Expenses Trend Chart -->
    <div class="card shadow-sm mb-5 border-0">
        <div class="card-header bg-white border-0">
            <h5 class="mb-0"><i class="bi bi-graph-down me-2"></i>Monthly Expenses Trend</h5>
        </div>
        <div class="card-body">
            <canvas id="expensesChart" height="120"></canvas>
        </div>
    </div>

    <!-- Filters -->
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-header bg-light">
            <h6 class="mb-0"><i class="bi bi-funnel me-2"></i>Filter Expenses</h6>
        </div>
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-3">
                    <select name="type" class="form-select">
                        <option value="">All Types</option>
                        <?php foreach ($types as $k => $t): ?>
                            <option value="<?= $k ?>" <?= $f_type === $k ? 'selected' : '' ?>>
                                <i class="<?= $t['icon'] ?> me-2"></i><?= $t['label'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <select name="vehicle_id" class="form-select">
                        <option value="0">All Vehicles</option>
                        <?php foreach ($vehicles as $v): ?>
                            <option value="<?= (int)$v['id'] ?>" <?= $f_vehicle === (int)$v['id'] ? 'selected' : '' ?>>
                                <?= e($v['brand'] . ' ' . $v['model'] . ' • ' . $v['plate_number']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <input type="date" name="from" value="<?= e($f_from) ?>" class="form-control" placeholder="From">
                </div>
                <div class="col-md-2">
                    <input type="date" name="to" value="<?= e($f_to) ?>" class="form-control" placeholder="To">
                </div>
                <div class="col-md-1 d-flex align-items-end">
                    <button class="btn btn-primary w-100"><i class="bi bi-search"></i></button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Expense -->
    <div class="card shadow-sm mb-5 border-0">
        <div class="card-header bg-danger text-white">
            <h5 class="mb-0"><i class="bi bi-plus-circle me-2"></i>Add New Expense</h5>
        </div>
        <div class="card-body">
            <form method="post" class="row g-3">
                <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="create">

                <div class="col-md-4">
                    <label class="form-label">Vehicle (optional)</label>
                    <select name="vehicle_id" class="form-select">
                        <option value="0">— General Expense —</option>
                        <?php foreach ($vehicles as $v): ?>
                            <option value="<?= (int)$v['id'] ?>"><?= e($v['brand'] . ' ' . $v['model'] . ' • ' . $v['plate_number']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="form-label">Type</label>
                    <select name="type" class="form-select" required>
                        <?php foreach ($types as $k => $t): ?>
                            <option value="<?= $k ?>"><i class="<?= $t['icon'] ?> me-2"></i><?= $t['label'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="form-label">Amount (MAD)</label>
                    <input type="number" step="0.01" name="amount" class="form-control" required placeholder="0.00">
                </div>

                <div class="col-md-2">
                    <label class="form-label">Date</label>
                    <input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>

                <div class="col-md-2 d-flex align-items-end">
                    <button class="btn btn-danger w-100">Add Expense</button>
                </div>

                <div class="col-12">
                    <label class="form-label">Description</label>
                    <input type="text" name="description" class="form-control" placeholder="e.g. Oil change, annual insurance, road tax...">
                </div>
            </form>
        </div>
    </div>

    <!-- Expenses List as Cards -->
    <h5 class="mb-4"><i class="bi bi-list-task me-2"></i>Recent Expenses (<?= count($rows) ?>)</h5>
    <div class="row g-4">
        <?php if (empty($rows)): ?>
            <div class="col-12 text-center py-5">
                <i class="bi bi-receipt-cutoff display-1 text-muted opacity-50"></i>
                <h5 class="mt-4 text-muted">No expenses recorded</h5>
                <p class="text-muted">Start tracking your costs using the form above</p>
            </div>
        <?php else: ?>
            <?php foreach ($rows as $r):
                $typeInfo = $types[$r['type']] ?? $types['other'];
            ?>
                <div class="col-md-6 col-xl-4">
                    <div class="card h-100 shadow-sm hover-lift">
                        <div class="card-header d-flex justify-content-between align-items-center <?= $typeInfo['color'] ?> text-white">
                            <div>
                                <i class="<?= $typeInfo['icon'] ?> me-2"></i>
                                <strong><?= $typeInfo['label'] ?></strong>
                            </div>
                            <div class="fs-5 fw-bold"><?= money_fmt($r['amount']) ?></div>
                        </div>
                        <div class="card-body d-flex flex-column">
                            <div class="small text-muted mb-3">
                                <div><i class="bi bi-calendar-event me-1"></i><strong><?= date('d M Y', strtotime($r['date'])) ?></strong></div>
                                <?php if (!empty($r['vehicle_id'])): ?>
                                    <div><i class="bi bi-truck me-1"></i><?= e($r['brand'] . ' ' . $r['model'] . ' • ' . $r['plate_number']) ?></div>
                                <?php endif; ?>
                                <?php if (!empty($r['description'])): ?>
                                    <div class="mt-2"><em><?= e($r['description']) ?></em></div>
                                <?php endif; ?>
                            </div>

                            <div class="mt-auto d-flex gap-2">
                                <button class="btn btn-outline-secondary btn-sm flex-fill" type="button" onclick="toggleForm('edit-<?= $r['id'] ?>')">
                                    <i class="bi bi-pencil me-1"></i>Edit
                                </button>
                                <form method="post" onsubmit="return confirm('Delete this expense permanently?')" class="flex-fill">
                                    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                    <button class="btn btn-outline-danger btn-sm w-100">
                                        <i class="bi bi-trash me-1"></i>Delete
                                    </button>
                                </form>
                            </div>

                            <!-- Edit Form -->
                            <div id="edit-<?= $r['id'] ?>" class="mt-3 d-none border-top pt-3 bg-light rounded">
                                <form method="post">
                                    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                                    <input type="hidden" name="action" value="update">
                                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">

                                    <div class="row g-2">
                                        <div class="col-12">
                                            <select name="vehicle_id" class="form-select form-select-sm">
                                                <option value="0">— General —</option>
                                                <?php foreach ($vehicles as $v): ?>
                                                    <option value="<?= (int)$v['id'] ?>" <?= (int)$r['vehicle_id'] === (int)$v['id'] ? 'selected' : '' ?>>
                                                        <?= e($v['brand'] . ' ' . $v['model'] . ' • ' . $v['plate_number']) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-6">
                                            <select name="type" class="form-select form-select-sm">
                                                <?php foreach ($types as $k => $t): ?>
                                                    <option value="<?= $k ?>" <?= $r['type'] === $k ? 'selected' : '' ?>>
                                                        <i class="<?= $t['icon'] ?> me-2"></i><?= $t['label'] ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-6">
                                            <input type="number" step="0.01" name="amount" class="form-control form-control-sm" value="<?= e($r['amount']) ?>" required>
                                        </div>
                                        <div class="col-6">
                                            <input type="date" name="date" class="form-control form-control-sm" value="<?= e($r['date']) ?>" required>
                                        </div>
                                        <div class="col-12">
                                            <input type="text" name="description" class="form-control form-control-sm" value="<?= e($r['description'] ?? '') ?>">
                                        </div>
                                        <div class="col-12 d-grid">
                                            <button class="btn btn-success btn-sm">Update Expense</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const ctx = document.getElementById('expensesChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= $chartLabels ?>,
            datasets: [{
                label: 'Monthly Expenses',
                data: <?= $chartData ?>,
                borderColor: '#dc3545',
                backgroundColor: 'rgba(220, 53, 69, 0.1)',
                tension: 0.4,
                fill: true,
                pointBackgroundColor: '#dc3545',
                pointRadius: 6
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' },
                tooltip: { mode: 'index', intersect: false }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
});
</script>

<style>
.hover-lift {
    transition: all 0.3s ease;
}
.hover-lift:hover {
    transform: translateY(-10px);
    box-shadow: 0 25px 50px rgba(0,0,0,0.15) !important;
}
.bg-gradient-danger { background: linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%); }
.bg-gradient-warning { background: linear-gradient(135deg, #feca57 0%, #ff9ff3 100%); }
.bg-gradient-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
.bg-gradient-info { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); }
</style>

<script>
function toggleForm(id) {
    document.getElementById(id).classList.toggle('d-none');
}
</script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>