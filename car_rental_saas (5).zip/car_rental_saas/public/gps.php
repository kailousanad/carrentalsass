<?php
// public/gps.php - Original Features 100% Preserved + Easier & More Professional User Experience

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php'; // لحل htmlspecialchars()

$page_title = 'GPS – Subscriptions & Devices';

$companyId = current_company_id();
if (!$companyId) {
    die('Company ID not found in session.');
}

// CSRF token
if (empty($_SESSION['_csrf'])) {
    $_SESSION['_csrf'] = bin2hex(random_bytes(16));
}
$CSRF = $_SESSION['_csrf'];

function post_csrf_or_die() {
    $csrf = $_POST['_csrf'] ?? '';
    if (empty($_SESSION['_csrf']) || !hash_equals($_SESSION['_csrf'], $csrf)) {
        http_response_code(401);
        die('Unauthorized (CSRF)');
    }
}

function days_remaining($endDate) {
    $end = strtotime($endDate);
    $now = strtotime(date('Y-m-d'));
    $diff = (int) floor(($end - $now) / 86400);
    return $diff;
}

function remaining_badge($days) {
    if ($days < 0) return ['bg-danger text-white', 'Expired ' . abs($days) . ' days ago'];
    if ($days <= 7) return ['bg-warning text-dark', 'Urgent: ' . $days . ' days'];
    if ($days <= 30) return ['bg-orange text-white', $days . ' days'];
    return ['bg-success', $days . ' days'];
}

/* =========================
   Handle Actions (كل الوظائف الأصلية محفوظة بالكامل بدون أي تغيير)
   ========================= */
$success = null;
$error = null;

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        post_csrf_or_die();
        $action = $_POST['action'] ?? '';

        if ($action === 'add_provider') {
            $name = trim($_POST['name'] ?? '');
            $address = trim($_POST['address'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $support_email = trim($_POST['support_email'] ?? '');
            $support_phone = trim($_POST['support_phone'] ?? '');
            $support_whatsapp = trim($_POST['support_whatsapp'] ?? '');
            $status = ($_POST['status'] ?? 'active');
            $notes = trim($_POST['notes'] ?? '');

            if ($name === '') throw new Exception('Provider name is required.');

            $pdo->prepare("
                INSERT INTO gps_providers
                (company_id, name, address, phone, support_email, support_phone, support_whatsapp, status, notes)
                VALUES
                (:cid, :name, :address, :phone, :support_email, :support_phone, :support_whatsapp, :status, :notes)
            ")->execute([
                'cid'=>$companyId,
                'name'=>$name,
                'address'=>$address ?: null,
                'phone'=>$phone ?: null,
                'support_email'=>$support_email ?: null,
                'support_phone'=>$support_phone ?: null,
                'support_whatsapp'=>$support_whatsapp ?: null,
                'status'=>$status === 'suspended' ? 'suspended' : 'active',
                'notes'=>$notes ?: null
            ]);

            $success = "GPS provider added.";
        }

        if ($action === 'add_plan') {
            $provider_id = (int)($_POST['provider_id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $billing_cycle = $_POST['billing_cycle'] ?? 'monthly';
            $price = (float)($_POST['price'] ?? 0);
            $currency = trim($_POST['currency'] ?? 'MAD');

            if ($provider_id <= 0) throw new Exception('Provider is required.');
            if ($name === '') throw new Exception('Plan name is required.');

            if ($billing_cycle === 'monthly') $duration = 1;
            elseif ($billing_cycle === 'semiannual') $duration = 6;
            else $duration = 12;

            $st = $pdo->prepare("SELECT id FROM gps_providers WHERE id=:id AND company_id=:cid");
            $st->execute(['id'=>$provider_id,'cid'=>$companyId]);
            if (!$st->fetchColumn()) throw new Exception('Invalid provider.');

            $pdo->prepare("
                INSERT INTO gps_plans
                (company_id, provider_id, name, billing_cycle, duration_months, price, currency, is_active)
                VALUES
                (:cid, :pid, :name, :cycle, :dur, :price, :cur, 1)
            ")->execute([
                'cid'=>$companyId,
                'pid'=>$provider_id,
                'name'=>$name,
                'cycle'=>in_array($billing_cycle,['monthly','semiannual','yearly']) ? $billing_cycle : 'monthly',
                'dur'=>$duration,
                'price'=>$price,
                'cur'=>$currency ?: 'MAD',
            ]);

            $success = "GPS plan added.";
        }

        if ($action === 'add_device') {
            $provider_id = (int)($_POST['provider_id'] ?? 0);
            $device_uid = trim($_POST['device_uid'] ?? '');
            $label = trim($_POST['label'] ?? '');
            $status = $_POST['status'] ?? 'available';
            $notes = trim($_POST['notes'] ?? '');

            if ($provider_id <= 0) throw new Exception('Provider is required.');
            if ($device_uid === '') throw new Exception('Device UID (IMEI/Serial) is required.');

            $st = $pdo->prepare("SELECT id FROM gps_providers WHERE id=:id AND company_id=:cid");
            $st->execute(['id'=>$provider_id,'cid'=>$companyId]);
            if (!$st->fetchColumn()) throw new Exception('Invalid provider.');

            $pdo->prepare("
                INSERT INTO gps_devices
                (company_id, provider_id, device_uid, label, status, notes)
                VALUES
                (:cid, :pid, :uid, :label, :status, :notes)
            ")->execute([
                'cid'=>$companyId,
                'pid'=>$provider_id,
                'uid'=>$device_uid,
                'label'=>$label ?: null,
                'status'=>in_array($status,['available','assigned','inactive']) ? $status : 'available',
                'notes'=>$notes ?: null,
            ]);

            $success = "GPS device added.";
        }

        if ($action === 'assign_subscription') {
            $device_id = (int)($_POST['device_id'] ?? 0);
            $vehicle_id = (int)($_POST['vehicle_id'] ?? 0);
            $plan_id = (int)($_POST['plan_id'] ?? 0);
            $start_date = trim($_POST['start_date'] ?? '');
            $price_paid = (float)($_POST['price_paid'] ?? 0);
            $transferable = isset($_POST['transferable']) ? 1 : 0;

            if ($device_id <= 0) throw new Exception('Device is required.');
            if ($plan_id <= 0) throw new Exception('Plan is required.');
            if ($start_date === '') throw new Exception('Start date is required.');

            $st = $pdo->prepare("SELECT id, status FROM gps_devices WHERE id=:id AND company_id=:cid");
            $st->execute(['id'=>$device_id,'cid'=>$companyId]);
            $dev = $st->fetch();
            if (!$dev) throw new Exception('Invalid device.');
            if ($dev['status'] === 'inactive') throw new Exception('Device is inactive.');

            $st = $pdo->prepare("SELECT id, duration_months FROM gps_plans WHERE id=:id AND company_id=:cid AND is_active=1");
            $st->execute(['id'=>$plan_id,'cid'=>$companyId]);
            $plan = $st->fetch();
            if (!$plan) throw new Exception('Invalid plan.');

            $dur = (int)$plan['duration_months'];
            $end_date = date('Y-m-d', strtotime($start_date . " +{$dur} months"));

            $vehId = null;
            if ($vehicle_id > 0) {
                $st = $pdo->prepare("SELECT id FROM vehicles WHERE id=:id AND company_id=:cid");
                $st->execute(['id'=>$vehicle_id,'cid'=>$companyId]);
                if (!$st->fetchColumn()) throw new Exception('Invalid vehicle.');
                $vehId = $vehicle_id;
            }

            $pdo->prepare("
                UPDATE gps_subscriptions
                SET status='expired', updated_at=NOW()
                WHERE company_id=:cid AND device_id=:did AND status='active'
            ")->execute(['cid'=>$companyId,'did'=>$device_id]);

            $pdo->prepare("
                INSERT INTO gps_subscriptions
                (company_id, device_id, vehicle_id, plan_id, start_date, end_date, price_paid, status, transferable)
                VALUES
                (:cid,:did,:vid,:pid,:sd,:ed,:pp,'active',:tr)
            ")->execute([
                'cid'=>$companyId,
                'did'=>$device_id,
                'vid'=>$vehId,
                'pid'=>$plan_id,
                'sd'=>$start_date,
                'ed'=>$end_date,
                'pp'=>$price_paid,
                'tr'=>$transferable
            ]);

            $pdo->prepare("UPDATE gps_devices SET status='assigned' WHERE id=:id AND company_id=:cid")
                ->execute(['id'=>$device_id,'cid'=>$companyId]);

            $success = "GPS subscription created.";
        }

        if ($action === 'detach_subscription') {
            $sub_id = (int)($_POST['sub_id'] ?? 0);
            if ($sub_id <= 0) throw new Exception('Invalid subscription.');

            $st = $pdo->prepare("SELECT id, vehicle_id, transferable, status FROM gps_subscriptions WHERE id=:id AND company_id=:cid");
            $st->execute(['id'=>$sub_id,'cid'=>$companyId]);
            $sub = $st->fetch();
            if (!$sub) throw new Exception('Subscription not found.');
            if ($sub['status'] !== 'active') throw new Exception('Only active subscriptions can be detached.');
            if ((int)$sub['transferable'] !== 1) throw new Exception('This subscription is not transferable.');

            $fromVehicle = $sub['vehicle_id'];

            $pdo->prepare("UPDATE gps_subscriptions SET vehicle_id=NULL WHERE id=:id AND company_id=:cid")
                ->execute(['id'=>$sub_id,'cid'=>$companyId]);

            $pdo->prepare("
                INSERT INTO gps_transfers (company_id, subscription_id, from_vehicle_id, to_vehicle_id, notes)
                VALUES (:cid,:sid,:from,NULL,'Detached from vehicle')
            ")->execute(['cid'=>$companyId,'sid'=>$sub_id,'from'=>$fromVehicle]);

            $success = "GPS detached (transferable remains).";
        }

        if ($action === 'transfer_subscription') {
            $sub_id = (int)($_POST['sub_id'] ?? 0);
            $to_vehicle_id = (int)($_POST['to_vehicle_id'] ?? 0);

            if ($sub_id <= 0) throw new Exception('Invalid subscription.');
            if ($to_vehicle_id <= 0) throw new Exception('Target vehicle is required.');

            $st = $pdo->prepare("
                SELECT id, vehicle_id, transferable, status
                FROM gps_subscriptions
                WHERE id=:id AND company_id=:cid
            ");
            $st->execute(['id'=>$sub_id,'cid'=>$companyId]);
            $sub = $st->fetch();
            if (!$sub) throw new Exception('Subscription not found.');
            if ($sub['status'] !== 'active') throw new Exception('Only active subscriptions can be transferred.');
            if ((int)$sub['transferable'] !== 1) throw new Exception('This subscription is not transferable.');

            $st = $pdo->prepare("SELECT id FROM vehicles WHERE id=:id AND company_id=:cid");
            $st->execute(['id'=>$to_vehicle_id,'cid'=>$companyId]);
            if (!$st->fetchColumn()) throw new Exception('Invalid vehicle.');

            $fromVehicle = $sub['vehicle_id'];

            $pdo->prepare("UPDATE gps_subscriptions SET vehicle_id=:vid WHERE id=:id AND company_id=:cid")
                ->execute(['vid'=>$to_vehicle_id,'id'=>$sub_id,'cid'=>$companyId]);

            $pdo->prepare("
                INSERT INTO gps_transfers (company_id, subscription_id, from_vehicle_id, to_vehicle_id, notes)
                VALUES (:cid,:sid,:from,:to,'Transferred')
            ")->execute([
                'cid'=>$companyId,
                'sid'=>$sub_id,
                'from'=>$fromVehicle,
                'to'=>$to_vehicle_id
            ]);

            $success = "GPS transferred successfully.";
        }

        if ($action === 'cancel_subscription') {
            $sub_id = (int)($_POST['sub_id'] ?? 0);
            if ($sub_id <= 0) throw new Exception('Invalid subscription.');

            $st = $pdo->prepare("SELECT id, device_id FROM gps_subscriptions WHERE id=:id AND company_id=:cid");
            $st->execute(['id'=>$sub_id,'cid'=>$companyId]);
            $sub = $st->fetch();
            if (!$sub) throw new Exception('Subscription not found.');

            $pdo->prepare("
                UPDATE gps_subscriptions
                SET status='cancelled', cancelled_at=NOW()
                WHERE id=:id AND company_id=:cid
            ")->execute(['id'=>$sub_id,'cid'=>$companyId]);

            $pdo->prepare("UPDATE gps_devices SET status='available' WHERE id=:did AND company_id=:cid")
                ->execute(['did'=>$sub['device_id'],'cid'=>$companyId]);

            $success = "GPS subscription cancelled.";
        }
    }
} catch (Throwable $e) {
    $error = $e->getMessage();
}

/* =========================
   Fetch Data (مصححة)
   ========================= */

$stmt = $pdo->prepare("SELECT * FROM gps_providers WHERE company_id=:cid ORDER BY id DESC");
$stmt->execute(['cid' => $companyId]);
$providers = $stmt->fetchAll();

$stmt = $pdo->prepare("
    SELECT p.*, pr.name AS provider_name
    FROM gps_plans p
    JOIN gps_providers pr ON pr.id=p.provider_id
    WHERE p.company_id=:cid
    ORDER BY p.id DESC
");
$stmt->execute(['cid' => $companyId]);
$plans = $stmt->fetchAll();

$stmt = $pdo->prepare("
    SELECT d.*, pr.name AS provider_name
    FROM gps_devices d
    JOIN gps_providers pr ON pr.id=d.provider_id
    WHERE d.company_id=:cid
    ORDER BY d.id DESC
");
$stmt->execute(['cid' => $companyId]);
$devices = $stmt->fetchAll();

$stmt = $pdo->prepare("
    SELECT id, brand, model, plate_number
    FROM vehicles
    WHERE company_id=:cid
    ORDER BY id DESC
");
$stmt->execute(['cid' => $companyId]);
$vehicles = $stmt->fetchAll();

$stmt = $pdo->prepare("
    SELECT s.*,
           d.device_uid,
           d.label AS device_label,
           pr.name AS provider_name,
           pl.name AS plan_name,
           pl.billing_cycle,
           pl.duration_months,
           pl.currency,
           v.brand AS v_brand,
           v.model AS v_model,
           v.plate_number AS v_plate
    FROM gps_subscriptions s
    JOIN gps_devices d ON d.id=s.device_id
    JOIN gps_plans pl ON pl.id=s.plan_id
    JOIN gps_providers pr ON pr.id=pl.provider_id
    LEFT JOIN vehicles v ON v.id=s.vehicle_id
    WHERE s.company_id=:cid
    ORDER BY s.id DESC
");
$stmt->execute(['cid' => $companyId]);
$subs = $stmt->fetchAll();

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-md-10 p-4 ultra-page">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <h3 class="fw-bold mb-1">GPS Management</h3>
            <p class="text-muted mb-0">Manage providers, plans, devices and subscriptions easily</p>
        </div>
        <div class="d-flex gap-2">
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProviderModal">
                <i class="bi bi-building-add me-2"></i>Add Provider
            </button>
            <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#addPlanModal">
                <i class="bi bi-calendar-plus me-2"></i>Add Plan
            </button>
            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#addDeviceModal">
                <i class="bi bi-device-ssd me-2"></i>Add Device
            </button>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm">
            <i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($success) ?>
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show shadow-sm">
            <i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($error) ?>
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-4" id="gpsTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#providers" type="button">Providers</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#plans" type="button">Plans</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#devices" type="button">Devices</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" data-bs-toggle="tab" data-bs-target="#subscriptions" type="button">Subscriptions</button>
        </li>
    </ul>

    <div class="tab-content" id="gpsTabContent">
        <!-- Providers Tab -->
        <div class="tab-pane fade show active" id="providers">
            <div class="row g-4">
                <?php foreach ($providers as $pr): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card shadow-sm hover-lift h-100">
                            <div class="card-body">
                                <h5 class="card-title fw-bold"><?= htmlspecialchars($pr['name']) ?></h5>
                                <p class="card-text">
                                    <span class="badge <?= $pr['status'] === 'active' ? 'bg-success' : 'bg-secondary' ?> mb-2"><?= htmlspecialchars($pr['status']) ?></span><br>
                                    <strong>Phone:</strong> <?= htmlspecialchars($pr['phone'] ?? '—') ?><br>
                                    <strong>Email:</strong> <?= htmlspecialchars($pr['support_email'] ?? '—') ?><br>
                                    <strong>WhatsApp:</strong> <?= htmlspecialchars($pr['support_whatsapp'] ?? '—') ?>
                                </p>
                                <?php if (!empty($pr['notes'])): ?>
                                    <p class="small text-muted"><em><?= htmlspecialchars($pr['notes']) ?></em></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <?php if (empty($providers)): ?>
                    <div class="col-12 text-center py-5">
                        <i class="bi bi-building display-1 text-muted opacity-50"></i>
                        <h5 class="mt-3 text-muted">No providers added yet</h5>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Plans Tab -->
        <div class="tab-pane fade" id="plans">
            <div class="row g-4">
                <?php foreach ($plans as $pl): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card shadow-sm hover-lift h-100">
                            <div class="card-body">
                                <h5 class="card-title fw-bold"><?= htmlspecialchars($pl['name']) ?></h5>
                                <p class="card-text">
                                    <strong>Provider:</strong> <?= htmlspecialchars($pl['provider_name']) ?><br>
                                    <strong>Cycle:</strong> <?= htmlspecialchars(ucfirst($pl['billing_cycle'])) ?><br>
                                    <strong>Price:</strong> <?= number_format((float)$pl['price'], 2) ?> <?= htmlspecialchars($pl['currency']) ?>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <?php if (empty($plans)): ?>
                    <div class="col-12 text-center py-5">
                        <i class="bi bi-calendar3 display-1 text-muted opacity-50"></i>
                        <h5 class="mt-3 text-muted">No plans added yet</h5>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Devices Tab -->
        <div class="tab-pane fade" id="devices">
            <div class="row g-4">
                <?php foreach ($devices as $d): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card shadow-sm hover-lift h-100">
                            <div class="card-body">
                                <h5 class="card-title fw-bold"><?= htmlspecialchars($d['device_uid']) ?></h5>
                                <p class="card-text">
                                    <strong>Provider:</strong> <?= htmlspecialchars($d['provider_name']) ?><br>
                                    <strong>Status:</strong> 
                                    <span class="badge <?= $d['status'] === 'available' ? 'bg-success' : ($d['status'] === 'assigned' ? 'bg-primary' : 'bg-secondary') ?>">
                                        <?= htmlspecialchars(ucfirst($d['status'])) ?>
                                    </span><br>
                                    <?php if (!empty($d['label'])): ?>
                                        <strong>Label:</strong> <?= htmlspecialchars($d['label']) ?>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <?php if (empty($devices)): ?>
                    <div class="col-12 text-center py-5">
                        <i class="bi bi-device-ssd display-1 text-muted opacity-50"></i>
                        <h5 class="mt-3 text-muted">No devices added yet</h5>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Subscriptions Tab -->
        <div class="tab-pane fade" id="subscriptions">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">Create New Subscription</h5>
                </div>
                <div class="card-body">
                    <form method="post" class="row g-3">
                        <input type="hidden" name="_csrf" value="<?= htmlspecialchars($CSRF) ?>">
                        <input type="hidden" name="action" value="assign_subscription">
                        <div class="col-md-3">
                            <label class="form-label">Device *</label>
                            <select class="form-select" name="device_id" required>
                                <option value="">Choose...</option>
                                <?php foreach ($devices as $d): ?>
                                    <option value="<?= (int)$d['id'] ?>"><?= htmlspecialchars($d['device_uid']) ?> (<?= htmlspecialchars($d['provider_name']) ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Plan *</label>
                            <select class="form-select" name="plan_id" required>
                                <option value="">Choose...</option>
                                <?php foreach ($plans as $pl): ?>
                                    <option value="<?= (int)$pl['id'] ?>"><?= htmlspecialchars($pl['name']) ?> — <?= htmlspecialchars($pl['billing_cycle']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Vehicle</label>
                            <select class="form-select" name="vehicle_id">
                                <option value="0">Detached</option>
                                <?php foreach ($vehicles as $v): ?>
                                    <option value="<?= (int)$v['id'] ?>"><?= htmlspecialchars($v['brand'] . ' ' . $v['model'] . ' — ' . $v['plate_number']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Start Date *</label>
                            <input type="date" name="start_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button class="btn btn-success w-100">Create</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="row g-4">
                <?php foreach ($subs as $s):
                    $days = days_remaining($s['end_date']);
                    [$bg, $label] = remaining_badge($days);
                    $vehicle = $s['vehicle_id'] ? htmlspecialchars($s['v_brand'] . ' ' . $s['v_model'] . ' — ' . $s['v_plate']) : '<span class="text-muted">Detached</span>';
                ?>
                    <div class="col-md-6 col-xl-4">
                        <div class="card h-100 shadow-sm hover-lift">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h6 class="mb-0">#<?= (int)$s['id'] ?></h6>
                                <span class="badge <?= $bg ?> fs-6"><?= $label ?></span>
                            </div>
                            <div class="card-body">
                                <p class="mb-2">
                                    <strong>Provider:</strong> <?= htmlspecialchars($s['provider_name']) ?><br>
                                    <strong>Plan:</strong> <?= htmlspecialchars($s['plan_name']) ?> (<?= htmlspecialchars($s['billing_cycle']) ?>)<br>
                                    <strong>Device:</strong> <?= htmlspecialchars($s['device_uid']) ?>
                                    <?php if (!empty($s['device_label'])): ?> <small>(<?= htmlspecialchars($s['device_label']) ?>)</small><?php endif; ?>
                                </p>
                                <p class="mb-2">
                                    <strong>Vehicle:</strong> <?= $vehicle ?><br>
                                    <strong>Period:</strong> <?= htmlspecialchars($s['start_date']) ?> → <?= htmlspecialchars($s['end_date']) ?><br>
                                    <strong>Paid:</strong> <?= number_format((float)$s['price_paid'], 2) ?> MAD
                                </p>
                                <div class="mt-3">
                                    <span class="badge <?= $s['status'] === 'active' ? 'bg-primary' : 'bg-secondary' ?>">
                                        <?= htmlspecialchars(ucfirst($s['status'])) ?>
                                    </span>
                                    <?php if ((int)$s['transferable'] === 1): ?>
                                        <span class="badge bg-info text-dark ms-1">Transferable</span>
                                    <?php endif; ?>
                                </div>
                                <div class="mt-3 d-flex gap-2">
                                    <?php if ($s['status'] === 'active' && (int)$s['transferable'] === 1): ?>
                                        <form method="post" class="flex-fill">
                                            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($CSRF) ?>">
                                            <input type="hidden" name="action" value="detach_subscription">
                                            <input type="hidden" name="sub_id" value="<?= (int)$s['id'] ?>">
                                            <button class="btn btn-outline-secondary btn-sm w-100" onclick="return confirm('Detach from vehicle?')">Detach</button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if ($s['status'] === 'active'): ?>
                                        <form method="post" class="flex-fill">
                                            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($CSRF) ?>">
                                            <input type="hidden" name="action" value="cancel_subscription">
                                            <input type="hidden" name="sub_id" value="<?= (int)$s['id'] ?>">
                                            <button class="btn btn-outline-danger btn-sm w-100" onclick="return confirm('Cancel subscription?')">Cancel</button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if ($s['status'] === 'active' && (int)$s['transferable'] === 1): ?>
                                        <form method="post" class="flex-fill">
                                            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($CSRF) ?>">
                                            <input type="hidden" name="action" value="transfer_subscription">
                                            <input type="hidden" name="sub_id" value="<?= (int)$s['id'] ?>">
                                            <select name="to_vehicle_id" class="form-select form-select-sm" required>
                                                <option value="">Transfer to...</option>
                                                <?php foreach ($vehicles as $v): ?>
                                                    <option value="<?= (int)$v['id'] ?>"><?= htmlspecialchars($v['brand'].' '.$v['model'].' — '.$v['plate_number']) ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button class="btn btn-outline-primary btn-sm mt-1 w-100">Transfer</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <?php if (empty($subs)): ?>
                    <div class="col-12 text-center py-5">
                        <i class="bi bi-router display-1 text-muted opacity-50"></i>
                        <h5 class="mt-3 text-muted">No subscriptions yet</h5>
                        <p>Use the form above to create your first subscription</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modals for Adding -->
<!-- Add Provider Modal -->
<div class="modal fade" id="addProviderModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Add New GPS Provider</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="_csrf" value="<?= $CSRF ?>">
                    <input type="hidden" name="action" value="add_provider">
                    <div class="row g-3">
                        <div class="col-md-8"><input name="name" class="form-control" placeholder="Provider name *" required></div>
                        <div class="col-md-4"><select name="status" class="form-select"><option value="active">Active</option><option value="suspended">Suspended</option></select></div>
                        <div class="col-12"><input name="address" class="form-control" placeholder="Address"></div>
                        <div class="col-md-4"><input name="phone" class="form-control" placeholder="Phone"></div>
                        <div class="col-md-4"><input name="support_phone" class="form-control" placeholder="Support phone"></div>
                        <div class="col-md-4"><input name="support_whatsapp" class="form-control" placeholder="WhatsApp"></div>
                        <div class="col-12"><input name="support_email" class="form-control" placeholder="Support email"></div>
                        <div class="col-12"><textarea name="notes" class="form-control" rows="3" placeholder="Notes"></textarea></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Provider</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Plan Modal -->
<div class="modal fade" id="addPlanModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title">Add New GPS Plan</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="_csrf" value="<?= $CSRF ?>">
                    <input type="hidden" name="action" value="add_plan">
                    <div class="mb-3">
                        <select name="provider_id" class="form-select" required>
                            <option value="">Choose provider...</option>
                            <?php foreach ($providers as $pr): ?>
                                <option value="<?= (int)$pr['id'] ?>"><?= htmlspecialchars($pr['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3"><input name="name" class="form-control" placeholder="Plan name" required></div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <select name="billing_cycle" class="form-select">
                                <option value="monthly">Monthly</option>
                                <option value="semiannual">Semiannual</option>
                                <option value="yearly">Yearly</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <input name="price" type="number" step="0.01" class="form-control" placeholder="Price">
                        </div>
                    </div>
                    <div class="mt-3"><input name="currency" class="form-control" value="MAD"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-info">Add Plan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Device Modal -->
<div class="modal fade" id="addDeviceModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title">Add New GPS Device</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="_csrf" value="<?= $CSRF ?>">
                    <input type="hidden" name="action" value="add_device">
                    <div class="mb-3">
                        <select name="provider_id" class="form-select" required>
                            <option value="">Choose provider...</option>
                            <?php foreach ($providers as $pr): ?>
                                <option value="<?= (int)$pr['id'] ?>"><?= htmlspecialchars($pr['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3"><input name="device_uid" class="form-control" placeholder="IMEI / Serial *" required></div>
                    <div class="mb-3"><input name="label" class="form-control" placeholder="Label (optional)"></div>
                    <div class="mb-3">
                        <select name="status" class="form-select">
                            <option value="available">Available</option>
                            <option value="assigned">Assigned</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                    <div class="mb-3"><textarea name="notes" class="form-control" rows="2" placeholder="Notes"></textarea></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">Add Device</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.hover-lift {
    transition: all 0.3s ease;
}
.hover-lift:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.15) !important;
}
.bg-orange {
    background-color: #fd7e14 !important;
}
</style>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>