<?php
// public/gps_notify.php
// Creates GPS notifications into `notifications` table (D7 / D3 / EXPIRED).
// Run daily (Task Scheduler / Cron).

require_once __DIR__ . '/../config/config.php';

date_default_timezone_set('Africa/Casablanca');
$today = date('Y-m-d');

// Optional token protection
$SECRET = 'CHANGE_ME_SECRET';
if (!isset($_GET['token']) || $_GET['token'] !== $SECRET) {
    http_response_code(403);
    die('Forbidden');
}

function insert_notification(PDO $pdo, int $companyId, string $type, string $refKey, array $data): void
{
    $pdo->prepare("
        INSERT IGNORE INTO notifications (company_id, type, ref_key, data, is_read, created_at)
        VALUES (:cid, :type, :ref, :data, 0, NOW())
    ")->execute([
        'cid'  => $companyId,
        'type' => $type,
        'ref'  => $refKey,
        'data' => json_encode($data, JSON_UNESCAPED_UNICODE),
    ]);
}

// شركات عندها GPS subscriptions
$companies = $pdo->query("SELECT DISTINCT company_id FROM gps_subscriptions")->fetchAll(PDO::FETCH_COLUMN);

$created = 0;

foreach ($companies as $companyId) {
    $companyId = (int)$companyId;

    // 1) D7 + D3 (نشوف شحال باقي)
    $st = $pdo->prepare("
        SELECT
            s.id AS subscription_id,
            s.vehicle_id,
            s.end_date,
            d.device_uid,
            v.brand, v.model, v.plate_number
        FROM gps_subscriptions s
        JOIN gps_devices d ON d.id = s.device_id
        LEFT JOIN vehicles v ON v.id = s.vehicle_id
        WHERE s.company_id = :cid
          AND s.status = 'active'
    ");
    $st->execute(['cid' => $companyId]);

    while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
        $end = $r['end_date'];
        if (!$end) continue;

        $daysLeft = (int) floor((strtotime($end) - strtotime($today)) / 86400);

        $vehicleLabel = (!empty($r['plate_number']))
            ? trim(($r['brand'] ?? '').' '.($r['model'] ?? '')).' ('.$r['plate_number'].')'
            : 'Detached (no vehicle)';

        // D7
        if ($daysLeft === 7) {
            $type = 'gps_expiring_7';
            $ref  = "gps:D7:{$r['subscription_id']}:{$today}";
            $data = [
                'subscription_id' => (int)$r['subscription_id'],
                'vehicle_id'      => $r['vehicle_id'] ? (int)$r['vehicle_id'] : null,
                'vehicle'         => $vehicleLabel,
                'plate_number'    => $r['plate_number'] ?? null,
                'device_uid'      => $r['device_uid'] ?? null,
                'end_date'        => $end,
                'days_left'       => 7
            ];
            insert_notification($pdo, $companyId, $type, $ref, $data);
            $created++;
        }

        // D3
        if ($daysLeft === 3) {
            $type = 'gps_expiring_3';
            $ref  = "gps:D3:{$r['subscription_id']}:{$today}";
            $data = [
                'subscription_id' => (int)$r['subscription_id'],
                'vehicle_id'      => $r['vehicle_id'] ? (int)$r['vehicle_id'] : null,
                'vehicle'         => $vehicleLabel,
                'plate_number'    => $r['plate_number'] ?? null,
                'device_uid'      => $r['device_uid'] ?? null,
                'end_date'        => $end,
                'days_left'       => 3
            ];
            insert_notification($pdo, $companyId, $type, $ref, $data);
            $created++;
        }

        // EXPIRED (إذا سالا)
        if ($daysLeft < 0) {
            $type = 'gps_expired';
            $ref  = "gps:EXP:{$r['subscription_id']}:{$today}";
            $data = [
                'subscription_id' => (int)$r['subscription_id'],
                'vehicle_id'      => $r['vehicle_id'] ? (int)$r['vehicle_id'] : null,
                'vehicle'         => $vehicleLabel,
                'plate_number'    => $r['plate_number'] ?? null,
                'device_uid'      => $r['device_uid'] ?? null,
                'end_date'        => $end,
                'days_left'       => $daysLeft
            ];
            insert_notification($pdo, $companyId, $type, $ref, $data);
            $created++;

            // Recommended: حدث status ديال subscription
            $pdo->prepare("UPDATE gps_subscriptions SET status='expired', updated_at=NOW() WHERE id=:id")
                ->execute(['id' => (int)$r['subscription_id']]);
        }
    }
}

echo "OK - GPS notifications inserted/checked: {$created}";
