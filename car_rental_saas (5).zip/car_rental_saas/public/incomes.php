<?php
// public/incomes.php - Professional Dashboard Design (Like Image #2)

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';

$page_title = 'Incomes Dashboard';

$companyId = current_company_id();
if (!$companyId) {
    die('Company ID not found.');
}

$types = [
    'rental'  => 'Rental Income',
    'penalty' => 'Penalty / Fine',
    'other'   => 'Other Revenue',
];

$errors = [];
$success = flash('success');
$errorMsg = flash('error');

/** Load bookings */
$stmt = $pdo->prepare("SELECT id, reference FROM bookings WHERE company_id = :cid ORDER BY id DESC");
$stmt->execute(['cid' => $companyId]);
$bookings = $stmt->fetchAll();

/** Handle POST */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['_csrf'] ?? '';
    if (!csrf_verify($csrf)) {
        $errors[] = 'Invalid CSRF token.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'create') {
            $booking_id  = (int)($_POST['booking_id'] ?? 0);
            $amount      = (float)($_POST['amount'] ?? 0);
            $type        = $_POST['type'] ?? 'rental';
            $date        = $_POST['date'] ?? '';
            $description = trim($_POST['description'] ?? '');

            if ($amount <= 0) $errors[] = 'Amount must be greater than 0';
            if (empty($date)) $errors[] = 'Date is required';
            if (!array_key_exists($type, $types)) $type = 'other';
            $booking_id = $booking_id > 0 ? $booking_id : null;

            if (!$errors) {
                $stmt = $pdo->prepare("
                    INSERT INTO incomes (company_id, booking_id, amount, type, date, description)
                    VALUES (:cid, :bid, :amount, :type, :d, :desc)
                ");
                $stmt->execute([
                    'cid'    => $companyId,
                    'bid'    => $booking_id,
                    'amount' => $amount,
                    'type'   => $type,
                    'd'      => $date,
                    'desc'   => $description ?: null,
                ]);

                flash('success', 'Income added successfully.');
                redirect('incomes.php');
            }
        }

        if ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id <= 0) $errors[] = 'Invalid income ID';

            if (!$errors) {
                $stmt = $pdo->prepare("DELETE FROM incomes WHERE id = :id AND company_id = :cid LIMIT 1");
                $stmt->execute(['id' => $id, 'cid' => $companyId]);

                flash('success', 'Income deleted successfully.');
                redirect('incomes.php');
            }
        }
    }
}

/** Load incomes with booking reference */
$stmt = $pdo->prepare("
    SELECT i.*, b.reference
    FROM incomes i
    LEFT JOIN bookings b ON b.id = i.booking_id
    WHERE i.company_id = :cid
    ORDER BY i.date DESC, i.id DESC
");
$stmt->execute(['cid' => $companyId]);
$rows = $stmt->fetchAll();

/** Calculate totals */
$totalAll = 0;
$monthly = [];
foreach ($rows as $r) {
    $totalAll += (float)$r['amount'];
    $month = date('Y-m', strtotime($r['date']));
    $monthly[$month] = ($monthly[$month] ?? 0) + (float)$r['amount'];
}

// Sort months
ksort($monthly);
$chartLabels = json_encode(array_keys($monthly));
$chartData = json_encode(array_values($monthly));

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-md-10 p-4 ultra-page">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-1">Incomes Dashboard</h2>
            <p class="text-muted mb-0">Track all revenue streams: rentals, penalties, and extras</p>
        </div>
        <div class="text-end">
            <div class="small text-muted">Total Revenue</div>
            <h3 class="fw-bold text-success mb-0"><?= money_fmt($totalAll) ?></h3>
        </div>
    </div>

    <!-- Alerts -->
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-4 shadow-sm">
            <i class="bi bi-check-circle-fill me-2"></i><?= e($success) ?>
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($errorMsg || $errors): ?>
        <div class="alert alert-danger alert-dismissible fade show rounded-4 shadow-sm">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?= e($errorMsg) ?>
            <?php foreach ($errors as $er): ?><div><?= e($er) ?></div><?php endforeach; ?>
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Stats Cards -->
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm bg-gradient-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5 class="mb-1">Total Income</h5>
                            <h3 class="mb-0"><?= money_fmt($totalAll) ?></h3>
                        </div>
                        <i class="bi bi-cash-stack display-4 opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm bg-gradient-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5 class="mb-1">This Month</h5>
                            <h3 class="mb-0"><?= money_fmt($monthly[date('Y-m')] ?? 0) ?></h3>
                        </div>
                        <i class="bi bi-calendar-check display-4 opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm bg-gradient-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h5 class="mb-1">Transactions</h5>
                            <h3 class="mb-0"><?= count($rows) ?></h3>
                        </div>
                        <i class="bi bi-receipt display-4 opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Revenue Chart -->
    <div class="card shadow-sm mb-5 border-0">
        <div class="card-header bg-white border-0">
            <h5 class="mb-0">Revenue Trend (Monthly)</h5>
        </div>
        <div class="card-body">
            <canvas id="revenueChart" height="100"></canvas>
        </div>
    </div>

    <!-- Add Income + List -->
    <div class="row g-4">
        <!-- Add Income -->
        <div class="col-lg-4">
            <div class="card shadow-sm h-100 border-0">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="bi bi-plus-circle me-2"></i>Add New Income</h5>
                </div>
                <div class="card-body">
                    <form method="post">
                        <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                        <input type="hidden" name="action" value="create">

                        <div class="mb-3">
                            <label class="form-label">Booking (optional)</label>
                            <select name="booking_id" class="form-select">
                                <option value="0">— No booking —</option>
                                <?php foreach ($bookings as $b): ?>
                                    <option value="<?= (int)$b['id'] ?>"><?= e($b['reference']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Type</label>
                            <select name="type" class="form-select" required>
                                <?php foreach ($types as $k => $lbl): ?>
                                    <option value="<?= $k ?>"><?= $lbl ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="row mb-3">
                            <div class="col-6">
                                <label class="form-label">Amount</label>
                                <input type="number" step="0.01" name="amount" class="form-control" required placeholder="0.00">
                            </div>
                            <div class="col-6">
                                <label class="form-label">Date</label>
                                <input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <input type="text" name="description" class="form-control" placeholder="e.g. Extra day, late fee">
                        </div>

                        <button class="btn btn-primary w-100">Add Income</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Incomes List -->
        <div class="col-lg-8">
            <div class="card shadow-sm h-100 border-0">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Incomes</h5>
                    <span class="badge bg-light text-dark"><?= count($rows) ?> records</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th>Date</th>
                                    <th>Type</th>
                                    <th>Booking</th>
                                    <th class="text-end">Amount</th>
                                    <th>Description</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($rows)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-5">
                                            <i class="bi bi-inbox display-4"></i>
                                            <div class="mt-3">No income records yet</div>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($rows as $r):
                                        $typeColor = $r['type'] === 'rental' ? 'bg-success' : ($r['type'] === 'penalty' ? 'bg-danger' : 'bg-secondary');
                                    ?>
                                        <tr>
                                            <td><strong><?= date('d M Y', strtotime($r['date'])) ?></strong></td>
                                            <td><span class="badge <?= $typeColor ?>"><?= e($types[$r['type']] ?? ucfirst($r['type'])) ?></span></td>
                                            <td class="text-muted"><?= e($r['reference'] ?? '—') ?></td>
                                            <td class="text-end fw-bold"><?= money_fmt($r['amount']) ?></td>
                                            <td><?= e($r['description'] ?: '—') ?></td>
                                            <td>
                                                <form method="post" onsubmit="return confirm('Delete this income?')">
                                                    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                                    <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const ctx = document.getElementById('revenueChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= $chartLabels ?>,
            datasets: [{
                label: 'Monthly Revenue',
                data: <?= $chartData ?>,
                borderColor: '#4f46e5',
                backgroundColor: 'rgba(79, 70, 229, 0.1)',
                tension: 0.4,
                fill: true,
                pointBackgroundColor: '#4f46e5',
                pointRadius: 5
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'top' },
                tooltip: { mode: 'index', intersect: false }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
});
</script>

<style>
.bg-gradient-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}
.bg-gradient-success {
    background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}
.bg-gradient-info {
    background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
}
.hover-lift {
    transition: all 0.3s ease;
}
.hover-lift:hover {
    transform: translateY(-10px);
    box-shadow: 0 25px 50px rgba(0,0,0,0.15) !important;
}
</style>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>