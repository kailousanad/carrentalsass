<?php
// public/index.php  (ULTRA Dashboard + Charts) + Bank Installments Integration

require_once __DIR__ . '/../includes/auth.php';
require_login();

require_once __DIR__ . '/../config/config.php';

$page_title = 'Dashboard – Car Rental SaaS (ULTRA)';
$companyId = current_company_id();

/**
 * Fallback for e() if not defined in your project
 */
if (!function_exists('e')) {
    function e($v): string {
        return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    }
}

// ---------------------- CRONS (once/day per session) ----------------------

// Run insurance cron once per day per session
if (!empty($companyId) && (!isset($_SESSION['insurance_cron_ran']) || $_SESSION['insurance_cron_ran'] !== date('Y-m-d'))) {
    $_SESSION['insurance_cron_ran'] = date('Y-m-d');
    @include __DIR__ . '/cron_insurance.php';
}

// Run installments cron once per day per session (NEW)
if (!empty($companyId) && (!isset($_SESSION['installments_cron_ran']) || $_SESSION['installments_cron_ran'] !== date('Y-m-d'))) {
    $_SESSION['installments_cron_ran'] = date('Y-m-d');
    @include __DIR__ . '/cron_installments.php';
}

function safeFetchColumn(PDO $pdo, string $sql, array $params = [], $default = 0) {
    try {
        $st = $pdo->prepare($sql);
        $st->execute($params);
        $v = $st->fetchColumn();
        return ($v !== false && $v !== null) ? $v : $default;
    } catch (Throwable $e) {
        return $default;
    }
}

function safeFetchAll(PDO $pdo, string $sql, array $params = []): array {
    try {
        $st = $pdo->prepare($sql);
        $st->execute($params);
        return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        return [];
    }
}

function colExists(PDO $pdo, string $table, string $column): bool {
    try {
        $st = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE :c");
        $st->execute(['c' => $column]);
        return (bool)$st->fetch(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        return false;
    }
}

function tableExists(PDO $pdo, string $table): bool {
    try {
        $st = $pdo->prepare("SHOW TABLES LIKE :t");
        $st->execute(['t' => $table]);
        return (bool)$st->fetchColumn();
    } catch (Throwable $e) {
        return false;
    }
}

function pct(float $num, float $den, int $dec = 0): float {
    if ($den <= 0) return 0;
    return round(($num / $den) * 100, $dec);
}

// Helper for installments due date calc (NEW)
function dueDateFromDay(string $ym, int $dueDay): string {
    // $ym: YYYY-MM
    $first = strtotime($ym . '-01');
    if (!$first) return $ym . '-01';
    $daysInMonth = (int)date('t', $first);
    $d = max(1, min($dueDay, $daysInMonth));
    return date('Y-m-d', strtotime($ym . '-' . str_pad((string)$d, 2, '0', STR_PAD_LEFT)));
}

function nextInstallmentDueDate(int $dueDay): string {
    // returns next due date from today (this month or next)
    $today = date('Y-m-d');
    $ymThis = date('Y-m');
    $ymNext = date('Y-m', strtotime('+1 month'));
    $dueThis = dueDateFromDay($ymThis, $dueDay);
    if ($dueThis >= $today) return $dueThis;
    return dueDateFromDay($ymNext, $dueDay);
}

// ---------------------- Super Admin view ----------------------
if (is_super_admin()) {
    require_once __DIR__ . '/../templates/header.php';
    require_once __DIR__ . '/../templates/sidebar.php';
    ?>

    <main class="col-12 col-lg-10 ultra-main">
      <div class="ultra-topbar">
        <div class="ultra-topbar__left">
          <div>
            <div class="ultra-title">Super Admin</div>
            <div class="ultra-subtitle">Vue globale sur les agences • Gestion & supervision</div>
          </div>
        </div>
        <div class="ultra-topbar__right">
          <a class="ultra-btn ultra-btn--primary" href="companies.php"><i class="bi bi-buildings"></i> Agences</a>
          <a class="ultra-btn ultra-btn--soft" href="users.php"><i class="bi bi-people"></i> Utilisateurs</a>
          <a class="ultra-btn ultra-btn--soft" href="vehicles.php"><i class="bi bi-car-front"></i> Véhicules</a>
          <a class="ultra-btn ultra-btn--soft" href="statistics.php"><i class="bi bi-graph-up"></i> Stats</a>
        </div>
      </div>

      <div class="ultra-grid">
        <div class="ultra-col">
          <div class="ultra-card">
            <div class="ultra-card__head">
              <div>
                <div class="ultra-card__title">Administration</div>
                <div class="ultra-card__hint">Accès rapide aux modules clés</div>
              </div>
              <span class="ultra-chip"><i class="bi bi-shield-check me-1"></i> Super Admin</span>
            </div>
            <div class="ultra-card__body">
              <div class="row g-3">

                <div class="col-md-6 col-xl-4">
                  <div class="card shadow-sm h-100">
                    <div class="card-body">
                      <div class="d-flex align-items-start justify-content-between">
                        <div>
                          <div class="fw-bold">Agences</div>
                          <div class="text-muted small">Entreprises, abonnements, accès</div>
                        </div>
                        <span class="badge bg-primary-subtle text-primary border border-primary-subtle"><i class="bi bi-buildings"></i></span>
                      </div>
                      <div class="mt-3">
                        <a class="btn btn-sm btn-primary" href="companies.php">Gérer</a>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-6 col-xl-4">
                  <div class="card shadow-sm h-100">
                    <div class="card-body">
                      <div class="d-flex align-items-start justify-content-between">
                        <div>
                          <div class="fw-bold">Utilisateurs</div>
                          <div class="text-muted small">Rôles, accès, sécurité</div>
                        </div>
                        <span class="badge bg-info-subtle text-info border border-info-subtle"><i class="bi bi-people"></i></span>
                      </div>
                      <div class="mt-3">
                        <a class="btn btn-sm btn-outline-dark" href="users.php">Ouvrir</a>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-6 col-xl-4">
                  <div class="card shadow-sm h-100">
                    <div class="card-body">
                      <div class="d-flex align-items-start justify-content-between">
                        <div>
                          <div class="fw-bold">Véhicules</div>
                          <div class="text-muted small">Parc, statut, maintenance</div>
                        </div>
                        <span class="badge bg-success-subtle text-success border border-success-subtle"><i class="bi bi-car-front"></i></span>
                      </div>
                      <div class="mt-3">
                        <a class="btn btn-sm btn-outline-dark" href="vehicles.php">Ouvrir</a>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-6 col-xl-4">
                  <div class="card shadow-sm h-100">
                    <div class="card-body">
                      <div class="d-flex align-items-start justify-content-between">
                        <div>
                          <div class="fw-bold">Statistiques</div>
                          <div class="text-muted small">Suivi global & reporting</div>
                        </div>
                        <span class="badge bg-warning-subtle text-warning border border-warning-subtle"><i class="bi bi-graph-up"></i></span>
                      </div>
                      <div class="mt-3">
                        <a class="btn btn-sm btn-outline-dark" href="statistics.php">Voir</a>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-6 col-xl-4">
                  <div class="card shadow-sm h-100">
                    <div class="card-body">
                      <div class="d-flex align-items-start justify-content-between">
                        <div>
                          <div class="fw-bold">Paramètres</div>
                          <div class="text-muted small">Configuration & règles</div>
                        </div>
                        <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle"><i class="bi bi-gear"></i></span>
                      </div>
                      <div class="mt-3">
                        <a class="btn btn-sm btn-outline-dark" href="settings.php">Ouvrir</a>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-6 col-xl-4">
                  <div class="card shadow-sm h-100">
                    <div class="card-body">
                      <div class="d-flex align-items-start justify-content-between">
                        <div>
                          <div class="fw-bold">Notifications</div>
                          <div class="text-muted small">Suivi des alertes</div>
                        </div>
                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle"><i class="bi bi-bell"></i></span>
                      </div>
                      <div class="mt-3">
                        <a class="btn btn-sm btn-outline-dark" href="notifications.php">Voir</a>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

              <div class="mt-3 ultra-empty ultra-empty--small">
                Astuce : commence par <strong>Agences</strong> pour gérer les abonnements et les accès.
              </div>
            </div>
          </div>
        </div>

        <div class="ultra-col ultra-col--right">
          <div class="ultra-card">
            <div class="ultra-card__head">
              <div>
                <div class="ultra-card__title">Raccourcis</div>
                <div class="ultra-card__hint">Actions fréquentes</div>
              </div>
            </div>
            <div class="ultra-card__body">
              <div class="d-grid gap-2">
                <a class="btn btn-primary" href="companies.php"><i class="bi bi-buildings me-2"></i>Gérer les agences</a>
                <a class="btn btn-outline-dark" href="users.php"><i class="bi bi-people me-2"></i>Gérer les utilisateurs</a>
                <a class="btn btn-outline-dark" href="vehicles.php"><i class="bi bi-car-front me-2"></i>Voir les véhicules</a>
                <a class="btn btn-outline-dark" href="statistics.php"><i class="bi bi-graph-up me-2"></i>Ouvrir les statistiques</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>

    <?php
    require_once __DIR__ . '/../templates/footer.php';
    exit;
}

if (!$companyId) die('Company ID not found in session.');

$now = date('Y-m-d H:i:s');
$today = date('Y-m-d');
$thisMonthStart = date('Y-m-01');
$thisMonthEnd = date('Y-m-t');

// Optional GPS tables
$hasGpsSubs = tableExists($pdo, 'gps_subscriptions');

// Optional installments table (NEW)
$hasInstallments = tableExists($pdo, 'vehicle_installments');

// ---------------------- KPIs ----------------------
$kpi = [
  'vehicles_total' => 0,
  'vehicles_in_park' => 0,
  'vehicles_on_rent' => 0,
  'vehicles_maintenance' => 0,

  'bookings_today' => 0,
  'bookings_active' => 0,
  'bookings_late' => 0,

  'revenue_month' => 0.0,
  'expenses_month' => 0.0,
  'profit_month' => 0.0,
  'unpaid_total' => 0.0,

  'unread_notifications' => 0,
];

// Vehicles
$kpi['vehicles_total'] = (int) safeFetchColumn($pdo, "SELECT COUNT(*) FROM vehicles WHERE company_id=:cid", ['cid'=>$companyId], 0);
$kpi['vehicles_in_park'] = (int) safeFetchColumn($pdo, "SELECT COUNT(*) FROM vehicles WHERE company_id=:cid AND status='in_park'", ['cid'=>$companyId], 0);
$kpi['vehicles_on_rent'] = (int) safeFetchColumn($pdo, "SELECT COUNT(*) FROM vehicles WHERE company_id=:cid AND status='on_rent'", ['cid'=>$companyId], 0);
$kpi['vehicles_maintenance'] = (int) safeFetchColumn($pdo, "SELECT COUNT(*) FROM vehicles WHERE company_id=:cid AND status='maintenance'", ['cid'=>$companyId], 0);

// Bookings
$kpi['bookings_today'] = (int) safeFetchColumn($pdo, "SELECT COUNT(*) FROM bookings WHERE company_id=:cid AND DATE(start_datetime)=:d", ['cid'=>$companyId,'d'=>$today], 0);
$kpi['bookings_active'] = (int) safeFetchColumn($pdo, "SELECT COUNT(*) FROM bookings WHERE company_id=:cid AND status IN ('ongoing','yet_to_start')", ['cid'=>$companyId], 0);
$kpi['bookings_late'] = (int) safeFetchColumn($pdo, "SELECT COUNT(*) FROM bookings WHERE company_id=:cid AND status IN ('ongoing','yet_to_start') AND end_datetime < :now", ['cid'=>$companyId,'now'=>$now], 0);

// Revenue / Expenses this month
$kpi['revenue_month'] = (float) safeFetchColumn($pdo, "
  SELECT COALESCE(SUM(amount),0)
  FROM incomes
  WHERE company_id=:cid
    AND date BETWEEN :s AND :e
", ['cid'=>$companyId,'s'=>$thisMonthStart,'e'=>$thisMonthEnd], 0);

$kpi['expenses_month'] = (float) safeFetchColumn($pdo, "
  SELECT COALESCE(SUM(amount),0)
  FROM expenses
  WHERE company_id=:cid
    AND date BETWEEN :s AND :e
", ['cid'=>$companyId,'s'=>$thisMonthStart,'e'=>$thisMonthEnd], 0);

$kpi['profit_month'] = (float)($kpi['revenue_month'] - $kpi['expenses_month']);

$kpi['unpaid_total'] = (float) safeFetchColumn($pdo, "
  SELECT COALESCE(SUM(GREATEST(COALESCE(total_price,0)-COALESCE(paid_amount,0),0)),0)
  FROM bookings
  WHERE company_id=:cid AND status <> 'cancelled'
", ['cid'=>$companyId], 0);

// Notifications
$kpi['unread_notifications'] = (int) safeFetchColumn($pdo, "
  SELECT COUNT(*) FROM notifications WHERE company_id=:cid AND is_read=0
", ['cid'=>$companyId], 0);

// ---------------------- Utilization (last 30 days) ----------------------
$rangeStart = date('Y-m-d 00:00:00', strtotime('-29 days'));
$rangeEnd   = date('Y-m-d 23:59:59');

$daysRange = 30;
$bookedDays = 0;

$bookedSegments = safeFetchAll($pdo, "
  SELECT start_datetime, end_datetime
  FROM bookings
  WHERE company_id=:cid
    AND status <> 'cancelled'
    AND end_datetime >= :rs
    AND start_datetime <= :re
", ['cid'=>$companyId,'rs'=>$rangeStart,'re'=>$rangeEnd]);

$rangeStartTs = strtotime($rangeStart);
$rangeEndTs   = strtotime($rangeEnd);

foreach ($bookedSegments as $seg) {
    $sd = strtotime((string)$seg['start_datetime']);
    $ed = strtotime((string)$seg['end_datetime']);
    if (!$sd || !$ed) continue;

    $a = max($sd, $rangeStartTs);
    $b = min($ed, $rangeEndTs);
    if ($b >= $a) $bookedDays += (int) round(($b-$a)/86400) + 1;
}
$capacity = max(1, $kpi['vehicles_total'] * $daysRange);
$utilization = pct($bookedDays, $capacity, 1);

// ---------------------- Lists ----------------------
$pickupsToday = safeFetchAll($pdo, "
  SELECT b.*, v.brand, v.model, v.plate_number,
         p1.name AS pickup_name, p2.name AS dropoff_name
  FROM bookings b
  JOIN vehicles v ON v.id=b.vehicle_id
  LEFT JOIN places p1 ON p1.id=b.pickup_place_id
  LEFT JOIN places p2 ON p2.id=b.dropoff_place_id
  WHERE b.company_id=:cid
    AND b.status IN ('ongoing','yet_to_start')
    AND DATE(b.start_datetime)=:d
  ORDER BY b.start_datetime ASC
  LIMIT 12
", ['cid'=>$companyId,'d'=>$today]);

$returnsToday = safeFetchAll($pdo, "
  SELECT b.*, v.brand, v.model, v.plate_number,
         p1.name AS pickup_name, p2.name AS dropoff_name
  FROM bookings b
  JOIN vehicles v ON v.id=b.vehicle_id
  LEFT JOIN places p1 ON p1.id=b.pickup_place_id
  LEFT JOIN places p2 ON p2.id=b.dropoff_place_id
  WHERE b.company_id=:cid
    AND b.status IN ('ongoing','yet_to_start')
    AND DATE(b.end_datetime)=:d
  ORDER BY b.end_datetime ASC
  LIMIT 12
", ['cid'=>$companyId,'d'=>$today]);

$lateReturns = safeFetchAll($pdo, "
  SELECT b.*, v.brand, v.model, v.plate_number
  FROM bookings b
  JOIN vehicles v ON v.id=b.vehicle_id
  WHERE b.company_id=:cid
    AND b.status IN ('ongoing','yet_to_start')
    AND b.end_datetime < :now
  ORDER BY b.end_datetime ASC
  LIMIT 12
", ['cid'=>$companyId,'now'=>$now]);

$paymentsDue = safeFetchAll($pdo, "
  SELECT b.*, v.brand, v.model, v.plate_number,
         (GREATEST(COALESCE(b.total_price,0)-COALESCE(b.paid_amount,0),0)) AS remaining
  FROM bookings b
  JOIN vehicles v ON v.id=b.vehicle_id
  WHERE b.company_id=:cid
    AND b.status <> 'cancelled'
    AND (COALESCE(b.total_price,0) - COALESCE(b.paid_amount,0)) > 0
  ORDER BY remaining DESC, b.id DESC
  LIMIT 10
", ['cid'=>$companyId]);

$insuranceSoon = safeFetchAll($pdo, "
  SELECT id, brand, model, plate_number, insurance_expiry_date
  FROM vehicles
  WHERE company_id=:cid
    AND insurance_expiry_date IS NOT NULL
    AND insurance_expiry_date BETWEEN :t AND DATE_ADD(:t, INTERVAL 30 DAY)
  ORDER BY insurance_expiry_date ASC
  LIMIT 10
", ['cid'=>$companyId,'t'=>$today]);

$maintSoon = safeFetchAll($pdo, "
  SELECT id, brand, model, plate_number, mileage_current, oil_change_next_at_km,
         (oil_change_next_at_km - mileage_current) AS remaining_km
  FROM vehicles
  WHERE company_id=:cid
    AND oil_change_next_at_km IS NOT NULL
    AND (oil_change_next_at_km - mileage_current) <= 500
  ORDER BY remaining_km ASC
  LIMIT 10
", ['cid'=>$companyId]);

$gpsSoon = [];
if ($hasGpsSubs && colExists($pdo, 'gps_subscriptions', 'end_date')) {
    $gpsSoon = safeFetchAll($pdo, "
      SELECT gs.*, v.brand, v.model, v.plate_number
      FROM gps_subscriptions gs
      LEFT JOIN vehicles v ON v.id=gs.vehicle_id
      WHERE gs.company_id=:cid
        AND gs.status='active'
        AND gs.end_date IS NOT NULL
        AND gs.end_date BETWEEN :t AND DATE_ADD(:t, INTERVAL 30 DAY)
      ORDER BY gs.end_date ASC
      LIMIT 10
    ", ['cid'=>$companyId,'t'=>$today]);
}

// --------- Installments soon (≤ 30 days) NEW ----------
$installmentsSoon = [];
$installments7 = [];

if ($hasInstallments) {
    $rawInst = safeFetchAll($pdo, "
      SELECT vi.*, v.brand, v.model, v.plate_number
      FROM vehicle_installments vi
      JOIN vehicles v ON v.id = vi.vehicle_id
      WHERE vi.company_id = :cid
        AND vi.status = 'active'
        AND vi.monthly_amount > 0
      ORDER BY vi.vehicle_id DESC
      LIMIT 200
    ", ['cid'=>$companyId]);

    $tTs = strtotime($today);
    foreach ($rawInst as $it) {
        $dueDay = (int)($it['due_day'] ?? 5);
        $due = nextInstallmentDueDate($dueDay);
        $dueTs = strtotime($due);
        if (!$dueTs) continue;

        $daysLeft = (int)floor(($dueTs - $tTs) / 86400);

        $row = $it;
        $row['due_date'] = $due;
        $row['days_left'] = $daysLeft;

        if ($daysLeft >= 0 && $daysLeft <= 30) $installmentsSoon[] = $row;
        if ($daysLeft >= 0 && $daysLeft <= 7)  $installments7[] = $row;
    }

    usort($installmentsSoon, fn($a,$b)=> ($a['days_left'] <=> $b['days_left']));
    usort($installments7, fn($a,$b)=> ($a['days_left'] <=> $b['days_left']));

    $installmentsSoon = array_slice($installmentsSoon, 0, 10);
    $installments7 = array_slice($installments7, 0, 10);
}

$latestNotifs = safeFetchAll($pdo, "
  SELECT id, type, data, is_read, created_at
  FROM notifications
  WHERE company_id=:cid
  ORDER BY id DESC
  LIMIT 8
", ['cid'=>$companyId]);

// ---------------------- Urgent modal ----------------------
$urgent = [
  'late_returns' => $lateReturns,
  'insurance_7'  => safeFetchAll($pdo, "
      SELECT id, brand, model, plate_number, insurance_expiry_date
      FROM vehicles
      WHERE company_id=:cid
        AND insurance_expiry_date IS NOT NULL
        AND insurance_expiry_date BETWEEN :t AND DATE_ADD(:t, INTERVAL 7 DAY)
      ORDER BY insurance_expiry_date ASC
      LIMIT 10
  ", ['cid'=>$companyId,'t'=>$today]),
  'tech_7'       => safeFetchAll($pdo, "
      SELECT id, brand, model, plate_number, technical_visit_expiry_date
      FROM vehicles
      WHERE company_id=:cid
        AND technical_visit_expiry_date IS NOT NULL
        AND technical_visit_expiry_date BETWEEN :t AND DATE_ADD(:t, INTERVAL 7 DAY)
      ORDER BY technical_visit_expiry_date ASC
      LIMIT 10
  ", ['cid'=>$companyId,'t'=>$today]),
  'payments_due' => $paymentsDue,
  'installments_7' => $installments7, // NEW
];

$hasUrgent =
  (count($urgent['late_returns']) > 0) ||
  (count($urgent['insurance_7']) > 0) ||
  (count($urgent['tech_7']) > 0) ||
  (count($urgent['payments_due']) > 0) ||
  (count($urgent['installments_7']) > 0);

// ---------------------- Charts data ----------------------

// Bookings last 7 days
$days7 = safeFetchAll($pdo, "
  SELECT DATE(start_datetime) AS d, COUNT(*) AS c
  FROM bookings
  WHERE company_id=:cid
    AND status <> 'cancelled'
    AND start_datetime >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
  GROUP BY DATE(start_datetime)
  ORDER BY d ASC
", ['cid'=>$companyId]);

$bookings7_map = [];
foreach ($days7 as $r) {
  $bookings7_map[(string)$r['d']] = (int)$r['c'];
}

$bookings7_labels = [];
$bookings7_values = [];
for ($i = 6; $i >= 0; $i--) {
  $d = date('Y-m-d', strtotime("-$i days"));
  $bookings7_labels[] = $d;
  $bookings7_values[] = $bookings7_map[$d] ?? 0;
}

// Revenue vs Expenses last 6 months
$months6 = safeFetchAll($pdo, "
  SELECT DATE_FORMAT(date, '%Y-%m') AS ym, COALESCE(SUM(amount),0) AS total
  FROM incomes
  WHERE company_id=:cid
    AND date >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
  GROUP BY ym
  ORDER BY ym ASC
", ['cid'=>$companyId]);

$months6_exp = safeFetchAll($pdo, "
  SELECT DATE_FORMAT(date, '%Y-%m') AS ym, COALESCE(SUM(amount),0) AS total
  FROM expenses
  WHERE company_id=:cid
    AND date >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
  GROUP BY ym
  ORDER BY ym ASC
", ['cid'=>$companyId]);

$rev_map = [];
foreach ($months6 as $r) $rev_map[(string)$r['ym']] = (float)$r['total'];

$exp_map[(string)$r['ym']] = (float)$r['total'];


$months6_labels = [];
$months6_rev = [];
$months6_expv = [];

for ($i = 5; $i >= 0; $i--) {
  $ym = date('Y-m', strtotime("-$i months"));
  $months6_labels[] = $ym;
  $months6_rev[] = $rev_map[$ym] ?? 0;
  $months6_expv[] = $exp_map[$ym] ?? 0;
}

// Vehicles status distribution
$vehStatus = safeFetchAll($pdo, "
  SELECT status, COUNT(*) AS c
  FROM vehicles
  WHERE company_id=:cid
  GROUP BY status
", ['cid'=>$companyId]);

$status_map = [
  'in_park' => 0,
  'on_rent' => 0,
  'maintenance' => 0,
  'sold' => 0,
];
foreach ($vehStatus as $r) {
  $s = (string)$r['status'];
  if (!isset($status_map[$s])) $status_map[$s] = 0;
  $status_map[$s] = (int)$r['c'];
}

$veh_labels = ['In park','On rent','Maintenance','Sold'];
$veh_values = [
  (int)$status_map['in_park'],
  (int)$status_map['on_rent'],
  (int)$status_map['maintenance'],
  (int)$status_map['sold'],
];

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<style>
/* ===== ULTRA small additions for charts layout (safe) ===== */
.ultra-row2{
  display:grid;
  grid-template-columns: 1.4fr .9fr;
  gap:16px;
}
.ultra-card2{
  background: var(--bs-body-bg, #fff);
  border: 1px solid rgba(0,0,0,.06);
  border-radius: 18px;
  box-shadow: 0 12px 30px rgba(0,0,0,.06);
  overflow:hidden;
}
.ultra-card2 .head{
  padding:14px 16px;
  display:flex;
  align-items:center;
  justify-content:space-between;
  border-bottom:1px solid rgba(0,0,0,.06);
}
.ultra-card2 .t{font-weight:700;}
.ultra-card2 .s{font-size:.85rem; color: rgba(0,0,0,.55);}
.ultra-card2 .body{padding:14px 16px;}
@media (max-width: 992px){
  .ultra-row2{grid-template-columns: 1fr;}
}
</style>

<main class="col-12 col-lg-10 ultra-main">

  <div class="ultra-topbar">
    <div class="ultra-topbar__left">
      <div>
        <div class="ultra-title">Agency Dashboard</div>
        <div class="ultra-subtitle">Agence ID: <?= e((string)$companyId) ?> • Today: <?= e((string)$today) ?></div>
      </div>
    </div>

    <div class="ultra-topbar__right">
      <a href="booking_create.php" class="ultra-btn ultra-btn--primary">
        <i class="bi bi-calendar2-plus"></i> New booking
      </a>
      <a href="vehicles.php" class="ultra-btn ultra-btn--soft">
        <i class="bi bi-car-front"></i> Vehicles
      </a>
      <a href="expenses.php" class="ultra-btn ultra-btn--soft">
        <i class="bi bi-receipt"></i> Expenses
      </a>
      <a href="notifications.php" class="ultra-btn ultra-btn--soft ultra-bell">
        <i class="bi bi-bell"></i> Notifications
        <?php if ($kpi['unread_notifications'] > 0): ?>
          <span class="ultra-badge"><?= (int)$kpi['unread_notifications'] ?></span>
        <?php endif; ?>
      </a>

      <?php if ($hasUrgent): ?>
        <a href="#" class="ultra-btn ultra-btn--soft" data-bs-toggle="modal" data-bs-target="#urgentModal">
          <i class="bi bi-exclamation-triangle"></i> Urgent
        </a>
      <?php endif; ?>
    </div>
  </div>

  <!-- KPIs -->
  <section class="ultra-kpis">
    <div class="ultra-kpi">
      <div class="ultra-kpi__meta">
        <div class="ultra-kpi__label">Vehicles</div>
        <div class="ultra-kpi__value"><?= (int)$kpi['vehicles_total'] ?>
          <span>Total</span>
        </div>
        <div class="ultra-kpi__pills">
          <span class="ultra-pill">In park: <?= (int)$kpi['vehicles_in_park'] ?></span>
          <span class="ultra-pill">On rent: <?= (int)$kpi['vehicles_on_rent'] ?></span>
          <?php if ((int)$kpi['vehicles_maintenance'] > 0): ?>
            <span class="ultra-pill">Maintenance: <?= (int)$kpi['vehicles_maintenance'] ?></span>
          <?php endif; ?>
        </div>
      </div>
      <div class="ultra-kpi__icon is-blue"><i class="bi bi-car-front"></i></div>
    </div>

    <div class="ultra-kpi">
      <div class="ultra-kpi__meta">
        <div class="ultra-kpi__label">Bookings</div>
        <div class="ultra-kpi__value"><?= (int)$kpi['bookings_active'] ?><span>Active</span></div>
        <div class="ultra-kpi__sub">
          Today: <?= (int)$kpi['bookings_today'] ?> • Late: <?= (int)$kpi['bookings_late'] ?>
        </div>
        <div class="ultra-kpi__pills">
          <span class="ultra-pill">Pickups: <?= count($pickupsToday) ?></span>
          <span class="ultra-pill">Returns: <?= count($returnsToday) ?></span>
        </div>
      </div>
      <div class="ultra-kpi__icon is-purple"><i class="bi bi-calendar-check"></i></div>
    </div>

    <div class="ultra-kpi">
      <div class="ultra-kpi__meta">
        <div class="ultra-kpi__label">This month</div>
        <div class="ultra-kpi__value"><?= number_format((float)$kpi['profit_month'], 2) ?><span>MAD</span></div>
        <div class="ultra-kpi__sub">
          Revenue: <?= number_format((float)$kpi['revenue_month'], 2) ?> • Expenses: <?= number_format((float)$kpi['expenses_month'], 2) ?>
        </div>
        <div class="ultra-kpi__pills">
          <span class="ultra-pill">Utilization: <?= e((string)$utilization) ?>%</span>
        </div>
      </div>
      <div class="ultra-kpi__icon is-green"><i class="bi bi-cash-coin"></i></div>
    </div>

    <div class="ultra-kpi">
      <div class="ultra-kpi__meta">
        <div class="ultra-kpi__label">Unpaid</div>
        <div class="ultra-kpi__value"><?= number_format((float)$kpi['unpaid_total'], 2) ?><span>MAD</span></div>
        <div class="ultra-kpi__sub">Payments due (top 10)</div>
        <div class="ultra-kpi__pills">
          <span class="ultra-pill"><?= count($paymentsDue) ?> bookings</span>
        </div>
      </div>
      <div class="ultra-kpi__icon is-orange"><i class="bi bi-exclamation-circle"></i></div>
    </div>
  </section>

  <!-- CHARTS -->
  <section class="ultra-row2 mb-3">
    <div class="ultra-card2">
      <div class="head">
        <div>
          <div class="t">Bookings (Last 7 days)</div>
          <div class="s">Trend of reservations</div>
        </div>
        <a class="ultra-link" href="bookings.php">Open</a>
      </div>
      <div class="body">
        <canvas id="chartBookings7" height="110"></canvas>
      </div>
    </div>

    <div class="ultra-card2">
      <div class="head">
        <div>
          <div class="t">Fleet distribution</div>
          <div class="s">Vehicles by status</div>
        </div>
        <a class="ultra-link" href="vehicles.php">Vehicles</a>
      </div>
      <div class="body">
        <canvas id="chartFleet" height="140"></canvas>
      </div>
    </div>
  </section>

  <section class="ultra-card2 mb-3">
    <div class="head">
      <div>
        <div class="t">Revenue vs Expenses (Last 6 months)</div>
        <div class="s">Financial overview</div>
      </div>
      <a class="ultra-link" href="statistics.php">Stats</a>
    </div>
    <div class="body">
      <canvas id="chartFinance" height="90"></canvas>
    </div>
  </section>

  <!-- Main grid -->
  <section class="ultra-grid">
    <!-- LEFT -->
    <div class="ultra-col">

      <!-- Today operations -->
      <div class="ultra-card">
        <div class="ultra-card__head">
          <div>
            <div class="ultra-card__title">Today operations</div>
            <div class="ultra-card__hint">Pickups & returns scheduled for <?= e((string)$today) ?></div>
          </div>
          <a class="ultra-link" href="bookings.php">View all</a>
        </div>

        <div class="ultra-card__body">
          <div class="ultra-split">
            <div>
              <div class="ultra-card__minihead">
                <div class="ultra-minititle">
                  <span class="ultra-ico"><i class="bi bi-car-front"></i></span>
                  Pickups today
                </div>
                <span class="ultra-tag is-blue"><?= count($pickupsToday) ?></span>
              </div>

              <div class="ultra-list">
                <?php if (!$pickupsToday): ?>
                  <div class="ultra-empty ultra-empty--small">No pickups scheduled today.</div>
                <?php else: ?>
                  <?php foreach ($pickupsToday as $b): ?>
                    <a class="ultra-item" href="booking_view.php?id=<?= (int)$b['id'] ?>">
                      <div class="ultra-item__top">
                        <div class="ultra-item__title">
                          <?= e($b['brand'].' '.$b['model']) ?>
                          <span>#<?= (int)$b['id'] ?> • <?= e((string)$b['plate_number']) ?></span>
                        </div>
                        <span class="ultra-tag is-blue"><?= e(date('H:i', strtotime((string)$b['start_datetime']))) ?></span>
                      </div>
                      <div class="ultra-item__sub">
                        <?= e((string)($b['pickup_name'] ?? '—')) ?> → <?= e((string)($b['dropoff_name'] ?? '—')) ?>
                      </div>
                    </a>
                  <?php endforeach; ?>
                <?php endif; ?>
              </div>
            </div>

            <div>
              <div class="ultra-card__minihead">
                <div class="ultra-minititle">
                  <span class="ultra-ico"><i class="bi bi-arrow-return-left"></i></span>
                  Returns today
                </div>
                <span class="ultra-tag is-orange"><?= count($returnsToday) ?></span>
              </div>

              <div class="ultra-list">
                <?php if (!$returnsToday): ?>
                  <div class="ultra-empty ultra-empty--small">No returns scheduled today.</div>
                <?php else: ?>
                  <?php foreach ($returnsToday as $b): ?>
                    <a class="ultra-item" href="booking_view.php?id=<?= (int)$b['id'] ?>">
                      <div class="ultra-item__top">
                        <div class="ultra-item__title">
                          <?= e($b['brand'].' '.$b['model']) ?>
                          <span>#<?= (int)$b['id'] ?> • <?= e((string)$b['plate_number']) ?></span>
                        </div>
                        <span class="ultra-tag is-orange"><?= e(date('H:i', strtotime((string)$b['end_datetime']))) ?></span>
                      </div>
                      <div class="ultra-item__sub">
                        End: <?= e(date('d/m/Y H:i', strtotime((string)$b['end_datetime']))) ?>
                      </div>
                    </a>
                  <?php endforeach; ?>
                <?php endif; ?>
              </div>
            </div>
          </div>

        </div>
      </div>

      <!-- Attention needed -->
      <div class="ultra-card">
        <div class="ultra-card__head">
          <div>
            <div class="ultra-card__title">Attention needed</div>
            <div class="ultra-card__hint">Late returns & unpaid bookings</div>
          </div>
          <?php if ($hasUrgent): ?>
            <span class="ultra-chip ultra-chip--danger"><i class="bi bi-exclamation-triangle me-1"></i>Urgent</span>
          <?php else: ?>
            <span class="ultra-chip"><i class="bi bi-check2-circle me-1"></i>All good</span>
          <?php endif; ?>
        </div>

        <div class="ultra-card__body">
          <div class="ultra-split">

            <div>
              <div class="ultra-card__minihead">
                <div class="ultra-minititle ultra-danger">
                  <span class="ultra-ico"><i class="bi bi-alarm"></i></span>
                  Late returns
                </div>
                <a class="ultra-link" href="bookings.php?filter=late">View</a>
              </div>
              <div class="ultra-list">
                <?php if (!$lateReturns): ?>
                  <div class="ultra-empty ultra-empty--small">No late returns.</div>
                <?php else: ?>
                  <?php foreach ($lateReturns as $b): ?>
                    <a class="ultra-item is-unread" href="booking_view.php?id=<?= (int)$b['id'] ?>">
                      <div class="ultra-item__top">
                        <div class="ultra-item__title">
                          <?= e($b['brand'].' '.$b['model']) ?>
                          <span>#<?= (int)$b['id'] ?> • <?= e((string)$b['plate_number']) ?></span>
                        </div>
                        <span class="ultra-tag is-red"><?= e(date('d/m H:i', strtotime((string)$b['end_datetime']))) ?></span>
                      </div>
                      <div class="ultra-item__sub">Ended: <?= e((string)$b['end_datetime']) ?></div>
                    </a>
                  <?php endforeach; ?>
                <?php endif; ?>
              </div>
            </div>

            <div>
              <div class="ultra-card__minihead">
                <div class="ultra-minititle">
                  <span class="ultra-ico"><i class="bi bi-credit-card"></i></span>
                  Payments due
                </div>
                <a class="ultra-link" href="bookings.php?filter=unpaid">View</a>
              </div>
              <div class="ultra-list">
                <?php if (!$paymentsDue): ?>
                  <div class="ultra-empty ultra-empty--small">No unpaid bookings.</div>
                <?php else: ?>
                  <?php foreach ($paymentsDue as $b): ?>
                    <a class="ultra-item" href="booking_payment.php?id=<?= (int)$b['id'] ?>">
                      <div class="ultra-item__top">
                        <div class="ultra-item__title">
                          <?= e($b['brand'].' '.$b['model']) ?>
                          <span>#<?= (int)$b['id'] ?> • <?= e((string)$b['plate_number']) ?></span>
                        </div>
                        <span class="ultra-tag is-orange"><?= number_format((float)$b['remaining'], 2) ?> MAD</span>
                      </div>
                      <div class="ultra-item__sub">Open payment</div>
                    </a>
                  <?php endforeach; ?>
                <?php endif; ?>
              </div>
            </div>

          </div>
        </div>
      </div>

    </div>

    <!-- RIGHT -->
    <div class="ultra-col ultra-col--right">

      <div class="ultra-card">
        <div class="ultra-card__head">
          <div>
            <div class="ultra-card__title">Upcoming expirations</div>
            <div class="ultra-card__hint">Insurance • Maintenance • GPS • Installments</div>
          </div>
          <a class="ultra-link" href="vehicles.php">Vehicles</a>
        </div>
        <div class="ultra-card__body">

          <div class="ultra-divider"></div>

          <div class="ultra-card__minihead">
            <div class="ultra-minititle">
              <span class="ultra-ico"><i class="bi bi-shield-check"></i></span>
              Insurance soon (≤ 30 days)
            </div>
            <span class="ultra-tag is-orange"><?= count($insuranceSoon) ?></span>
          </div>
          <div class="ultra-list">
            <?php if (!$insuranceSoon): ?>
              <div class="ultra-empty ultra-empty--small">No insurance expiring soon.</div>
            <?php else: ?>
              <?php foreach ($insuranceSoon as $v): ?>
                <a class="ultra-item" href="vehicles.php">
                  <div class="ultra-item__top">
                    <div class="ultra-item__title"><?= e($v['brand'].' '.$v['model']) ?><span><?= e((string)$v['plate_number']) ?></span></div>
                    <span class="ultra-tag is-orange"><?= e((string)$v['insurance_expiry_date']) ?></span>
                  </div>
                  <div class="ultra-item__sub">Insurance expiry</div>
                </a>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>

          <div class="ultra-divider"></div>

          <div class="ultra-card__minihead">
            <div class="ultra-minititle">
              <span class="ultra-ico"><i class="bi bi-tools"></i></span>
              Maintenance soon (≤ 500 km)
            </div>
            <span class="ultra-tag is-blue"><?= count($maintSoon) ?></span>
          </div>
          <div class="ultra-list">
            <?php if (!$maintSoon): ?>
              <div class="ultra-empty ultra-empty--small">No maintenance due soon.</div>
            <?php else: ?>
              <?php foreach ($maintSoon as $v): ?>
                <a class="ultra-item" href="maintenance.php">
                  <div class="ultra-item__top">
                    <div class="ultra-item__title"><?= e($v['brand'].' '.$v['model']) ?><span><?= e((string)$v['plate_number']) ?></span></div>
                    <span class="ultra-tag is-blue"><?= (int)$v['remaining_km'] ?> km</span>
                  </div>
                  <div class="ultra-item__sub">Oil change in <?= (int)$v['remaining_km'] ?> km</div>
                </a>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>

          <?php if ($hasGpsSubs): ?>
            <div class="ultra-divider"></div>

            <div class="ultra-card__minihead">
              <div class="ultra-minititle">
                <span class="ultra-ico"><i class="bi bi-geo-alt"></i></span>
                GPS subscriptions soon
              </div>
              <span class="ultra-tag is-purple"><?= count($gpsSoon) ?></span>
            </div>
            <div class="ultra-list">
              <?php if (!$gpsSoon): ?>
                <div class="ultra-empty ultra-empty--small">No GPS subscriptions expiring soon.</div>
              <?php else: ?>
                <?php foreach ($gpsSoon as $gs): ?>
                  <a class="ultra-item" href="gps.php">
                    <div class="ultra-item__top">
                      <div class="ultra-item__title">
                        <?= e(($gs['brand'] ?? 'Vehicle').' '.($gs['model'] ?? '')) ?>
                        <span><?= e((string)($gs['plate_number'] ?? '—')) ?></span>
                      </div>
                      <span class="ultra-tag is-purple"><?= e((string)($gs['end_date'] ?? '—')) ?></span>
                    </div>
                    <div class="ultra-item__sub">GPS end date</div>
                  </a>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          <?php endif; ?>

          <?php if ($hasInstallments): ?>
            <div class="ultra-divider"></div>

            <div class="ultra-card__minihead">
              <div class="ultra-minititle">
                <span class="ultra-ico"><i class="bi bi-bank"></i></span>
                Bank installments (≤ 30 days)
              </div>
              <span class="ultra-tag is-orange"><?= count($installmentsSoon) ?></span>
            </div>

            <div class="ultra-list">
              <?php if (!$installmentsSoon): ?>
                <div class="ultra-empty ultra-empty--small">No installments due soon.</div>
              <?php else: ?>
                <?php foreach ($installmentsSoon as $it): ?>
                  <?php
                    $veh = trim(($it['brand'] ?? '').' '.($it['model'] ?? ''));
                    $plate = (string)($it['plate_number'] ?? '—');
                    $due = (string)($it['due_date'] ?? '—');
                    $daysLeft = (int)($it['days_left'] ?? 0);
                    $amount = (float)($it['monthly_amount'] ?? 0);
                    $cur = (string)($it['currency'] ?? 'MAD');
                  ?>
                  <a class="ultra-item" href="installments.php?vehicle_id=<?= (int)$it['vehicle_id'] ?>">
                    <div class="ultra-item__top">
                      <div class="ultra-item__title">
                        <?= e($veh ?: 'Vehicle') ?>
                        <span><?= e($plate) ?></span>
                      </div>
                      <span class="ultra-tag is-orange"><?= e($due) ?></span>
                    </div>
                    <div class="ultra-item__sub">
                      <?= number_format($amount, 2) ?> <?= e($cur) ?> • <?= $daysLeft ?> day(s) left
                    </div>
                  </a>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          <?php endif; ?>

        </div>
      </div>

      <div class="ultra-card">
        <div class="ultra-card__head">
          <div>
            <div class="ultra-card__title">Latest notifications</div>
            <div class="ultra-card__hint">Last 8 alerts</div>
          </div>
          <a class="ultra-link" href="notifications.php">Open</a>
        </div>
        <div class="ultra-card__body">
          <div class="ultra-list">
            <?php if (!$latestNotifs): ?>
              <div class="ultra-empty ultra-empty--small">No notifications.</div>
            <?php else: ?>
              <?php foreach ($latestNotifs as $n): ?>
                <?php
                  $isRead = (int)($n['is_read'] ?? 0) === 1;
                  $data = $n['data'] ?? '';
                  $snippet = is_string($data) ? $data : json_encode($data);
                  $snippet = (string)$snippet;
                  if (strlen($snippet) > 90) $snippet = substr($snippet, 0, 90).'…';
                ?>
                <a class="ultra-item <?= $isRead ? '' : 'is-unread' ?>" href="notifications.php">
                  <div class="ultra-item__top">
                    <div class="ultra-item__title">
                      <?= e((string)($n['type'] ?? 'notification')) ?>
                      <span>#<?= (int)$n['id'] ?></span>
                    </div>
                    <span class="ultra-tag"><?= e(date('d/m H:i', strtotime((string)$n['created_at']))) ?></span>
                  </div>
                  <div class="ultra-item__sub"><?= e($snippet) ?></div>
                </a>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </div>

    </div>
  </section>

</main>

<!-- =========================
     URGENT MODAL
     ========================= -->
<div class="modal fade" id="urgentModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-scrollable modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title">Urgent alerts</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <div class="row g-3">
          <div class="col-lg-6">
            <div class="card shadow-sm">
              <div class="card-header fw-semibold"><i class="bi bi-alarm me-2"></i>Late returns</div>
              <div class="card-body">
                <?php if (!count($urgent['late_returns'])): ?>
                  <div class="text-muted small">No late returns.</div>
                <?php else: ?>
                  <div class="list-group">
                    <?php foreach ($urgent['late_returns'] as $b): ?>
                      <a class="list-group-item list-group-item-action" href="booking_view.php?id=<?= (int)$b['id'] ?>">
                        <div class="d-flex justify-content-between">
                          <div class="fw-semibold"><?= e($b['brand'].' '.$b['model']) ?> <span class="text-muted">• <?= e((string)$b['plate_number']) ?></span></div>
                          <span class="badge bg-danger"><?= e(date('d/m H:i', strtotime((string)$b['end_datetime']))) ?></span>
                        </div>
                      </a>
                    <?php endforeach; ?>
                  </div>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="card shadow-sm">
              <div class="card-header fw-semibold"><i class="bi bi-shield-check me-2"></i>Insurance (7 days)</div>
              <div class="card-body">
                <?php if (!count($urgent['insurance_7'])): ?>
                  <div class="text-muted small">No insurance expiring in 7 days.</div>
                <?php else: ?>
                  <div class="list-group">
                    <?php foreach ($urgent['insurance_7'] as $v): ?>
                      <a class="list-group-item list-group-item-action" href="vehicles.php">
                        <div class="d-flex justify-content-between">
                          <div class="fw-semibold"><?= e($v['brand'].' '.$v['model']) ?> <span class="text-muted">• <?= e((string)$v['plate_number']) ?></span></div>
                          <span class="badge bg-warning text-dark"><?= e((string)$v['insurance_expiry_date']) ?></span>
                        </div>
                      </a>
                    <?php endforeach; ?>
                  </div>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="card shadow-sm">
              <div class="card-header fw-semibold"><i class="bi bi-clipboard-check me-2"></i>Technical visit (7 days)</div>
              <div class="card-body">
                <?php if (!count($urgent['tech_7'])): ?>
                  <div class="text-muted small">No technical visit expiring in 7 days.</div>
                <?php else: ?>
                  <div class="list-group">
                    <?php foreach ($urgent['tech_7'] as $v): ?>
                      <a class="list-group-item list-group-item-action" href="vehicles.php">
                        <div class="d-flex justify-content-between">
                          <div class="fw-semibold"><?= e($v['brand'].' '.$v['model']) ?> <span class="text-muted">• <?= e((string)$v['plate_number']) ?></span></div>
                          <span class="badge bg-warning text-dark"><?= e((string)$v['technical_visit_expiry_date']) ?></span>
                        </div>
                      </a>
                    <?php endforeach; ?>
                  </div>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="card shadow-sm">
              <div class="card-header fw-semibold"><i class="bi bi-credit-card me-2"></i>Payments due</div>
              <div class="card-body">
                <?php if (!count($urgent['payments_due'])): ?>
                  <div class="text-muted small">No unpaid bookings.</div>
                <?php else: ?>
                  <div class="list-group">
                    <?php foreach ($urgent['payments_due'] as $b): ?>
                      <a class="list-group-item list-group-item-action" href="booking_payment.php?id=<?= (int)$b['id'] ?>">
                        <div class="d-flex justify-content-between">
                          <div class="fw-semibold"><?= e($b['brand'].' '.$b['model']) ?> <span class="text-muted">• <?= e((string)$b['plate_number']) ?></span></div>
                          <span class="badge bg-danger"><?= number_format((float)$b['remaining'], 2) ?> MAD</span>
                        </div>
                      </a>
                    <?php endforeach; ?>
                  </div>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <?php if (!empty($urgent['installments_7'])): ?>
          <div class="col-lg-12">
            <div class="card shadow-sm">
              <div class="card-header fw-semibold"><i class="bi bi-bank me-2"></i>Bank installments (7 days)</div>
              <div class="card-body">
                <div class="list-group">
                  <?php foreach ($urgent['installments_7'] as $it): ?>
                    <?php
                      $veh = trim(($it['brand'] ?? '').' '.($it['model'] ?? ''));
                      $plate = (string)($it['plate_number'] ?? '—');
                      $due = (string)($it['due_date'] ?? '—');
                      $daysLeft = (int)($it['days_left'] ?? 0);
                      $amount = (float)($it['monthly_amount'] ?? 0);
                      $cur = (string)($it['currency'] ?? 'MAD');
                    ?>
                    <a class="list-group-item list-group-item-action" href="installments.php?vehicle_id=<?= (int)$it['vehicle_id'] ?>">
                      <div class="d-flex justify-content-between">
                        <div class="fw-semibold">
                          <?= e($veh ?: 'Vehicle') ?>
                          <span class="text-muted">• <?= e($plate) ?> • <?= number_format($amount, 2) ?> <?= e($cur) ?></span>
                        </div>
                        <span class="badge bg-warning text-dark"><?= e($due) ?> (<?= $daysLeft ?>d)</span>
                      </div>
                    </a>
                  <?php endforeach; ?>
                </div>
              </div>
            </div>
          </div>
          <?php endif; ?>

        </div>

      </div>
      <div class="modal-footer">
        <a class="btn btn-outline-dark" data-bs-dismiss="modal">Close</a>
        <a class="btn btn-danger" href="notifications.php">Open notifications</a>
      </div>
    </div>
  </div>
</div>

<?php if ($hasUrgent): ?>
<script>
  document.addEventListener('DOMContentLoaded', function(){
    if (window.bootstrap && document.getElementById('urgentModal')) {
      const m = new bootstrap.Modal(document.getElementById('urgentModal'));
      m.show();
    }
  });
</script>
<?php endif; ?>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<script>
  const bookings7Labels = <?= json_encode($bookings7_labels, JSON_UNESCAPED_UNICODE) ?>;
  const bookings7Values = <?= json_encode($bookings7_values, JSON_UNESCAPED_UNICODE) ?>;

  const months6Labels = <?= json_encode($months6_labels, JSON_UNESCAPED_UNICODE) ?>;
  const months6Rev = <?= json_encode($months6_rev, JSON_UNESCAPED_UNICODE) ?>;
  const months6Exp = <?= json_encode($months6_expv, JSON_UNESCAPED_UNICODE) ?>;

  const vehLabels = <?= json_encode($veh_labels, JSON_UNESCAPED_UNICODE) ?>;
  const vehValues = <?= json_encode($veh_values, JSON_UNESCAPED_UNICODE) ?>;

  function money(v){
    try { return new Intl.NumberFormat(undefined, { maximumFractionDigits: 0 }).format(v) + ' MAD'; }
    catch(e){ return v + ' MAD'; }
  }

  // Bookings line
  const c1 = document.getElementById('chartBookings7');
  if (c1) {
    new Chart(c1, {
      type: 'line',
      data: {
        labels: bookings7Labels,
        datasets: [{
          label: 'Bookings',
          data: bookings7Values,
          tension: 0.35,
          fill: true
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { label: (ctx) => ` ${ctx.parsed.y} bookings` } }
        },
        scales: {
          x: { grid: { display: false } },
          y: { beginAtZero: true, ticks: { precision: 0 } }
        }
      }
    });
  }

  // Fleet doughnut
  const c2 = document.getElementById('chartFleet');
  if (c2) {
    new Chart(c2, {
      type: 'doughnut',
      data: {
        labels: vehLabels,
        datasets: [{ data: vehValues, borderWidth: 1 }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } },
        cutout: '62%'
      }
    });
  }

  // Finance bar
  const c3 = document.getElementById('chartFinance');
  if (c3) {
    new Chart(c3, {
      type: 'bar',
      data: {
        labels: months6Labels,
        datasets: [
          { label: 'Revenue', data: months6Rev },
          { label: 'Expenses', data: months6Exp }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: 'bottom' },
          tooltip: { callbacks: { label: (ctx) => ` ${ctx.dataset.label}: ${money(ctx.parsed.y)}` } }
        },
        scales: {
          x: { grid: { display: false } },
          y: { beginAtZero: true, ticks: { callback: (v)=> money(v) } }
        }
      }
    });
  }
</script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
