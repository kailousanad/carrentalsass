<?php
// public/installments.php

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) redirect('index.php');

require_once __DIR__ . '/../config/config.php';

$page_title = 'Bank Installments – Car Rental SaaS';

$companyId = current_company_id();
if (!$companyId) die('Company ID not found in session.');

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['_csrf'];

$errors = [];
$success = '';

/* Vehicles list */
$st = $pdo->prepare("SELECT id, brand, model, plate_number FROM vehicles WHERE company_id=:cid ORDER BY id DESC");
$st->execute(['cid'=>$companyId]);
$vehicles = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

/* Selected vehicle */
$vehicleId = isset($_GET['vehicle_id']) && ctype_digit($_GET['vehicle_id']) ? (int)$_GET['vehicle_id'] : 0;

/* Fetch existing installment */
$inst = null;
if ($vehicleId) {
  $st = $pdo->prepare("SELECT * FROM vehicle_installments WHERE company_id=:cid AND vehicle_id=:vid LIMIT 1");
  $st->execute(['cid'=>$companyId,'vid'=>$vehicleId]);
  $inst = $st->fetch(PDO::FETCH_ASSOC);
}

/* Save */
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $token = $_POST['_csrf'] ?? '';
  if (!hash_equals($csrf, (string)$token)) { http_response_code(403); die('CSRF'); }

  $vehicleId = (int)($_POST['vehicle_id'] ?? 0);
  $provider  = trim($_POST['provider_name'] ?? '');
  $ref       = trim($_POST['contract_ref'] ?? '');
  $amount    = $_POST['monthly_amount'] ?? '0';
  $currency  = trim($_POST['currency'] ?? 'MAD');
  $dueDay    = (int)($_POST['due_day'] ?? 5);
  $startDate = trim($_POST['start_date'] ?? '');
  $endDate   = trim($_POST['end_date'] ?? '');
  $remind    = (int)($_POST['remind_days_before'] ?? 5);
  $status    = $_POST['status'] ?? 'active';

  if ($vehicleId <= 0) $errors[] = 'Vehicle is required.';
  if (!is_numeric($amount) || (float)$amount < 0) $errors[] = 'Monthly amount must be valid.';
  if ($dueDay < 1 || $dueDay > 31) $errors[] = 'Due day must be between 1 and 31.';
  if ($remind < 0 || $remind > 30) $errors[] = 'Remind days must be between 0 and 30.';
  if (!in_array($status, ['active','paused','ended'], true)) $status = 'active';

  $sd = $startDate !== '' ? $startDate : null;
  $ed = $endDate !== '' ? $endDate : null;

  if (!$errors) {
    // ensure vehicle belongs to company
    $chk = $pdo->prepare("SELECT id FROM vehicles WHERE id=:vid AND company_id=:cid");
    $chk->execute(['vid'=>$vehicleId,'cid'=>$companyId]);
    if (!$chk->fetchColumn()) {
      $errors[] = 'Invalid vehicle.';
    } else {
      // upsert
      $up = $pdo->prepare("
        INSERT INTO vehicle_installments
          (company_id, vehicle_id, provider_name, contract_ref, monthly_amount, currency, due_day, start_date, end_date, remind_days_before, status)
        VALUES
          (:cid,:vid,:provider,:ref,:amount,:currency,:due_day,:start_date,:end_date,:remind,:status)
        ON DUPLICATE KEY UPDATE
          provider_name=VALUES(provider_name),
          contract_ref=VALUES(contract_ref),
          monthly_amount=VALUES(monthly_amount),
          currency=VALUES(currency),
          due_day=VALUES(due_day),
          start_date=VALUES(start_date),
          end_date=VALUES(end_date),
          remind_days_before=VALUES(remind_days_before),
          status=VALUES(status)
      ");
      $up->execute([
        'cid'=>$companyId,
        'vid'=>$vehicleId,
        'provider'=>$provider ?: null,
        'ref'=>$ref ?: null,
        'amount'=>(float)$amount,
        'currency'=>$currency ?: 'MAD',
        'due_day'=>$dueDay,
        'start_date'=>$sd,
        'end_date'=>$ed,
        'remind'=>$remind,
        'status'=>$status
      ]);

      header('Location: installments.php?vehicle_id='.$vehicleId.'&saved=1');
      exit;
    }
  }
}

if (isset($_GET['saved'])) $success = 'saved';

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-12 col-lg-10 p-4">

  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <h4 class="mb-1">Bank Installments</h4>
      <div class="text-muted small">Configure monthly installment per vehicle + auto reminders.</div>
    </div>
    <a href="expenses.php" class="btn btn-outline-dark">
      <i class="bi bi-receipt me-2"></i>Open Expenses
    </a>
  </div>

  <?php if ($errors): ?>
    <div class="alert alert-danger py-2">
      <?php foreach($errors as $e): ?><div><?= h($e) ?></div><?php endforeach; ?>
    </div>
  <?php endif; ?>

  <?php if ($success==='saved'): ?>
    <div class="alert alert-success py-2">Installment saved successfully.</div>
  <?php endif; ?>

  <div class="card shadow-sm">
    <div class="card-body">
      <form method="get" class="row g-2 align-items-end mb-3">
        <div class="col-12 col-md-6">
          <label class="form-label">Select vehicle</label>
          <select name="vehicle_id" class="form-select" onchange="this.form.submit()">
            <option value="0">-- Choose --</option>
            <?php foreach($vehicles as $v): ?>
              <option value="<?= (int)$v['id'] ?>" <?= $vehicleId===(int)$v['id']?'selected':'' ?>>
                #<?= (int)$v['id'] ?> — <?= h($v['brand'].' '.$v['model']) ?> (<?= h($v['plate_number']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>
      </form>

      <?php if (!$vehicleId): ?>
        <div class="text-muted">Select a vehicle to configure its installment.</div>
      <?php else: ?>
        <form method="post" class="row g-3">
          <input type="hidden" name="_csrf" value="<?= h($csrf) ?>">
          <input type="hidden" name="vehicle_id" value="<?= (int)$vehicleId ?>">

          <div class="col-md-6">
            <label class="form-label">Bank / Provider</label>
            <input class="form-control" name="provider_name" value="<?= h($inst['provider_name'] ?? '') ?>" placeholder="CIH / Wafasalaf / ...">
          </div>

          <div class="col-md-6">
            <label class="form-label">Contract Ref</label>
            <input class="form-control" name="contract_ref" value="<?= h($inst['contract_ref'] ?? '') ?>" placeholder="REF-123...">
          </div>

          <div class="col-md-4">
            <label class="form-label">Monthly amount</label>
            <input type="number" step="0.01" min="0" class="form-control" name="monthly_amount" value="<?= h($inst['monthly_amount'] ?? '0') ?>">
          </div>

          <div class="col-md-2">
            <label class="form-label">Currency</label>
            <input class="form-control" name="currency" value="<?= h($inst['currency'] ?? 'MAD') ?>">
          </div>

          <div class="col-md-3">
            <label class="form-label">Due day (1..31)</label>
            <input type="number" min="1" max="31" class="form-control" name="due_day" value="<?= h($inst['due_day'] ?? '5') ?>">
          </div>

          <div class="col-md-3">
            <label class="form-label">Remind before (days)</label>
            <input type="number" min="0" max="30" class="form-control" name="remind_days_before" value="<?= h($inst['remind_days_before'] ?? '5') ?>">
          </div>

          <div class="col-md-3">
            <label class="form-label">Start date</label>
            <input type="date" class="form-control" name="start_date" value="<?= h($inst['start_date'] ?? '') ?>">
          </div>

          <div class="col-md-3">
            <label class="form-label">End date</label>
            <input type="date" class="form-control" name="end_date" value="<?= h($inst['end_date'] ?? '') ?>">
          </div>

          <div class="col-md-3">
            <label class="form-label">Status</label>
            <select class="form-select" name="status">
              <?php foreach(['active'=>'Active','paused'=>'Paused','ended'=>'Ended'] as $k=>$v): ?>
                <option value="<?= $k ?>" <?= (($inst['status'] ?? 'active')===$k)?'selected':'' ?>><?= h($v) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-12">
            <button class="btn btn-primary px-4">
              <i class="bi bi-save me-2"></i>Save Installment
            </button>
            <div class="small text-muted mt-2">
              This will auto-create a monthly expense and reminders in Notifications.
            </div>
          </div>
        </form>
      <?php endif; ?>
    </div>
  </div>

</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
