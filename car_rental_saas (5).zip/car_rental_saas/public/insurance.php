<?php
// public/insurance.php - Fully Working + Modern Professional Design

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php'; // لـ e(), csrf_token(), flash(), إلخ

$page_title = 'Insurance';

$companyId = current_company_id();
if (!$companyId) {
    die('Company ID not found.');
}

$success = flash('success');
$errorMsg = flash('error');
$errors = [];

function days_left($endDate): int {
    $today = strtotime(date('Y-m-d'));
    $end = strtotime($endDate);
    return (int)floor(($end - $today) / 86400);
}

function badge_class($days): string {
    if ($days < 0) return 'bg-dark';
    if ($days <= 10) return 'bg-danger';
    if ($days <= 30) return 'bg-warning text-dark';
    return 'bg-success';
}

function create_insurance_reminder_if_needed(PDO $pdo, int $companyId, int $vehicleId, string $endDate, array $vehicleMeta)
{
    $d = days_left($endDate);
    if ($d > 30) return;

    // upsert reminder
    $pdo->prepare("
        INSERT INTO vehicle_reminders (company_id, vehicle_id, reminder_type, end_date, last_notified_at)
        VALUES (:cid,:vid,'insurance_expiring',:ed,NULL)
        ON DUPLICATE KEY UPDATE company_id = company_id
    ")->execute(['cid' => $companyId, 'vid' => $vehicleId, 'ed' => $endDate]);

    // check if notified today
    $st = $pdo->prepare("
        SELECT last_notified_at FROM vehicle_reminders
        WHERE company_id=:cid AND vehicle_id=:vid AND reminder_type='insurance_expiring' AND end_date=:ed
        LIMIT 1
    ");
    $st->execute(['cid' => $companyId, 'vid' => $vehicleId, 'ed' => $endDate]);
    $last = $st->fetchColumn();

    $today = date('Y-m-d');
    $alreadyToday = $last && date('Y-m-d', strtotime($last)) === $today;
    if ($alreadyToday) return;

    $data = json_encode([
        'vehicle_id' => $vehicleId,
        'plate_number' => $vehicleMeta['plate_number'] ?? null,
        'vehicle' => trim(($vehicleMeta['brand'] ?? '') . ' ' . ($vehicleMeta['model'] ?? '')),
        'end_date' => $endDate,
        'days_left' => $d,
    ], JSON_UNESCAPED_UNICODE);

    $pdo->prepare("
        INSERT INTO notifications (company_id, user_id, type, data, is_read, created_at)
        VALUES (:cid, NULL, 'insurance_expiring', :data, 0, NOW())
    ")->execute(['cid' => $companyId, 'data' => $data]);

    $pdo->prepare("
        UPDATE vehicle_reminders
        SET last_notified_at = NOW()
        WHERE company_id=:cid AND vehicle_id=:vid AND reminder_type='insurance_expiring' AND end_date=:ed
        LIMIT 1
    ")->execute(['cid' => $companyId, 'vid' => $vehicleId, 'ed' => $endDate]);
}

/** Handle POST */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['_csrf'] ?? '';
    if (!csrf_verify($csrf)) {
        $errors[] = 'CSRF invalid.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'renew') {
            $vehicleId = (int)($_POST['vehicle_id'] ?? 0);
            $insurerId = (int)($_POST['insurer_id'] ?? 0);
            $policy = trim($_POST['policy_number'] ?? '');
            $type = $_POST['insurance_type'] ?? 'liability';
            $start = $_POST['start_date'] ?? '';
            $end = $_POST['end_date'] ?? '';
            $premium = (float)($_POST['premium_amount'] ?? 0);

            $allowed = ['liability', 'full', 'theft', 'other'];
            if (!in_array($type, $allowed, true)) $type = 'other';

            if ($vehicleId <= 0) $errors[] = 'Invalid vehicle';
            if (empty($start) || empty($end)) $errors[] = 'Start/End date required';
            if (strtotime($end) < strtotime($start)) $errors[] = 'End date must be after start date';

            if (!$errors) {
                // Expire old
                $pdo->prepare("
                    UPDATE vehicle_insurances
                    SET status = 'expired', updated_at = NOW()
                    WHERE company_id = :cid AND vehicle_id = :vid AND status = 'active'
                ")->execute(['cid' => $companyId, 'vid' => $vehicleId]);

                // Insert new
                $pdo->prepare("
                    INSERT INTO vehicle_insurances
                    (company_id, vehicle_id, insurer_id, policy_number, insurance_type, start_date, end_date, premium_amount, currency, status)
                    VALUES (:cid, :vid, :iid, :pol, :t, :sd, :ed, :amt, 'MAD', 'active')
                ")->execute([
                    'cid' => $companyId,
                    'vid' => $vehicleId,
                    'iid' => $insurerId > 0 ? $insurerId : null,
                    'pol' => $policy !== '' ? $policy : null,
                    't' => $type,
                    'sd' => $start,
                    'ed' => $end,
                    'amt' => $premium
                ]);

                // Create expense
                if ($premium > 0) {
                    $stmt = $pdo->prepare("SELECT brand, model, plate_number FROM vehicles WHERE id = :id AND company_id = :cid LIMIT 1");
                    $stmt->execute(['id' => $vehicleId, 'cid' => $companyId]);
                    $vmeta = $stmt->fetch() ?: [];

                    $desc = 'Insurance renewal - ' . ($vmeta['plate_number'] ?? '') . ' (' . trim(($vmeta['brand'] ?? '') . ' ' . ($vmeta['model'] ?? '')) . ')'
                          . ($policy ? ' - policy ' . $policy : '');

                    $pdo->prepare("
                        INSERT INTO expenses (company_id, vehicle_id, amount, type, date, description)
                        VALUES (:cid, :vid, :amt, 'insurance', :d, :desc)
                    ")->execute([
                        'cid' => $companyId,
                        'vid' => $vehicleId,
                        'amt' => $premium,
                        'd' => $start,
                        'desc' => $desc
                    ]);
                }

                flash('success', 'Insurance renewed and expense created.');
                redirect('insurance.php');
            }
        }

        if ($action === 'cancel') {
            $insuranceId = (int)($_POST['insurance_id'] ?? 0);
            $reason = trim($_POST['cancel_reason'] ?? 'Cancelled');

            if ($insuranceId <= 0) $errors[] = 'Invalid insurance id';

            if (!$errors) {
                $pdo->prepare("
                    UPDATE vehicle_insurances
                    SET status='cancelled', cancel_reason=:r, cancelled_at=NOW(), updated_at=NOW()
                    WHERE id=:id AND company_id=:cid AND status='active'
                    LIMIT 1
                ")->execute(['r' => $reason, 'id' => $insuranceId, 'cid' => $companyId]);

                flash('success', 'Insurance cancelled.');
                redirect('insurance.php');
            }
        }
    }
}

/** Load insurers */
$stmt = $pdo->prepare("SELECT id, name FROM insurers WHERE company_id = :cid ORDER BY name ASC");
$stmt->execute(['cid' => $companyId]);
$insurers = $stmt->fetchAll();

/** Load vehicles + active insurance */
$stmt = $pdo->prepare("
    SELECT
        v.id AS vehicle_id, v.brand, v.model, v.plate_number, v.status AS vehicle_status,
        i.id AS insurance_id, i.insurer_id, i.policy_number, i.insurance_type, i.start_date, i.end_date, i.premium_amount, i.status,
        ins.name AS insurer_name, ins.phone AS insurer_phone, ins.email AS insurer_email, ins.contact_person
    FROM vehicles v
    LEFT JOIN vehicle_insurances i ON i.vehicle_id = v.id AND i.company_id = v.company_id AND i.status = 'active'
    LEFT JOIN insurers ins ON ins.id = i.insurer_id
    WHERE v.company_id = :cid
    ORDER BY v.id DESC
");
$stmt->execute(['cid' => $companyId]);
$rows = $stmt->fetchAll();

/** Auto reminders */
foreach ($rows as $r) {
    if (!empty($r['end_date'])) {
        create_insurance_reminder_if_needed(
            $pdo,
            $companyId,
            (int)$r['vehicle_id'],
            $r['end_date'],
            ['brand' => $r['brand'], 'model' => $r['model'], 'plate_number' => $r['plate_number']]
        );
    }
}

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-md-10 p-4 ultra-page">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <h3 class="fw-bold mb-1">Vehicle Insurance</h3>
            <p class="text-muted mb-0">All insurance policies in one place – status, days left, renew or cancel</p>
        </div>
        <a href="insurers.php" class="btn btn-outline-primary">
            <i class="bi bi-building me-2"></i>Manage Insurers
        </a>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm">
            <i class="bi bi-check-circle-fill me-2"></i><?= e($success) ?>
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($errorMsg || $errors): ?>
        <div class="alert alert-danger alert-dismissible fade show shadow-sm">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?= e($errorMsg) ?>
            <?php foreach ($errors as $er): ?>
                <div><?= e($er) ?></div>
            <?php endforeach; ?>
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <?php if (empty($rows)): ?>
            <div class="col-12 text-center py-5">
                <i class="bi bi-shield-slash display-1 text-muted opacity-50"></i>
                <h5 class="mt-4 text-muted">No vehicles registered yet</h5>
            </div>
        <?php else: ?>
            <?php foreach ($rows as $r):
                $has = !empty($r['insurance_id']);
                $days = $has ? days_left($r['end_date']) : null;
                $badge = $has ? badge_class($days) : 'bg-secondary';
                $label = !$has ? 'No insurance'
                    : ($days < 0 ? 'Expired' : 'باقي ' . $days . ' يوم');
            ?>
                <div class="col-md-6 col-xl-4">
                    <div class="card h-100 shadow-sm hover-lift border-start border-4 <?= $has ? 'border-primary' : 'border-secondary' ?>">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h6 class="mb-0 fw-bold"><?= e($r['brand'] . ' ' . $r['model']) ?></h6>
                            <span class="badge <?= $badge ?> fs-6"><?= $label ?></span>
                        </div>
                        <div class="card-body d-flex flex-column">
                            <div class="small text-muted mb-4">
                                <div><strong>Plate:</strong> <?= e($r['plate_number']) ?></div>
                                <?php if ($has): ?>
                                    <div><strong>Insurer:</strong> <?= e($r['insurer_name'] ?: '—') ?></div>
                                    <div><strong>Type:</strong> <?= e(ucfirst($r['insurance_type'])) ?></div>
                                    <div><strong>Policy #:</strong> <?= e($r['policy_number'] ?: '—') ?></div>
                                    <div><strong>Period:</strong> <?= e($r['start_date']) ?> → <?= e($r['end_date']) ?></div>
                                    <div><strong>Premium:</strong> <?= number_format((float)$r['premium_amount'], 2) ?> MAD</div>
                                    <?php if (!empty($r['insurer_phone']) || !empty($r['insurer_email'])): ?>
                                        <div class="mt-2">
                                            <?= !empty($r['insurer_phone']) ? '<i class="bi bi-telephone me-1"></i>' . e($r['insurer_phone']) : '' ?>
                                            <?= !empty($r['insurer_email']) ? ' • <i class="bi bi-envelope me-1"></i>' . e($r['insurer_email']) : '' ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>

                            <div class="mt-auto">
                                <button class="btn btn-primary w-100 mb-2" type="button" onclick="toggleForm('renew-<?= $r['vehicle_id'] ?>')">
                                    Renew Insurance
                                </button>

                                <?php if ($has): ?>
                                    <button class="btn btn-outline-danger w-100" type="button" onclick="toggleForm('cancel-<?= $r['insurance_id'] ?>')">
                                        Cancel Policy
                                    </button>
                                <?php endif; ?>
                            </div>

                            <!-- Renew Form -->
                            <div id="renew-<?= $r['vehicle_id'] ?>" class="mt-3 d-none border-top pt-3 bg-light rounded">
                                <form method="post">
                                    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                                    <input type="hidden" name="action" value="renew">
                                    <input type="hidden" name="vehicle_id" value="<?= (int)$r['vehicle_id'] ?>">

                                    <div class="row g-2">
                                        <div class="col-12">
                                            <select name="insurer_id" class="form-select form-select-sm">
                                                <option value="0">— No insurer —</option>
                                                <?php foreach ($insurers as $ins): ?>
                                                    <option value="<?= (int)$ins['id'] ?>" <?= $r['insurer_id'] == $ins['id'] ? 'selected' : '' ?>>
                                                        <?= e($ins['name']) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-6">
                                            <select name="insurance_type" class="form-select form-select-sm">
                                                <?php foreach (['liability','full','theft','other'] as $t): ?>
                                                    <option value="<?= $t ?>" <?= $r['insurance_type'] === $t ? 'selected' : '' ?>><?= ucfirst($t) ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-6">
                                            <input type="text" name="policy_number" class="form-control form-control-sm" placeholder="Policy #" value="<?= e($r['policy_number'] ?? '') ?>">
                                        </div>
                                        <div class="col-6">
                                            <input type="date" name="start_date" class="form-control form-control-sm" value="<?= date('Y-m-d') ?>" required>
                                        </div>
                                        <div class="col-6">
                                            <input type="date" name="end_date" class="form-control form-control-sm" value="<?= e($r['end_date'] ?? '') ?>" required>
                                        </div>
                                        <div class="col-8">
                                            <input type="number" step="0.01" name="premium_amount" class="form-control form-control-sm" placeholder="Premium amount">
                                        </div>
                                        <div class="col-4 d-grid">
                                            <button class="btn btn-success btn-sm w-100">Save Renewal</button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <!-- Cancel Form -->
                            <?php if ($has): ?>
                                <div id="cancel-<?= $r['insurance_id'] ?>" class="mt-3 d-none border-top pt-3 bg-light rounded">
                                    <form method="post" onsubmit="return confirm('Are you sure you want to cancel this insurance policy?')">
                                        <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                                        <input type="hidden" name="action" value="cancel">
                                        <input type="hidden" name="insurance_id" value="<?= (int)$r['insurance_id'] ?>">

                                        <div class="input-group input-group-sm">
                                            <input type="text" name="cancel_reason" class="form-control" placeholder="Reason (e.g. sold vehicle)" required>
                                            <button class="btn btn-danger">Cancel Policy</button>
                                        </div>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<style>
.hover-lift {
    transition: all 0.3s ease;
}
.hover-lift:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.12) !important;
}
</style>

<script>
function toggleForm(id) {
    const el = document.getElementById(id);
    el.classList.toggle('d-none');
}
</script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>