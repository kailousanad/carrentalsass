<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) redirect('index.php');

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';

$companyId = current_company_id();
if (!$companyId) die('Company ID not found.');

$success = flash('success');
$errorMsg = flash('error');
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['_csrf'] ?? '';
    if (!csrf_verify($csrf)) {
        $errors[] = 'CSRF invalid.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'convert') {
            $tplId = (int)($_POST['template_id'] ?? 0);
            $amount = (float)($_POST['amount'] ?? 0);

            if ($tplId <= 0) $errors[] = 'Invalid template';
            if ($amount <= 0) $errors[] = 'Amount must be > 0';

            if (!$errors) {
                // Load template
                $st = $pdo->prepare("
                    SELECT t.*, v.plate_number, v.brand, v.model
                    FROM expense_templates t
                    JOIN vehicles v ON v.id = t.vehicle_id
                    WHERE t.id=:id AND t.company_id=:cid AND t.status='draft'
                    LIMIT 1
                ");
                $st->execute(['id'=>$tplId,'cid'=>$companyId]);
                $t = $st->fetch();
                if (!$t) {
                    $errors[] = 'Template not found or already processed.';
                } else {
                    // Create real expense
                    $desc = 'Insurance renewal for '.$t['plate_number'].' ('.$t['brand'].' '.$t['model'].') - due '.$t['due_date'];

                    $pdo->prepare("
                        INSERT INTO expenses (company_id, vehicle_id, amount, type, date, description)
                        VALUES (:cid, :vid, :amount, 'insurance', :d, :desc)
                    ")->execute([
                        'cid'=>$companyId,
                        'vid'=>(int)$t['vehicle_id'],
                        'amount'=>$amount,
                        'd'=>$t['due_date'],
                        'desc'=>$desc,
                    ]);

                    // Mark template as converted
                    $pdo->prepare("
                        UPDATE expense_templates
                        SET status='converted', suggested_amount=:amt, updated_at=NOW()
                        WHERE id=:id AND company_id=:cid
                        LIMIT 1
                    ")->execute(['amt'=>$amount,'id'=>$tplId,'cid'=>$companyId]);

                    flash('success', 'Template converted to expense.');
                    redirect('insurance_templates.php');
                }
            }
        }

        if ($action === 'dismiss') {
            $tplId = (int)($_POST['template_id'] ?? 0);
            if ($tplId <= 0) $errors[] = 'Invalid template';
            if (!$errors) {
                $pdo->prepare("
                    UPDATE expense_templates
                    SET status='dismissed', updated_at=NOW()
                    WHERE id=:id AND company_id=:cid AND status='draft'
                    LIMIT 1
                ")->execute(['id'=>$tplId,'cid'=>$companyId]);

                flash('success', 'Template dismissed.');
                redirect('insurance_templates.php');
            }
        }
    }
}

$stmt = $pdo->prepare("
    SELECT t.*, v.brand, v.model, v.plate_number, v.insurance_expiry_date
    FROM expense_templates t
    JOIN vehicles v ON v.id = t.vehicle_id
    WHERE t.company_id = :cid AND t.template_type='insurance_renewal' AND t.status='draft'
    ORDER BY t.due_date ASC
");
$stmt->execute(['cid'=>$companyId]);
$rows = $stmt->fetchAll();

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>
<div class="col-md-10 p-4">
  <div class="topbar d-flex justify-content-between align-items-center px-3 py-2 mb-3">
    <div>
      <h5 class="mb-0">Insurance templates</h5>
      <div class="small text-muted">Draft expenses generated automatically when insurance expiry is near.</div>
    </div>
    <a class="btn btn-outline-primary" href="cron_insurance.php?days=30" target="_blank">Run Scan (30d)</a>
  </div>

  <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
  <?php if ($errorMsg): ?><div class="alert alert-danger"><?= e($errorMsg) ?></div><?php endif; ?>

  <?php if ($errors): ?>
    <div class="alert alert-danger">
      <ul class="mb-0"><?php foreach($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul>
    </div>
  <?php endif; ?>

  <div class="card shadow-sm">
    <div class="card-body">
      <h6 class="mb-3">Drafts</h6>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead>
            <tr>
              <th>Due date</th>
              <th>Vehicle</th>
              <th>Plate</th>
              <th>Suggested</th>
              <th style="width:360px"></th>
            </tr>
          </thead>
          <tbody>
            <?php if(!$rows): ?>
              <tr><td colspan="5" class="text-muted">No insurance templates now. Run scan.</td></tr>
            <?php endif; ?>

            <?php foreach($rows as $r): ?>
              <tr>
                <td class="fw-semibold"><?= e($r['due_date']) ?></td>
                <td><?= e($r['brand'].' '.$r['model']) ?></td>
                <td class="text-muted"><?= e($r['plate_number']) ?></td>
                <td><?= money_fmt($r['suggested_amount']) ?> <?= e($r['currency']) ?></td>
                <td class="text-end">
                  <form method="post" class="d-inline-flex gap-2 align-items-center">
                    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="convert">
                    <input type="hidden" name="template_id" value="<?= (int)$r['id'] ?>">

                    <input type="number" step="0.01" name="amount" class="form-control form-control-sm" placeholder="Amount" style="max-width:140px" required>
                    <button class="btn btn-sm btn-success">Convert to Expense</button>
                  </form>

                  <form method="post" class="d-inline" onsubmit="return confirm('Dismiss this template?')">
                    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="dismiss">
                    <input type="hidden" name="template_id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn-sm btn-outline-secondary">Dismiss</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>

          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../templates/footer.php'; ?>
