<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) redirect('index.php');

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';

$companyId = current_company_id();
if (!$companyId) die('Company ID not found.');

$page_title = 'Insurers';

$success = flash('success');
$errorMsg = flash('error');
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $csrf = $_POST['_csrf'] ?? '';
  if (!csrf_verify($csrf)) {
    $errors[] = 'CSRF invalid.';
  } else {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
      $name = trim($_POST['name'] ?? '');
      $phone = trim($_POST['phone'] ?? '');
      $email = trim($_POST['email'] ?? '');
      $address = trim($_POST['address'] ?? '');
      $contact = trim($_POST['contact_person'] ?? '');
      $notes = trim($_POST['notes'] ?? '');

      if ($name === '') $errors[] = 'Name is required';
      if (!$errors) {
        $pdo->prepare("
          INSERT INTO insurers (company_id, name, phone, email, address, contact_person, notes)
          VALUES (:cid,:n,:p,:e,:a,:c,:no)
        ")->execute([
          'cid'=>$companyId,'n'=>$name,'p'=>$phone?:null,'e'=>$email?:null,'a'=>$address?:null,'c'=>$contact?:null,'no'=>$notes?:null
        ]);

        flash('success', 'Insurer added.');
        redirect('insurers.php');
      }
    }

    if ($action === 'delete') {
      $id = (int)($_POST['id'] ?? 0);
      if ($id <= 0) $errors[] = 'Invalid id';

      if (!$errors) {
        $pdo->prepare("DELETE FROM insurers WHERE id=:id AND company_id=:cid LIMIT 1")
            ->execute(['id'=>$id,'cid'=>$companyId]);

        flash('success', 'Insurer deleted.');
        redirect('insurers.php');
      }
    }
  }
}

$st = $pdo->prepare("SELECT * FROM insurers WHERE company_id=:cid ORDER BY id DESC");
$st->execute(['cid'=>$companyId]);
$rows = $st->fetchAll();

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>
<div class="col-md-10 p-4">
  <div class="topbar d-flex justify-content-between align-items-center px-3 py-2 mb-3">
    <div>
      <h5 class="mb-0">Insurers</h5>
      <div class="small text-muted">Manage insurance companies & contact info.</div>
    </div>
    <a class="btn btn-outline-secondary" href="insurance.php">Back to Insurance</a>
  </div>

  <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
  <?php if ($errorMsg): ?><div class="alert alert-danger"><?= e($errorMsg) ?></div><?php endif; ?>
  <?php if ($errors): ?>
    <div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div>
  <?php endif; ?>

  <div class="card shadow-sm mb-3">
    <div class="card-body">
      <h6 class="mb-3">Add insurer</h6>
      <form method="post" class="row g-2">
        <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="create">

        <div class="col-md-4">
          <label class="form-label small">Company name</label>
          <input type="text" name="name" class="form-control" required>
        </div>
        <div class="col-md-2">
          <label class="form-label small">Phone</label>
          <input type="text" name="phone" class="form-control">
        </div>
        <div class="col-md-3">
          <label class="form-label small">Email</label>
          <input type="email" name="email" class="form-control">
        </div>
        <div class="col-md-3">
          <label class="form-label small">Contact person</label>
          <input type="text" name="contact_person" class="form-control">
        </div>
        <div class="col-md-6">
          <label class="form-label small">Address</label>
          <input type="text" name="address" class="form-control">
        </div>
        <div class="col-md-6">
          <label class="form-label small">Notes</label>
          <input type="text" name="notes" class="form-control">
        </div>
        <div class="col-md-12 d-flex justify-content-end">
          <button class="btn btn-primary">Add</button>
        </div>
      </form>
    </div>
  </div>

  <div class="card shadow-sm">
    <div class="card-body">
      <h6 class="mb-3">List</h6>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead>
            <tr>
              <th>Name</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Contact</th>
              <th>Address</th>
              <th class="text-end"></th>
            </tr>
          </thead>
          <tbody>
          <?php if(!$rows): ?>
            <tr><td colspan="6" class="text-muted">No insurers yet.</td></tr>
          <?php endif; ?>
          <?php foreach($rows as $r): ?>
            <tr>
              <td class="fw-semibold"><?= e($r['name']) ?></td>
              <td><?= e($r['phone']) ?></td>
              <td><?= e($r['email']) ?></td>
              <td><?= e($r['contact_person']) ?></td>
              <td><?= e($r['address']) ?></td>
              <td class="text-end">
                <form method="post" onsubmit="return confirm('Delete this insurer?')">
                  <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <button class="btn btn-sm btn-outline-danger">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../templates/footer.php'; ?>
