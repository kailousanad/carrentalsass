<?php
// public/login.php - ULTRA Login with Beautiful JS Effects

session_start();

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/functions.php';

if (is_logged_in()) {
    redirect('index.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $error = 'Please fill in all fields.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            $error = 'Invalid email or password.';
        } elseif (isset($user['is_active']) && (int)$user['is_active'] !== 1) {
            $error = 'Your account is disabled.';
        } else {
            $dbPass = (string)($user['password'] ?? '');
            $isModernHash = str_starts_with($dbPass, '$2y$') || str_starts_with($dbPass, '$argon2');

            $ok = false;
            if (!$isModernHash && preg_match('/^[a-f0-9]{32}$/i', $dbPass)) {
                $ok = hash_equals(strtolower($dbPass), md5($password));
            } else {
                $ok = password_verify($password, $dbPass);
            }

            if (!$ok) {
                $error = 'Invalid email or password.';
            } else {
                $_SESSION['user_id']        = (int)($user['id'] ?? 0);
                $_SESSION['company_id']     = $user['company_id'] ?? null;
                $_SESSION['user_name']      = $user['name'] ?? 'User';
                $_SESSION['user_email']     = $user['email'] ?? $email;
                $_SESSION['is_super_admin'] = (int)($user['is_super_admin'] ?? 0);

                redirect('index.php');
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login • Car Rental ULTRA</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --gradient: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            --text: #1e293b;
            --muted: #64748b;
            --bg: #f8fafc;
            --card: #ffffff;
            --shadow: 0 25px 50px rgba(0,0,0,0.1);
            --radius: 28px;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--gradient);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text);
            overflow: hidden;
        }

        .login-container {
            width: 100%;
            max-width: 440px;
            padding: 1.5rem;
            animation: fadeIn 1s ease-out;
        }

        .login-card {
            background: var(--card);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            animation: slideUp 0.9s ease-out;
        }

        .login-header {
            text-align: center;
            padding: 3rem 2rem 2.5rem;
            background: var(--gradient);
            color: white;
            position: relative;
        }

        .login-header h1 {
            font-size: 2.2rem;
            font-weight: 900;
            margin-bottom: 0.75rem;
            letter-spacing: -0.5px;
        }

        .typing-text {
            font-size: 1.1rem;
            font-weight: 500;
            opacity: 0.95;
            min-height: 1.5em;
        }

        .login-body {
            padding: 2.5rem 2.5rem 3rem;
        }

        .form-group {
            position: relative;
            margin-bottom: 1.75rem;
        }

        .form-label {
            position: absolute;
            left: 1.25rem;
            top: 50%;
            transform: translateY(-50%);
            background: var(--card);
            padding: 0 0.5rem;
            font-weight: 600;
            color: var(--muted);
            pointer-events: none;
            transition: all 0.3s ease;
            font-size: 1rem;
        }

        .form-control {
            width: 100%;
            padding: 1.1rem 1.25rem;
            border: 2px solid #e2e8f0;
            border-radius: 16px;
            font-size: 1rem;
            background: transparent;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 5px rgba(99, 102, 241, 0.15);
        }

        .form-control:focus + .form-label,
        .form-control:not(:placeholder-shown) + .form-label {
            top: 0;
            font-size: 0.85rem;
            color: var(--primary);
        }

        .password-toggle {
            position: absolute;
            right: 1.25rem;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: var(--muted);
            font-size: 1.2rem;
            transition: color 0.3s ease;
        }

        .password-toggle:hover {
            color: var(--primary);
        }

        .btn-login {
            width: 100%;
            padding: 1.1rem;
            background: var(--gradient);
            color: white;
            border: none;
            border-radius: 16px;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.4s ease;
            box-shadow: 0 12px 30px rgba(99, 102, 241, 0.3);
            position: relative;
            overflow: hidden;
        }

        .btn-login:hover {
            transform: translateY(-4px);
            box-shadow: 0 18px 40px rgba(99, 102, 241, 0.4);
        }

        .btn-login.loading {
            opacity: 0.8;
            cursor: not-allowed;
        }

        .btn-login .spinner {
            display: none;
            width: 20px;
            height: 20px;
            border: 2px solid transparent;
            border-top: 2px solid white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-right: 0.75rem;
        }

        .btn-login.loading .spinner {
            display: inline-block;
        }

        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            padding: 1.1rem 1.5rem;
            border-radius: 16px;
            border: 1px solid #fecaca;
            font-size: 0.95rem;
            margin-bottom: 1.75rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            animation: shake 0.6s ease-in-out;
        }

        .alert-error i {
            font-size: 1.4rem;
            animation: pulse 1.5s infinite;
        }

        .login-footer {
            text-align: center;
            margin-top: 2.5rem;
            color: var(--muted);
            font-size: 0.9rem;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-8px); }
            20%, 40%, 60%, 80% { transform: translateX(8px); }
        }

        @keyframes pulse {
            0%, 100% { opacity: 0.7; }
            50% { opacity: 1; }
        }

        @media (max-width: 480px) {
            .login-container { padding: 1rem; }
            .login-header { padding: 2.5rem 1.5rem 2rem; }
            .login-header h1 { font-size: 1.9rem; }
            .login-body { padding: 2rem 1.5rem; }
        }
    </style>
</head>
<body>

<div class="login-container">
    <div class="login-card">
        <div class="login-header">
            <h1>Welcome Back</h1>
            <p class="typing-text" id="typingText"></p>
        </div>

        <div class="login-body">
            <?php if ($error): ?>
                <div class="alert-error">
                    <i class="bi bi-exclamation-triangle-fill"></i>
                    <div><?= htmlspecialchars($error) ?></div>
                </div>
            <?php endif; ?>

            <form method="post" action="login.php" id="loginForm">
                <div class="form-group">
                    <input 
                        type="email" 
                        name="email" 
                        class="form-control" 
                        placeholder=" " 
                        value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" 
                        required 
                        autocomplete="email">
                    <label class="form-label">Email Address</label>
                </div>

                <div class="form-group">
                    <input 
                        type="password" 
                        name="password" 
                        class="form-control" 
                        id="passwordField"
                        placeholder=" " 
                        required 
                        autocomplete="current-password">
                    <label class="form-label">Password</label>
                    <i class="bi bi-eye-slash password-toggle" id="togglePassword"></i>
                </div>

                <button type="submit" class="btn-login" id="loginBtn">
                    <span class="spinner"></span>
                    <span>Sign In</span>
                </button>
            </form>

            <div class="login-footer">
                Powered by <strong>MediaOn</strong> © <?= date('Y') ?>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // 1. Typing effect for subtitle
    const phrases = [
        "Manage bookings with ease",
        "Track vehicles in real-time",
        "Professional rental system",
        "Everything in one place"
    ];
    let phraseIndex = 0;
    let charIndex = 0;
    const typingText = document.getElementById('typingText');

    function type() {
        if (charIndex < phrases[phraseIndex].length) {
            typingText.textContent += phrases[phraseIndex].charAt(charIndex);
            charIndex++;
            setTimeout(type, 50);
        } else {
            setTimeout(erase, 2000);
        }
    }

    function erase() {
        if (charIndex > 0) {
            typingText.textContent = phrases[phraseIndex].substring(0, charIndex - 1);
            charIndex--;
            setTimeout(erase, 30);
        } else {
            phraseIndex = (phraseIndex + 1) % phrases.length;
            setTimeout(type, 500);
        }
    }

    setTimeout(type, 1000);

    // 2. Toggle password visibility
    const togglePassword = document.getElementById('togglePassword');
    const passwordField = document.getElementById('passwordField');

    togglePassword.addEventListener('click', function () {
        const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordField.setAttribute('type', type);
        this.classList.toggle('bi-eye');
        this.classList.toggle('bi-eye-slash');
    });

    // 3. Loading state on submit
    const loginForm = document.getElementById('loginForm');
    const loginBtn = document.getElementById('loginBtn');

    loginForm.addEventListener('submit', function () {
        loginBtn.classList.add('loading');
        loginBtn.disabled = true;
    });
});
</script>

</body>
</html>