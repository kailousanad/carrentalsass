<?php
require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$page_title = 'Maintenance / Oil Change';

$companyId = current_company_id();
if (!$companyId) die('Company ID not found.');

$errors = [];
$success = '';

// Helpers
function maintenance_badge($remainingKm)
{
    if ($remainingKm <= 0) return ['bg-danger', 'Maintenance due'];
    if ($remainingKm <= 200) return ['bg-danger', 'Urgent'];
    if ($remainingKm <= 500) return ['bg-warning text-dark', 'Soon'];
    return ['bg-success', 'OK'];
}

// -------------------- Handle POST (Add Maintenance) --------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $vehicle_id      = (int)($_POST['vehicle_id'] ?? 0);
    $oil_interval_km = (int)($_POST['oil_interval_km'] ?? 0);
    $oil_type        = trim($_POST['oil_type'] ?? '');
    $oil_brand       = trim($_POST['oil_brand'] ?? '');
    $oil_quantity    = trim($_POST['oil_quantity'] ?? '');
    $filter_oil      = isset($_POST['filter_oil']) ? 1 : 0;
    $filter_air      = isset($_POST['filter_air']) ? 1 : 0;
    $filter_fuel     = isset($_POST['filter_fuel']) ? 1 : 0;
    $garage_name     = trim($_POST['garage_name'] ?? '');
    $cost            = (float)($_POST['cost'] ?? 0);
    $notes           = trim($_POST['notes'] ?? '');

    if ($vehicle_id <= 0) $errors[] = 'Vehicle is required.';
    if (!in_array($oil_interval_km, [8000,10000,12000,15000,20000], true)) {
        $errors[] = 'Invalid oil interval.';
    }

    // Get current vehicle km
    $stmt = $pdo->prepare("SELECT mileage_current FROM vehicles WHERE id=:id AND company_id=:cid LIMIT 1");
    $stmt->execute(['id'=>$vehicle_id,'cid'=>$companyId]);
    $vehicle = $stmt->fetch();

    if (!$vehicle) {
        $errors[] = 'Vehicle not found.';
    }

    if (!$errors) {

        $km_at_service   = (int)$vehicle['mileage_current'];
        $next_service_km = $km_at_service + $oil_interval_km;

        $pdo->beginTransaction();
        try {
            // Close previous active maintenance
            $pdo->prepare("
                UPDATE vehicle_maintenances
                SET status='done'
                WHERE vehicle_id=:vid AND company_id=:cid AND status='active'
            ")->execute([
                'vid'=>$vehicle_id,
                'cid'=>$companyId
            ]);

            // Insert new maintenance
            $pdo->prepare("
                INSERT INTO vehicle_maintenances
                (company_id, vehicle_id, oil_interval_km, km_at_service, next_service_km,
                 oil_type, oil_brand, oil_quantity,
                 filter_oil, filter_air, filter_fuel,
                 garage_name, cost, notes)
                VALUES
                (:cid,:vid,:interval,:km_now,:km_next,
                 :oil_type,:oil_brand,:oil_qty,
                 :f_oil,:f_air,:f_fuel,
                 :garage,:cost,:notes)
            ")->execute([
                'cid'=>$companyId,
                'vid'=>$vehicle_id,
                'interval'=>$oil_interval_km,
                'km_now'=>$km_at_service,
                'km_next'=>$next_service_km,
                'oil_type'=>$oil_type ?: null,
                'oil_brand'=>$oil_brand ?: null,
                'oil_qty'=>$oil_quantity ?: null,
                'f_oil'=>$filter_oil,
                'f_air'=>$filter_air,
                'f_fuel'=>$filter_fuel,
                'garage'=>$garage_name ?: null,
                'cost'=>$cost,
                'notes'=>$notes ?: null,
            ]);

            // Create expense automatically
            if ($cost > 0) {
                $pdo->prepare("
                    INSERT INTO expenses (company_id, vehicle_id, amount, type, date, description)
                    VALUES (:cid,:vid,:amt,'maintenance',CURDATE(),'Oil change')
                ")->execute([
                    'cid'=>$companyId,
                    'vid'=>$vehicle_id,
                    'amt'=>$cost
                ]);
            }

            $pdo->commit();
            header('Location: maintenance.php?success=1');
            exit;

        } catch (Throwable $e) {
            $pdo->rollBack();
            $errors[] = $e->getMessage();
        }
    }
}

if (isset($_GET['success'])) {
    $success = 'Maintenance saved successfully.';
}

// -------------------- Load vehicles --------------------
$vehicles = $pdo->prepare("
    SELECT id, brand, model, plate_number, mileage_current
    FROM vehicles
    WHERE company_id=:cid AND status!='sold'
    ORDER BY brand
");
$vehicles->execute(['cid'=>$companyId]);
$vehicles = $vehicles->fetchAll();

// -------------------- Load maintenance list --------------------
$list = $pdo->prepare("
    SELECT m.*, v.brand, v.model, v.plate_number, v.mileage_current
    FROM vehicle_maintenances m
    JOIN vehicles v ON v.id = m.vehicle_id
    WHERE m.company_id=:cid
    ORDER BY m.id DESC
");
$list->execute(['cid'=>$companyId]);
$maintenances = $list->fetchAll();

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-md-10 p-4">
    <h5 class="mb-3">Maintenance / Oil Change</h5>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $e): ?>
                <div><?= htmlspecialchars($e) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- ADD FORM -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h6>Add oil change</h6>
            <form method="post" class="row g-2">

                <div class="col-md-4">
                    <label class="form-label">Vehicle</label>
                    <select name="vehicle_id" class="form-select" required>
                        <option value="">Select vehicle</option>
                        <?php foreach ($vehicles as $v): ?>
                            <option value="<?= (int)$v['id'] ?>">
                                <?= htmlspecialchars($v['brand'].' '.$v['model'].' - '.$v['plate_number']) ?>
                                (<?= (int)$v['mileage_current'] ?> km)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="form-label">Interval (km)</label>
                    <select name="oil_interval_km" class="form-select" required>
                        <option value="8000">8000</option>
                        <option value="10000">10000</option>
                        <option value="12000">12000</option>
                        <option value="15000">15000</option>
                        <option value="20000">20000</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Oil type</label>
                    <input type="text" name="oil_type" class="form-control">
                </div>

                <div class="col-md-3">
                    <label class="form-label">Oil brand</label>
                    <input type="text" name="oil_brand" class="form-control">
                </div>

                <div class="col-md-2">
                    <label class="form-label">Quantity (L)</label>
                    <input type="text" name="oil_quantity" class="form-control">
                </div>

                <div class="col-md-4 mt-4">
                    <label><input type="checkbox" name="filter_oil" checked> Oil filter</label><br>
                    <label><input type="checkbox" name="filter_air"> Air filter</label><br>
                    <label><input type="checkbox" name="filter_fuel"> Fuel filter</label>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Garage</label>
                    <input type="text" name="garage_name" class="form-control">
                </div>

                <div class="col-md-2">
                    <label class="form-label">Cost</label>
                    <input type="text" name="cost" class="form-control">
                </div>

                <div class="col-md-12">
                    <label class="form-label">Notes</label>
                    <textarea name="notes" class="form-control"></textarea>
                </div>

                <div class="col-md-12 text-end">
                    <button class="btn btn-primary">Save maintenance</button>
                </div>

            </form>
        </div>
    </div>

    <!-- LIST -->
    <div class="card shadow-sm">
        <div class="card-body">
            <h6>Maintenance history</h6>
            <div class="table-responsive">
                <table class="table table-sm align-middle">
                    <thead>
                    <tr>
                        <th>Vehicle</th>
                        <th>KM at service</th>
                        <th>Next service</th>
                        <th>Remaining</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($maintenances as $m): ?>
                        <?php
                        $remaining = $m['next_service_km'] - $m['mileage_current'];
                        [$cls,$label] = maintenance_badge($remaining);
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($m['brand'].' '.$m['model'].' ('.$m['plate_number'].')') ?></td>
                            <td><?= (int)$m['km_at_service'] ?> km</td>
                            <td><?= (int)$m['next_service_km'] ?> km</td>
                            <td><?= $remaining ?> km</td>
                            <td><span class="badge <?= $cls ?>"><?= $label ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
