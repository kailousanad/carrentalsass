<?php
// public/notifications.php - ULTRA Pro Notifications (UX + Filters + Search + Actions)

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$page_title = 'Notifications';

$companyId = current_company_id();
if (!$companyId) die('Company ID not found in session.');

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// =========================
// CSRF (simple)
// =========================
if (empty($_SESSION['_csrf'])) {
    $_SESSION['_csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['_csrf'];

// =========================
// Actions (POST)
// =========================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $token  = $_POST['_csrf'] ?? '';

    if (!hash_equals($csrf, (string)$token)) {
        http_response_code(403);
        die('Invalid CSRF token.');
    }

    // keep current filter/page after actions
    $filter = $_POST['filter'] ?? 'all';
    $p      = $_POST['p'] ?? '1';
    $redirectTo = 'notifications.php?filter=' . urlencode($filter) . '&p=' . urlencode($p);

    // Mark single read
    if ($action === 'read_one') {
        $nid = $_POST['id'] ?? '';
        if (ctype_digit((string)$nid)) {
            $stmt = $pdo->prepare("
                UPDATE notifications
                SET is_read = 1
                WHERE id = :id AND company_id = :cid
                LIMIT 1
            ");
            $stmt->execute(['id' => (int)$nid, 'cid' => $companyId]);
        }
        header("Location: $redirectTo");
        exit;
    }

    // Mark all read
    if ($action === 'read_all') {
        $pdo->prepare("
            UPDATE notifications
            SET is_read = 1
            WHERE company_id = :cid AND is_read = 0
        ")->execute(['cid' => $companyId]);

        header("Location: $redirectTo");
        exit;
    }

    // Delete one
    if ($action === 'delete_one') {
        $nid = $_POST['id'] ?? '';
        if (ctype_digit((string)$nid)) {
            $pdo->prepare("
                DELETE FROM notifications
                WHERE id = :id AND company_id = :cid
                LIMIT 1
            ")->execute(['id' => (int)$nid, 'cid' => $companyId]);
        }

        header("Location: $redirectTo");
        exit;
    }

    // Delete all read
    if ($action === 'delete_read') {
        $pdo->prepare("
            DELETE FROM notifications
            WHERE company_id = :cid AND is_read = 1
        ")->execute(['cid' => $companyId]);

        header("Location: $redirectTo");
        exit;
    }
}

// =========================
// Filters
// =========================
$filter = $_GET['filter'] ?? 'all'; // all | unread | oil | insurance | gps
$q = trim((string)($_GET['q'] ?? ''));

$allowed = ['all','unread','oil','insurance','gps'];
if (!in_array($filter, $allowed, true)) $filter = 'all';

$where = "n.company_id = :cid";
$params = ['cid' => $companyId];

if ($filter === 'unread') {
    $where .= " AND n.is_read = 0";
}
if ($filter === 'oil') {
    $where .= " AND n.type IN ('oil_change_soon','oil_change_urgent','oil_change_due')";
}
if ($filter === 'insurance') {
    $where .= " AND n.type IN ('insurance_expiring','insurance_cancelled')";
}
if ($filter === 'gps') {
    $where .= " AND n.type IN ('gps_expiring_7','gps_expiring_3','gps_expired')";
}

// Search (on type, created_at, and JSON data text)
if ($q !== '') {
    $where .= " AND (
        n.type LIKE :q OR
        n.created_at LIKE :q OR
        n.data LIKE :q
    )";
    $params['q'] = "%{$q}%";
}

// =========================
// Pagination
// =========================
$page = (isset($_GET['p']) && ctype_digit($_GET['p'])) ? max(1, (int)$_GET['p']) : 1;
$perPage = (int)($_GET['per_page'] ?? 20);
if (!in_array($perPage, [10,20,30,50,100], true)) $perPage = 20;
$offset = ($page - 1) * $perPage;

// =========================
// Counts (header pills)
// =========================
$counts = [
    'unread' => 0,
    'oil' => 0,
    'insurance' => 0,
    'gps' => 0,
    'total' => 0,
];

$st = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE company_id = :cid");
$st->execute(['cid'=>$companyId]);
$counts['total'] = (int)$st->fetchColumn();

$st = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE company_id=:cid AND is_read=0");
$st->execute(['cid'=>$companyId]);
$counts['unread'] = (int)$st->fetchColumn();

$st = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE company_id=:cid AND type IN ('oil_change_soon','oil_change_urgent','oil_change_due') AND is_read=0");
$st->execute(['cid'=>$companyId]);
$counts['oil'] = (int)$st->fetchColumn();

$st = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE company_id=:cid AND type IN ('insurance_expiring','insurance_cancelled') AND is_read=0");
$st->execute(['cid'=>$companyId]);
$counts['insurance'] = (int)$st->fetchColumn();

$st = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE company_id=:cid AND type IN ('gps_expiring_7','gps_expiring_3','gps_expired') AND is_read=0");
$st->execute(['cid'=>$companyId]);
$counts['gps'] = (int)$st->fetchColumn();

// Count filtered total (for pagination)
$st = $pdo->prepare("SELECT COUNT(*) FROM notifications n WHERE $where");
$st->execute($params);
$totalFiltered = (int)$st->fetchColumn();
$totalPages = max(1, (int)ceil($totalFiltered / $perPage));
if ($page > $totalPages) { $page = $totalPages; $offset = ($page - 1) * $perPage; }

// =========================
// Fetch rows
// =========================
$sql = "
    SELECT n.*
    FROM notifications n
    WHERE $where
    ORDER BY n.is_read ASC, n.id DESC
    LIMIT :limit OFFSET :offset
";
$stmt = $pdo->prepare($sql);
foreach ($params as $k=>$v) $stmt->bindValue(':'.$k, $v);
$stmt->bindValue(':limit', (int)$perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

// =========================
// Helpers
// =========================
function type_badge($type): array
{
    switch ($type) {
        case 'oil_change_due':     return ['bg-danger', 'Oil Due', 'bi-droplet-half'];
        case 'oil_change_urgent':  return ['bg-warning text-dark', 'Oil Urgent', 'bi-exclamation-triangle'];
        case 'oil_change_soon':    return ['bg-info text-dark', 'Oil Soon', 'bi-clock-history'];

        case 'insurance_expiring':  return ['bg-warning text-dark', 'Insurance Expiring', 'bi-shield-exclamation'];
        case 'insurance_cancelled': return ['bg-secondary', 'Insurance Cancelled', 'bi-shield-x'];

        case 'gps_expiring_7': return ['bg-info text-dark', 'GPS Expiring (7d)', 'bi-broadcast'];
        case 'gps_expiring_3': return ['bg-warning text-dark', 'GPS Expiring (3d)', 'bi-broadcast-pin'];
        case 'gps_expired':    return ['bg-danger', 'GPS Expired', 'bi-broadcast-off'];

        default: return ['bg-light text-dark', $type, 'bi-bell'];
    }
}

function render_message($type, $data): string
{
    $plate   = $data['plate'] ?? ($data['plate_number'] ?? '—');
    $vehicle = $data['vehicle'] ?? 'Vehicle';

    if ($type === 'oil_change_due') {
        $rem = $data['remaining_km'] ?? 0;
        $next = $data['next_service_km'] ?? null;
        return "Oil change is due now for $vehicle ($plate). Next service km: $next. Remaining: $rem km.";
    }
    if ($type === 'oil_change_urgent') {
        $rem = $data['remaining_km'] ?? 0;
        $next = $data['next_service_km'] ?? null;
        return "Oil change is urgent for $vehicle ($plate). Remaining: $rem km (next at $next).";
    }
    if ($type === 'oil_change_soon') {
        $rem = $data['remaining_km'] ?? 0;
        $next = $data['next_service_km'] ?? null;
        return "Oil change is coming soon for $vehicle ($plate). Remaining: $rem km (next at $next).";
    }

    if ($type === 'insurance_expiring') {
        $days = $data['days_left'] ?? null;
        $end = $data['end_date'] ?? null;
        return "Insurance expiring for $vehicle ($plate). Days left: $days. End date: $end.";
    }
    if ($type === 'insurance_cancelled') {
        $reason = $data['reason'] ?? 'Cancelled';
        return "Insurance cancelled for $vehicle ($plate). Reason: $reason.";
    }

    if ($type === 'gps_expiring_7' || $type === 'gps_expiring_3') {
        $days = $data['days_left'] ?? null;
        $end  = $data['end_date'] ?? null;
        $uid  = $data['device_uid'] ?? '—';
        return "GPS ($uid) is expiring soon for $vehicle ($plate). Days left: $days. End date: $end.";
    }
    if ($type === 'gps_expired') {
        $end  = $data['end_date'] ?? null;
        $uid  = $data['device_uid'] ?? '—';
        return "GPS ($uid) has expired for $vehicle ($plate). End date: $end.";
    }

    return "Notification for $vehicle ($plate).";
}

function qs(array $override = []): string {
    $q = array_merge($_GET, $override);
    foreach ($q as $k=>$v) if ($v === '' || $v === null) unset($q[$k]);
    return http_build_query($q);
}

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<link rel="stylesheet" href="assets/css/notifications.css?v=<?= time() ?>">

<main class="col-12 col-lg-10 p-4 ultra-notifs">

  <!-- Topbar -->
  <div class="un-topbar mb-3">
    <div>
      <div class="un-title">Notifications</div>
      <div class="un-sub text-muted">
        Oil change • Insurance • GPS • System alerts
        <span class="ms-2 un-dot">•</span>
        <span class="ms-2"><i class="bi bi-envelope me-1"></i><?= (int)$counts['unread'] ?> unread</span>
      </div>
    </div>

    <div class="d-flex gap-2 flex-wrap">
      <form method="post" class="d-inline" onsubmit="return UN.confirmForm(this,'Mark all read','Mark all notifications as read?');">
        <input type="hidden" name="action" value="read_all">
        <input type="hidden" name="_csrf" value="<?= h($csrf) ?>">
        <input type="hidden" name="filter" value="<?= h($filter) ?>">
        <input type="hidden" name="p" value="<?= (int)$page ?>">
        <button class="btn btn-outline-secondary rounded-pill">
          <i class="bi bi-check2-all me-2"></i>Mark all read
        </button>
      </form>

      <form method="post" class="d-inline" onsubmit="return UN.confirmForm(this,'Clean up','Delete all READ notifications?');">
        <input type="hidden" name="action" value="delete_read">
        <input type="hidden" name="_csrf" value="<?= h($csrf) ?>">
        <input type="hidden" name="filter" value="<?= h($filter) ?>">
        <input type="hidden" name="p" value="<?= (int)$page ?>">
        <button class="btn btn-outline-danger rounded-pill">
          <i class="bi bi-trash3 me-2"></i>Delete read
        </button>
      </form>
    </div>
  </div>

  <!-- Filter pills -->
  <div class="un-pills mb-3">
    <a class="un-pill <?= $filter==='all'?'is-active':'' ?>" href="notifications.php?<?= h(qs(['filter'=>'all','p'=>1])) ?>">
      <i class="bi bi-ui-checks-grid me-2"></i>All
      <span class="badge text-bg-light ms-2"><?= (int)$counts['total'] ?></span>
    </a>

    <a class="un-pill <?= $filter==='unread'?'is-active is-primary':'' ?>" href="notifications.php?<?= h(qs(['filter'=>'unread','p'=>1])) ?>">
      <i class="bi bi-envelope-open me-2"></i>Unread
      <span class="badge text-bg-light ms-2"><?= (int)$counts['unread'] ?></span>
    </a>

    <a class="un-pill <?= $filter==='oil'?'is-active is-danger':'' ?>" href="notifications.php?<?= h(qs(['filter'=>'oil','p'=>1])) ?>">
      <i class="bi bi-droplet me-2"></i>Oil
      <span class="badge text-bg-light ms-2"><?= (int)$counts['oil'] ?></span>
    </a>

    <a class="un-pill <?= $filter==='insurance'?'is-active is-warning':'' ?>" href="notifications.php?<?= h(qs(['filter'=>'insurance','p'=>1])) ?>">
      <i class="bi bi-shield-check me-2"></i>Insurance
      <span class="badge text-bg-light ms-2"><?= (int)$counts['insurance'] ?></span>
    </a>

    <a class="un-pill <?= $filter==='gps'?'is-active is-info':'' ?>" href="notifications.php?<?= h(qs(['filter'=>'gps','p'=>1])) ?>">
      <i class="bi bi-broadcast me-2"></i>GPS
      <span class="badge text-bg-light ms-2"><?= (int)$counts['gps'] ?></span>
    </a>
  </div>

  <!-- Search + perPage -->
  <div class="card un-card mb-3">
    <div class="card-body">
      <form method="get" class="row g-2 align-items-end">
        <div class="col-12 col-md-7">
          <label class="form-label">Search</label>
          <div class="position-relative">
            <i class="bi bi-search un-search-ico"></i>
            <input type="text" name="q" class="form-control ps-5" value="<?= h($q) ?>" placeholder="Plate, device UID, type, date…">
          </div>
        </div>

        <div class="col-6 col-md-3">
          <label class="form-label">Per page</label>
          <select name="per_page" class="form-select">
            <?php foreach ([10,20,30,50,100] as $n): ?>
              <option value="<?= $n ?>" <?= $perPage===$n?'selected':'' ?>><?= $n ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-6 col-md-2 d-grid">
          <input type="hidden" name="filter" value="<?= h($filter) ?>">
          <input type="hidden" name="p" value="1">
          <button class="btn btn-dark">Apply</button>
        </div>
      </form>

      <div class="small text-muted mt-2">
        Showing <b><?= count($rows) ?></b> of <b><?= (int)$totalFiltered ?></b> (filter: <b><?= h($filter) ?></b>)
      </div>
    </div>
  </div>

  <!-- List -->
  <div class="card un-card">
    <div class="card-body p-0">
      <?php if (!$rows): ?>
        <div class="text-center py-5 text-muted">
          <i class="bi bi-inbox fs-1 d-block mb-3"></i>
          No notifications found.
        </div>
      <?php else: ?>
        <div class="list-group list-group-flush">
          <?php foreach ($rows as $n): ?>
            <?php
              $data = [];
              if (!empty($n['data'])) {
                $decoded = json_decode($n['data'], true);
                if (is_array($decoded)) $data = $decoded;
              }

              [$cls, $label, $icon] = type_badge($n['type']);
              $msg = render_message($n['type'], $data);
              $isUnread = ((int)$n['is_read'] === 0);

              $vehicleId = !empty($data['vehicle_id']) ? (int)$data['vehicle_id'] : 0;
              $hasGpsLink = in_array($n['type'], ['gps_expiring_7','gps_expiring_3','gps_expired'], true);
              $hasMaint = isset($data['maintenance_id']);
            ?>
            <div class="list-group-item un-item <?= $isUnread ? 'is-unread' : '' ?>">
              <div class="un-left">
                <div class="un-meta">
                  <span class="badge rounded-pill <?= h($cls) ?>">
                    <i class="bi <?= h($icon) ?> me-1"></i><?= h($label) ?>
                  </span>
                  <?php if ($isUnread): ?>
                    <span class="badge rounded-pill bg-primary">New</span>
                  <?php endif; ?>
                  <span class="small text-muted">
                    <i class="bi bi-clock me-1"></i><?= h($n['created_at']) ?>
                  </span>
                </div>

                <div class="un-message"><?= h($msg) ?></div>

                <div class="un-links">
                  <?php if ($vehicleId): ?>
                    <a href="vehicles.php?edit=<?= $vehicleId ?>" class="text-decoration-none">
                      <i class="bi bi-car-front me-1"></i>Open vehicle
                    </a>
                  <?php endif; ?>

                  <?php if ($vehicleId && ($hasGpsLink || $hasMaint)): ?>
                    <span class="text-muted">•</span>
                  <?php endif; ?>

                  <?php if ($hasGpsLink): ?>
                    <a href="gps.php" class="text-decoration-none"><i class="bi bi-broadcast me-1"></i>Open GPS</a>
                  <?php endif; ?>

                  <?php if ($hasGpsLink && $hasMaint): ?>
                    <span class="text-muted">•</span>
                  <?php endif; ?>

                  <?php if ($hasMaint): ?>
                    <a href="maintenance.php" class="text-decoration-none"><i class="bi bi-wrench-adjustable me-1"></i>Open maintenance</a>
                  <?php endif; ?>
                </div>
              </div>

              <div class="un-right">
                <?php if ($isUnread): ?>
                  <form method="post" class="d-inline" onsubmit="return UN.confirmForm(this,'Mark read','Mark this notification as read?');">
                    <input type="hidden" name="action" value="read_one">
                    <input type="hidden" name="_csrf" value="<?= h($csrf) ?>">
                    <input type="hidden" name="id" value="<?= (int)$n['id'] ?>">
                    <input type="hidden" name="filter" value="<?= h($filter) ?>">
                    <input type="hidden" name="p" value="<?= (int)$page ?>">
                    <button class="btn btn-sm btn-outline-success rounded-pill">
                      <i class="bi bi-check2 me-1"></i>Read
                    </button>
                  </form>
                <?php else: ?>
                  <span class="badge text-bg-light rounded-pill">Read</span>
                <?php endif; ?>

                <form method="post" class="d-inline" onsubmit="return UN.confirmForm(this,'Delete','Delete this notification?');">
                  <input type="hidden" name="action" value="delete_one">
                  <input type="hidden" name="_csrf" value="<?= h($csrf) ?>">
                  <input type="hidden" name="id" value="<?= (int)$n['id'] ?>">
                  <input type="hidden" name="filter" value="<?= h($filter) ?>">
                  <input type="hidden" name="p" value="<?= (int)$page ?>">
                  <button class="btn btn-sm btn-outline-danger rounded-pill">
                    <i class="bi bi-trash me-1"></i>Delete
                  </button>
                </form>
              </div>
            </div>
          <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ($totalFiltered > $perPage): ?>
          <div class="un-footer">
            <div class="small text-muted">Page <?= (int)$page ?> of <?= (int)$totalPages ?></div>
            <div class="d-flex gap-2">
              <a class="btn btn-sm btn-outline-secondary <?= $page<=1?'disabled':'' ?>"
                 href="notifications.php?<?= h(qs(['p'=>max(1,$page-1)])) ?>">
                Prev
              </a>
              <a class="btn btn-sm btn-outline-secondary <?= $page>=$totalPages?'disabled':'' ?>"
                 href="notifications.php?<?= h(qs(['p'=>min($totalPages,$page+1)])) ?>">
                Next
              </a>
            </div>
          </div>
        <?php endif; ?>

      <?php endif; ?>
    </div>
  </div>

</main>

<!-- Confirm Modal -->
<div class="modal fade" id="unConfirm" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title" id="unConfirmTitle">Confirm</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="unConfirmBody">Are you sure?</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-danger" id="unConfirmGo">Yes</button>
      </div>
    </div>
  </div>
</div>

<script src="assets/js/notifications.js?v=<?= time() ?>"></script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
