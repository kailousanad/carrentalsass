<?php
// public/settings.php - ULTRA Pro Settings (Agency + Places + Prices)

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$page_title = 'Settings – Car Rental SaaS';

$companyId = current_company_id();
if (!$companyId) die('Company ID not found in session.');

$errors = [];
$success = '';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
if (!function_exists('e')) { function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }

function safe_redirect_success(string $key): void {
    header('Location: settings.php?success='.urlencode($key));
    exit;
}

// =========================
// Ensure company_settings row exists
// =========================
$st = $pdo->prepare("SELECT * FROM company_settings WHERE company_id = :cid LIMIT 1");
$st->execute(['cid' => $companyId]);
$settings = $st->fetch(PDO::FETCH_ASSOC);

if (!$settings) {
    $ins = $pdo->prepare("INSERT INTO company_settings (company_id) VALUES (:cid)");
    $ins->execute(['cid' => $companyId]);
    $st->execute(['cid' => $companyId]);
    $settings = $st->fetch(PDO::FETCH_ASSOC);
}

// =========================
// Helpers: fetch lists
// =========================
function fetch_places(PDO $pdo, int $companyId, string $q=''): array {
    $q = trim($q);
    $sql = "SELECT * FROM places WHERE company_id=:cid";
    $params = ['cid'=>$companyId];
    if ($q !== '') {
        $sql .= " AND (name LIKE :q OR city LIKE :q OR address LIKE :q OR type LIKE :q)";
        $params['q'] = "%{$q}%";
    }
    $sql .= " ORDER BY id DESC";
    $st = $pdo->prepare($sql);
    $st->execute($params);
    return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function fetch_prices(PDO $pdo, int $companyId, string $q=''): array {
    $q = trim($q);
    $sql = "
      SELECT pp.id, pp.pickup_place_id, pp.dropoff_place_id, pp.price,
             p1.name AS pickup_name, p2.name AS dropoff_name
      FROM place_prices pp
      JOIN places p1 ON p1.id = pp.pickup_place_id
      JOIN places p2 ON p2.id = pp.dropoff_place_id
      WHERE pp.company_id=:cid
    ";
    $params = ['cid'=>$companyId];
    if ($q !== '') {
        $sql .= " AND (p1.name LIKE :q OR p2.name LIKE :q)";
        $params['q'] = "%{$q}%";
    }
    $sql .= " ORDER BY pp.id DESC";
    $st = $pdo->prepare($sql);
    $st->execute($params);
    return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

// =========================
// GET filters
// =========================
$tab = (string)($_GET['tab'] ?? 'agency');
if (!in_array($tab, ['agency','places','prices'], true)) $tab = 'agency';

$qPlaces = trim((string)($_GET['q_places'] ?? ''));
$qPrices = trim((string)($_GET['q_prices'] ?? ''));

// =========================
// POST HANDLERS
// =========================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ---------- A) Save Agency Settings ----------
    if ($action === 'save_agency') {
        $agency_name       = trim($_POST['agency_name'] ?? '');
        $agency_ice        = trim($_POST['agency_ice'] ?? '');
        $agency_if         = trim($_POST['agency_if'] ?? '');
        $agency_rc         = trim($_POST['agency_rc'] ?? '');
        $agency_patente    = trim($_POST['agency_patente'] ?? '');
        $agency_cnss       = trim($_POST['agency_cnss'] ?? '');
        $agency_address    = trim($_POST['agency_address'] ?? '');
        $agency_city       = trim($_POST['agency_city'] ?? '');
        $agency_phone      = trim($_POST['agency_phone'] ?? '');
        $agency_email      = trim($_POST['agency_email'] ?? '');
        $agency_logo_path  = trim($_POST['agency_logo_path'] ?? '');
        $contract_terms    = trim($_POST['contract_terms'] ?? '');

        if ($agency_name === '') $errors[] = 'Agency name is required.';

        if (!$errors) {
            $up = $pdo->prepare("
                UPDATE company_settings SET
                    agency_name = :agency_name,
                    agency_ice = :agency_ice,
                    agency_if = :agency_if,
                    agency_rc = :agency_rc,
                    agency_patente = :agency_patente,
                    agency_cnss = :agency_cnss,
                    agency_address = :agency_address,
                    agency_city = :agency_city,
                    agency_phone = :agency_phone,
                    agency_email = :agency_email,
                    agency_logo_path = :agency_logo_path,
                    contract_terms = :contract_terms
                WHERE company_id = :cid
            ");
            $up->execute([
                'agency_name'      => $agency_name,
                'agency_ice'       => $agency_ice ?: null,
                'agency_if'        => $agency_if ?: null,
                'agency_rc'        => $agency_rc ?: null,
                'agency_patente'   => $agency_patente ?: null,
                'agency_cnss'      => $agency_cnss ?: null,
                'agency_address'   => $agency_address ?: null,
                'agency_city'      => $agency_city ?: null,
                'agency_phone'     => $agency_phone ?: null,
                'agency_email'     => $agency_email ?: null,
                'agency_logo_path' => $agency_logo_path ?: null,
                'contract_terms'   => $contract_terms ?: null,
                'cid'              => $companyId,
            ]);

            safe_redirect_success('agency');
        }
    }

    // ---------- B) Add Place ----------
    if ($action === 'add_place') {
        $name = trim($_POST['place_name'] ?? '');
        $type = $_POST['place_type'] ?? 'both';
        $city = trim($_POST['place_city'] ?? '');
        $address = trim($_POST['place_address'] ?? '');

        if ($name === '') $errors[] = 'Place name is required.';
        if (!in_array($type, ['pickup','dropoff','both'], true)) $type = 'both';

        if (!$errors) {
            $ins = $pdo->prepare("
                INSERT INTO places (company_id, name, type, city, address)
                VALUES (:cid, :name, :type, :city, :address)
            ");
            $ins->execute([
                'cid' => $companyId,
                'name' => $name,
                'type' => $type,
                'city' => $city ?: null,
                'address' => $address ?: null,
            ]);

            safe_redirect_success('place');
        }
    }

    // ---------- C) Update Place ----------
    if ($action === 'update_place') {
        $id = $_POST['place_id'] ?? '';
        $name = trim($_POST['place_name'] ?? '');
        $type = $_POST['place_type'] ?? 'both';
        $city = trim($_POST['place_city'] ?? '');
        $address = trim($_POST['place_address'] ?? '');

        if (!ctype_digit((string)$id)) $errors[] = 'Invalid place id.';
        if ($name === '') $errors[] = 'Place name is required.';
        if (!in_array($type, ['pickup','dropoff','both'], true)) $type = 'both';

        if (!$errors) {
            // Ensure belongs to company
            $chk = $pdo->prepare("SELECT id FROM places WHERE id=:id AND company_id=:cid");
            $chk->execute(['id'=>(int)$id,'cid'=>$companyId]);
            if (!$chk->fetchColumn()) {
                $errors[] = 'Invalid place (not in your company).';
            } else {
                $up = $pdo->prepare("
                  UPDATE places SET
                    name=:name, type=:type, city=:city, address=:address
                  WHERE id=:id AND company_id=:cid
                ");
                $up->execute([
                  'name'=>$name,
                  'type'=>$type,
                  'city'=>$city ?: null,
                  'address'=>$address ?: null,
                  'id'=>(int)$id,
                  'cid'=>$companyId,
                ]);
                safe_redirect_success('place_updated');
            }
        }
    }

    // ---------- D) Delete Place ----------
    if ($action === 'delete_place') {
        $id = $_POST['place_id'] ?? '';
        if (!ctype_digit((string)$id)) $errors[] = 'Invalid place id.';

        if (!$errors) {
            // Ensure belongs to company
            $chk = $pdo->prepare("SELECT id FROM places WHERE id=:id AND company_id=:cid");
            $chk->execute(['id'=>(int)$id,'cid'=>$companyId]);
            if (!$chk->fetchColumn()) {
                $errors[] = 'Invalid place (not in your company).';
            } else {
                // Optional: delete related prices first (avoid FK errors)
                $delPP = $pdo->prepare("
                  DELETE FROM place_prices
                  WHERE company_id=:cid AND (pickup_place_id=:id OR dropoff_place_id=:id)
                ");
                $delPP->execute(['cid'=>$companyId,'id'=>(int)$id]);

                $del = $pdo->prepare("DELETE FROM places WHERE id=:id AND company_id=:cid");
                $del->execute(['id'=>(int)$id,'cid'=>$companyId]);

                safe_redirect_success('place_deleted');
            }
        }
    }

    // ---------- E) Save Price (Upsert) ----------
    if ($action === 'save_price') {
        $pickup  = $_POST['pickup_place_id'] ?? '';
        $dropoff = $_POST['dropoff_place_id'] ?? '';
        $price   = $_POST['price'] ?? '0';

        if (!ctype_digit((string)$pickup))  $errors[] = 'Pickup is required.';
        if (!ctype_digit((string)$dropoff)) $errors[] = 'Dropoff is required.';
        if (!is_numeric($price)) $errors[] = 'Price must be numeric.';
        $price = (float)$price;

        if (!$errors) {
            // Verify places belong to same company
            $chk1 = $pdo->prepare("SELECT id FROM places WHERE id=:id AND company_id=:cid");
            $chk1->execute(['id'=>(int)$pickup,'cid'=>$companyId]);
            $ok1 = $chk1->fetchColumn();

            $chk1->execute(['id'=>(int)$dropoff,'cid'=>$companyId]);
            $ok2 = $chk1->fetchColumn();

            if (!$ok1 || !$ok2) {
                $errors[] = 'Invalid pickup/dropoff for this company.';
            } else {
                // Upsert by UNIQUE(company_id, pickup_place_id, dropoff_place_id)
                $up = $pdo->prepare("
                    INSERT INTO place_prices (company_id, pickup_place_id, dropoff_place_id, price)
                    VALUES (:cid, :pickup, :dropoff, :price)
                    ON DUPLICATE KEY UPDATE price=VALUES(price)
                ");
                $up->execute([
                    'cid'=>$companyId,
                    'pickup'=>(int)$pickup,
                    'dropoff'=>(int)$dropoff,
                    'price'=>$price,
                ]);

                safe_redirect_success('price');
            }
        }
    }

    // ---------- F) Update Price by id ----------
    if ($action === 'update_price') {
        $id = $_POST['price_id'] ?? '';
        $price = $_POST['price'] ?? '0';

        if (!ctype_digit((string)$id)) $errors[] = 'Invalid price id.';
        if (!is_numeric($price)) $errors[] = 'Price must be numeric.';
        $price = (float)$price;

        if (!$errors) {
            $chk = $pdo->prepare("SELECT id FROM place_prices WHERE id=:id AND company_id=:cid");
            $chk->execute(['id'=>(int)$id,'cid'=>$companyId]);
            if (!$chk->fetchColumn()) {
                $errors[] = 'Invalid price (not in your company).';
            } else {
                $up = $pdo->prepare("UPDATE place_prices SET price=:price WHERE id=:id AND company_id=:cid");
                $up->execute(['price'=>$price,'id'=>(int)$id,'cid'=>$companyId]);
                safe_redirect_success('price_updated');
            }
        }
    }

    // ---------- G) Delete Price ----------
    if ($action === 'delete_price') {
        $id = $_POST['price_id'] ?? '';
        if (!ctype_digit((string)$id)) $errors[] = 'Invalid price id.';

        if (!$errors) {
            $del = $pdo->prepare("DELETE FROM place_prices WHERE id=:id AND company_id=:cid");
            $del->execute(['id'=>(int)$id,'cid'=>$companyId]);
            safe_redirect_success('price_deleted');
        }
    }
}

// =========================
// Success message
// =========================
if (isset($_GET['success'])) $success = (string)$_GET['success'];

// =========================
// Fetch updated settings
// =========================
$st = $pdo->prepare("SELECT * FROM company_settings WHERE company_id = :cid LIMIT 1");
$st->execute(['cid' => $companyId]);
$settings = $st->fetch(PDO::FETCH_ASSOC) ?: [];

// =========================
// Fetch Places & Prices
// =========================
$places = fetch_places($pdo, (int)$companyId, $qPlaces);
$prices = fetch_prices($pdo, (int)$companyId, $qPrices);

// Simple stats
$stats = [
  'places' => count($places),
  'prices' => count($prices),
];

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<link rel="stylesheet" href="assets/css/settings.css?v=<?= time() ?>">

<main class="col-12 col-lg-10 p-4 ultra-settings">

  <!-- Top Header -->
  <div class="us-topbar mb-3">
    <div>
      <div class="us-title">Settings</div>
      <div class="us-sub text-muted">
        Agency info • Places • Pricing rules
        <span class="ms-2 us-dot">•</span>
        <span class="ms-2"><i class="bi bi-geo-alt me-1"></i><?= (int)$stats['places'] ?> places</span>
        <span class="ms-2"><i class="bi bi-cash-coin me-1"></i><?= (int)$stats['prices'] ?> prices</span>
      </div>
    </div>

    <div class="us-actions">
      <button class="btn btn-outline-secondary rounded-pill" type="button" id="btnScrollTop">
        <i class="bi bi-arrow-up"></i>
      </button>
    </div>
  </div>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-danger py-2">
      <?php foreach ($errors as $er): ?><div><?= h($er) ?></div><?php endforeach; ?>
    </div>
  <?php endif; ?>

  <?php if ($success): ?>
    <div class="alert alert-success py-2">
      <?php if ($success === 'agency'): ?>Agency settings saved successfully.<?php endif; ?>
      <?php if ($success === 'place'): ?>Place added successfully.<?php endif; ?>
      <?php if ($success === 'place_updated'): ?>Place updated successfully.<?php endif; ?>
      <?php if ($success === 'place_deleted'): ?>Place deleted successfully.<?php endif; ?>
      <?php if ($success === 'price'): ?>Price saved successfully.<?php endif; ?>
      <?php if ($success === 'price_updated'): ?>Price updated successfully.<?php endif; ?>
      <?php if ($success === 'price_deleted'): ?>Price deleted successfully.<?php endif; ?>
    </div>
  <?php endif; ?>

  <!-- Tabs -->
  <div class="card us-card mb-3">
    <div class="card-body p-2">
      <div class="us-tabs">
        <a class="us-tab <?= $tab==='agency'?'is-active':'' ?>" href="settings.php?<?= e(http_build_query(['tab'=>'agency'])) ?>">
          <i class="bi bi-building me-2"></i>Agency
        </a>
        <a class="us-tab <?= $tab==='places'?'is-active':'' ?>" href="settings.php?<?= e(http_build_query(['tab'=>'places'])) ?>">
          <i class="bi bi-geo me-2"></i>Places
        </a>
        <a class="us-tab <?= $tab==='prices'?'is-active':'' ?>" href="settings.php?<?= e(http_build_query(['tab'=>'prices'])) ?>">
          <i class="bi bi-currency-exchange me-2"></i>Prices
        </a>
      </div>
    </div>
  </div>

  <?php if ($tab === 'agency'): ?>
    <!-- AGENCY -->
    <div class="row g-3">
      <div class="col-12 col-xl-8">
        <div class="card us-card">
          <div class="card-body">
            <div class="us-head">
              <div>
                <div class="us-h1">Agency settings</div>
                <div class="us-hint text-muted">Used in contracts & printed documents</div>
              </div>
              <span class="badge text-bg-light"><i class="bi bi-file-earmark-text me-1"></i>Contracts</span>
            </div>

            <form method="post" class="mt-3">
              <input type="hidden" name="action" value="save_agency">

              <div class="row g-2">
                <div class="col-md-8">
                  <label class="form-label">Agency name *</label>
                  <input class="form-control" name="agency_name" value="<?= h($settings['agency_name'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                  <label class="form-label">City</label>
                  <input class="form-control" name="agency_city" value="<?= h($settings['agency_city'] ?? '') ?>">
                </div>
              </div>

              <div class="row g-2 mt-1">
                <div class="col-md-3">
                  <label class="form-label">ICE</label>
                  <input class="form-control" name="agency_ice" value="<?= h($settings['agency_ice'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                  <label class="form-label">IF</label>
                  <input class="form-control" name="agency_if" value="<?= h($settings['agency_if'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                  <label class="form-label">RC</label>
                  <input class="form-control" name="agency_rc" value="<?= h($settings['agency_rc'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                  <label class="form-label">Patente</label>
                  <input class="form-control" name="agency_patente" value="<?= h($settings['agency_patente'] ?? '') ?>">
                </div>
              </div>

              <div class="row g-2 mt-1">
                <div class="col-md-4">
                  <label class="form-label">CNSS</label>
                  <input class="form-control" name="agency_cnss" value="<?= h($settings['agency_cnss'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                  <label class="form-label">Phone</label>
                  <input class="form-control" name="agency_phone" value="<?= h($settings['agency_phone'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                  <label class="form-label">Email</label>
                  <input class="form-control" name="agency_email" value="<?= h($settings['agency_email'] ?? '') ?>">
                </div>
              </div>

              <div class="mt-2">
                <label class="form-label">Address</label>
                <input class="form-control" name="agency_address" value="<?= h($settings['agency_address'] ?? '') ?>">
              </div>

              <div class="mt-2">
                <label class="form-label">Logo URL (optional)</label>
                <input class="form-control" name="agency_logo_path" value="<?= h($settings['agency_logo_path'] ?? '') ?>" placeholder="https://.../logo.png">
                <div class="small text-muted mt-1">Later we can upgrade to file upload + storage.</div>
              </div>

              <div class="mt-2">
                <label class="form-label">Default contract terms</label>
                <textarea class="form-control" name="contract_terms" rows="6"><?= h($settings['contract_terms'] ?? '') ?></textarea>
              </div>

              <div class="mt-3 d-flex gap-2">
                <button class="btn btn-dark flex-fill">
                  <i class="bi bi-save me-2"></i>Save Agency Settings
                </button>
                <a class="btn btn-outline-secondary" href="settings.php?tab=agency">
                  Reset
                </a>
              </div>

            </form>
          </div>
        </div>
      </div>

      <div class="col-12 col-xl-4">
        <div class="card us-card">
          <div class="card-body">
            <div class="us-h1">Quick tips</div>
            <div class="us-hint text-muted mb-2">Make contracts look professional</div>

            <div class="us-tip">
              <i class="bi bi-check2-circle"></i>
              <div><b>Agency name</b> is required — used as header.</div>
            </div>
            <div class="us-tip">
              <i class="bi bi-image"></i>
              <div>Logo URL can be a direct PNG/JPG link.</div>
            </div>
            <div class="us-tip">
              <i class="bi bi-file-text"></i>
              <div>Write default terms once — reused in each contract.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($tab === 'places'): ?>
    <!-- PLACES -->
    <div class="row g-3">
      <div class="col-12 col-xl-5">
        <div class="card us-card">
          <div class="card-body">
            <div class="us-head">
              <div>
                <div class="us-h1">Places</div>
                <div class="us-hint text-muted">Pickup / Dropoff points (airports, hotels, cities…)</div>
              </div>
              <button class="btn btn-primary rounded-pill" type="button" data-bs-toggle="modal" data-bs-target="#placeModal">
                <i class="bi bi-plus-circle me-2"></i>Add place
              </button>
            </div>

            <form method="get" class="mt-3">
              <input type="hidden" name="tab" value="places">
              <div class="input-group">
                <span class="input-group-text"><i class="bi bi-search"></i></span>
                <input class="form-control" name="q_places" value="<?= e($qPlaces) ?>" placeholder="Search places… (name/city/address)">
                <button class="btn btn-outline-secondary" type="submit">Search</button>
              </div>
            </form>

            <div class="mt-3 us-mini text-muted">
              Total: <b><?= (int)$stats['places'] ?></b> places
            </div>
          </div>
        </div>
      </div>

      <div class="col-12 col-xl-7">
        <div class="card us-card">
          <div class="card-body">
            <div class="us-head">
              <div>
                <div class="us-h1">Your places</div>
                <div class="us-hint text-muted">Edit / delete — prices linked will be removed on delete</div>
              </div>
            </div>

            <div class="table-responsive mt-2">
              <table class="table table-sm align-middle us-table">
                <thead>
                  <tr>
                    <th style="width:80px;">ID</th>
                    <th>Name</th>
                    <th style="width:120px;">Type</th>
                    <th style="width:160px;">City</th>
                    <th class="text-end" style="width:160px;">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (!$places): ?>
                    <tr><td colspan="5" class="text-center text-muted py-4">No places found.</td></tr>
                  <?php else: foreach ($places as $p): ?>
                    <tr>
                      <td class="fw-bold">#<?= (int)$p['id'] ?></td>
                      <td>
                        <div class="fw-semibold"><?= h($p['name']) ?></div>
                        <div class="small text-muted"><?= h($p['address'] ?? '') ?></div>
                      </td>
                      <td><span class="badge text-bg-light"><?= h($p['type']) ?></span></td>
                      <td><?= h($p['city'] ?? '') ?></td>
                      <td class="text-end">
                        <button class="btn btn-sm btn-outline-secondary"
                                type="button"
                                data-place='<?= e(json_encode($p, JSON_UNESCAPED_UNICODE)) ?>'
                                onclick="openEditPlace(this)">
                          <i class="bi bi-pencil"></i>
                        </button>

                        <form method="post" class="d-inline" onsubmit="return confirmActionForm(this,'Delete place','This will also remove linked prices. Continue?');">
                          <input type="hidden" name="action" value="delete_place">
                          <input type="hidden" name="place_id" value="<?= (int)$p['id'] ?>">
                          <button class="btn btn-sm btn-outline-danger" type="submit">
                            <i class="bi bi-trash"></i>
                          </button>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; endif; ?>
                </tbody>
              </table>
            </div>

          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($tab === 'prices'): ?>
    <!-- PRICES -->
    <div class="row g-3">
      <div class="col-12 col-xl-5">
        <div class="card us-card">
          <div class="card-body">
            <div class="us-head">
              <div>
                <div class="us-h1">Prices</div>
                <div class="us-hint text-muted">Pickup → Dropoff fixed rules</div>
              </div>
              <button class="btn btn-success rounded-pill" type="button" data-bs-toggle="modal" data-bs-target="#priceModal">
                <i class="bi bi-plus-circle me-2"></i>Add / Update
              </button>
            </div>

            <form method="get" class="mt-3">
              <input type="hidden" name="tab" value="prices">
              <div class="input-group">
                <span class="input-group-text"><i class="bi bi-search"></i></span>
                <input class="form-control" name="q_prices" value="<?= e($qPrices) ?>" placeholder="Search prices… (pickup/dropoff)">
                <button class="btn btn-outline-secondary" type="submit">Search</button>
              </div>
            </form>

            <div class="mt-3 us-mini text-muted">
              Total: <b><?= (int)$stats['prices'] ?></b> price rules
            </div>
          </div>
        </div>
      </div>

      <div class="col-12 col-xl-7">
        <div class="card us-card">
          <div class="card-body">
            <div class="us-head">
              <div>
                <div class="us-h1">Pickup → Dropoff list</div>
                <div class="us-hint text-muted">Quick edit price inline</div>
              </div>
            </div>

            <div class="table-responsive mt-2">
              <table class="table table-sm align-middle us-table">
                <thead>
                  <tr>
                    <th>Pickup</th>
                    <th>Dropoff</th>
                    <th class="text-end" style="width:180px;">Price (MAD)</th>
                    <th class="text-end" style="width:150px;">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (!$prices): ?>
                    <tr><td colspan="4" class="text-center text-muted py-4">No prices found.</td></tr>
                  <?php else: foreach ($prices as $pp): ?>
                    <tr>
                      <td class="fw-semibold"><?= h($pp['pickup_name']) ?></td>
                      <td class="fw-semibold"><?= h($pp['dropoff_name']) ?></td>
                      <td class="text-end">
                        <form method="post" class="d-inline-flex gap-2 align-items-center us-inline"
                              onsubmit="usShowLoading();">
                          <input type="hidden" name="action" value="update_price">
                          <input type="hidden" name="price_id" value="<?= (int)$pp['id'] ?>">
                          <input type="number" step="0.01" min="0" class="form-control form-control-sm text-end"
                                 name="price" value="<?= e(number_format((float)$pp['price'], 2, '.', '')) ?>"
                                 style="max-width:140px;">
                          <button class="btn btn-sm btn-outline-dark" type="submit" title="Save">
                            <i class="bi bi-check2"></i>
                          </button>
                        </form>
                      </td>
                      <td class="text-end">
                        <button class="btn btn-sm btn-outline-secondary"
                                type="button"
                                data-price='<?= e(json_encode($pp, JSON_UNESCAPED_UNICODE)) ?>'
                                onclick="openEditPrice(this)">
                          <i class="bi bi-pencil"></i>
                        </button>

                        <form method="post" class="d-inline" onsubmit="return confirmActionForm(this,'Delete price','Delete this price rule?');">
                          <input type="hidden" name="action" value="delete_price">
                          <input type="hidden" name="price_id" value="<?= (int)$pp['id'] ?>">
                          <button class="btn btn-sm btn-outline-danger" type="submit">
                            <i class="bi bi-trash"></i>
                          </button>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; endif; ?>
                </tbody>
              </table>
            </div>

          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

</main>

<!-- ===========================
  Place Modal (Add/Edit)
=========================== -->
<div class="modal fade" id="placeModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title" id="placeModalTitle">Add place</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" id="placeForm" onsubmit="usShowLoading();">
        <div class="modal-body">
          <input type="hidden" name="action" id="placeAction" value="add_place">
          <input type="hidden" name="place_id" id="placeId" value="">

          <div class="row g-2">
            <div class="col-md-8">
              <label class="form-label">Place name *</label>
              <input class="form-control" name="place_name" id="placeName" required placeholder="e.g. Casablanca Airport (CMN)">
            </div>
            <div class="col-md-4">
              <label class="form-label">Type</label>
              <select class="form-select" name="place_type" id="placeType">
                <option value="both">Pickup & Dropoff</option>
                <option value="pickup">Pickup only</option>
                <option value="dropoff">Dropoff only</option>
              </select>
            </div>
          </div>

          <div class="row g-2 mt-1">
            <div class="col-md-4">
              <label class="form-label">City</label>
              <input class="form-control" name="place_city" id="placeCity" placeholder="Casablanca">
            </div>
            <div class="col-md-8">
              <label class="form-label">Address</label>
              <input class="form-control" name="place_address" id="placeAddress" placeholder="Terminal 1, Mohammed V Airport">
            </div>
          </div>

          <div class="us-note mt-3">
            <i class="bi bi-lightbulb"></i>
            <div><b>Tip:</b> Use consistent naming: “City – Area” or “Airport (Code)”.</div>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" onclick="resetPlaceModal()" data-bs-dismiss="modal">Close</button>
          <button class="btn btn-primary" type="submit" id="placeSaveBtn"><i class="bi bi-save me-2"></i>Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- ===========================
  Price Modal (Upsert)
=========================== -->
<div class="modal fade" id="priceModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title" id="priceModalTitle">Add / update price</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" id="priceForm" onsubmit="usShowLoading();">
        <div class="modal-body">
          <input type="hidden" name="action" id="priceAction" value="save_price">
          <input type="hidden" name="price_id" id="priceId" value="">

          <div class="row g-2">
            <div class="col-md-6">
              <label class="form-label">Pickup *</label>
              <select name="pickup_place_id" id="pickupSelect" class="form-select" required>
                <option value="">-- Select --</option>
                <?php foreach ($places as $p): ?>
                  <option value="<?= (int)$p['id'] ?>"><?= h($p['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Dropoff *</label>
              <select name="dropoff_place_id" id="dropoffSelect" class="form-select" required>
                <option value="">-- Select --</option>
                <?php foreach ($places as $p): ?>
                  <option value="<?= (int)$p['id'] ?>"><?= h($p['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="row g-2 mt-1">
            <div class="col-md-6">
              <label class="form-label">Price (MAD)</label>
              <input type="number" step="0.01" min="0" class="form-control" name="price" id="priceValue" value="0">
              <div class="small text-muted mt-1">Upsert: if rule exists, it will update the price.</div>
            </div>
            <div class="col-md-6">
              <label class="form-label">Quick presets</label>
              <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-sm btn-outline-secondary" type="button" onclick="setPricePreset(0)">0</button>
                <button class="btn btn-sm btn-outline-secondary" type="button" onclick="setPricePreset(50)">50</button>
                <button class="btn btn-sm btn-outline-secondary" type="button" onclick="setPricePreset(100)">100</button>
                <button class="btn btn-sm btn-outline-secondary" type="button" onclick="setPricePreset(200)">200</button>
                <button class="btn btn-sm btn-outline-secondary" type="button" onclick="setPricePreset(500)">500</button>
              </div>
            </div>
          </div>

          <div class="us-note mt-3">
            <i class="bi bi-shield-check"></i>
            <div><b>Note:</b> Pickup and Dropoff must belong to your company.</div>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" onclick="resetPriceModal()" data-bs-dismiss="modal">Close</button>
          <button class="btn btn-success" type="submit" id="priceSaveBtn"><i class="bi bi-save me-2"></i>Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Confirm Modal -->
<div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title" id="confirmTitle">Confirm</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="confirmBody">Are you sure?</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-danger" id="confirmGo">Yes, continue</button>
      </div>
    </div>
  </div>
</div>

<!-- Loading overlay -->
<div class="us-loading" id="usLoading" aria-hidden="true">
  <div class="us-loading__card">
    <div class="spinner-border" role="status" aria-hidden="true"></div>
    <div class="ms-3">
      <div class="fw-semibold">Saving…</div>
      <div class="text-muted small">Please wait</div>
    </div>
  </div>
</div>

<script src="assets/js/settings.js?v=<?= time() ?>"></script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
