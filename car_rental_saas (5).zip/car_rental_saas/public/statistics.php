<?php
// public/statistics.php  (ULTRA Dashboard)

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) redirect('index.php');

require_once __DIR__ . '/../config/config.php';

$page_title = 'Statistics (ULTRA)';
$companyId = current_company_id();
if (!$companyId) die('Company ID not found in session.');

date_default_timezone_set('Africa/Casablanca');

/**
 * =========================================================
 *  COLUMN MAPPING (edit once if needed)
 * =========================================================
 */
$MAP = [
  // bookings table
  'bookings_table'    => 'bookings',
  'b_id'              => 'id',
  'b_company_id'      => 'company_id',
  'b_created_at'      => 'created_at',
  'b_start_date'      => 'start_date',
  'b_end_date'        => 'end_date',
  'b_status'          => 'status',
  'b_vehicle_id'      => 'vehicle_id',
  'b_total_price'     => 'total_price',     // fallback: total_amount
  'b_total_price_alt' => 'total_amount',
  'b_customer_id'     => 'customer_id',     // optional
  'b_customer_name'   => 'customer_name',   // optional

  // vehicles table
  'vehicles_table'    => 'vehicles',
  'v_id'              => 'id',
  'v_company_id'      => 'company_id',
  'v_brand'           => 'brand',
  'v_model'           => 'model',
  'v_plate'           => 'plate_number',

  // notifications table
  'notifications_table' => 'notifications',
  'n_company_id'        => 'company_id',
  'n_is_read'           => 'is_read',
  'n_type'              => 'type',
  'n_created_at'        => 'created_at',

  // gps_subscriptions table (optional)
  'gps_table'         => 'gps_subscriptions',
  'g_company_id'      => 'company_id',
  'g_status'          => 'status',
  'g_end_date'        => 'end_date',

  // expenses table(s) (optional) — ULTRA will auto-detect
  // If you have a different table name, set it here.
  'expenses_table_primary'   => 'expenses',
  'expenses_table_secondary' => 'vehicle_expenses',

  // expenses columns (if table exists)
  'e_id'         => 'id',
  'e_company_id' => 'company_id',
  'e_vehicle_id' => 'vehicle_id',     // optional
  'e_amount'     => 'amount',
  'e_date'       => 'expense_date',   // fallback: date / created_at
  'e_date_alt1'  => 'date',
  'e_date_alt2'  => 'created_at',
];

// ---------------------- Helpers ----------------------
function safeFetchColumn(PDO $pdo, string $sql, array $params, $default = 0) {
    try { $st=$pdo->prepare($sql); $st->execute($params); $v=$st->fetchColumn(); return ($v!==false && $v!==null)?$v:$default; }
    catch (Throwable $e) { return $default; }
}
function safeFetchAll(PDO $pdo, string $sql, array $params): array {
    try { $st=$pdo->prepare($sql); $st->execute($params); $r=$st->fetchAll(PDO::FETCH_ASSOC); return is_array($r)?$r:[]; }
    catch (Throwable $e) { return []; }
}
function tableExists(PDO $pdo, string $table): bool {
    try { $st=$pdo->prepare("SHOW TABLES LIKE :t"); $st->execute(['t'=>$table]); return (bool)$st->fetchColumn(); }
    catch (Throwable $e) { return false; }
}
function colExists(PDO $pdo, string $table, string $col): bool {
    try { $st=$pdo->prepare("SHOW COLUMNS FROM `$table` LIKE :c"); $st->execute(['c'=>$col]); return (bool)$st->fetchColumn(); }
    catch (Throwable $e) { return false; }
}
function pct($num, $den, $dec=1) {
    if ($den <= 0) return 0;
    return round(($num / $den) * 100, $dec);
}
function money($v) { return number_format((float)$v, 2); }

// ---------------------- Date filters ----------------------
$range = $_GET['range'] ?? '30'; // 7 | 30 | 90 | custom
$start = $_GET['start'] ?? '';
$end   = $_GET['end'] ?? '';

if ($range !== 'custom') {
    $days = in_array($range, ['7','30','90'], true) ? (int)$range : 30;
    $endDate = date('Y-m-d');
    $startDate = date('Y-m-d', strtotime("-{$days} days"));
} else {
    $endDate = ($end && preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) ? $end : date('Y-m-d');
    $startDate = ($start && preg_match('/^\d{4}-\d{2}-\d{2}$/', $start)) ? $start : date('Y-m-d', strtotime('-30 days'));
}
$paramsRange = ['cid'=>$companyId, 'start'=>$startDate, 'end'=>$endDate];
$today = date('Y-m-d');
$daysInRange = (int) max(1, round((strtotime($endDate) - strtotime($startDate)) / 86400) + 1);

// ---------------------- Resolve tables & columns ----------------------
$B = $MAP['bookings_table'];
$V = $MAP['vehicles_table'];
$N = $MAP['notifications_table'];
$G = $MAP['gps_table'];

$priceCol = $MAP['b_total_price'];
if (!colExists($pdo, $B, $priceCol) && colExists($pdo, $B, $MAP['b_total_price_alt'])) {
    $priceCol = $MAP['b_total_price_alt'];
}

// expenses table auto-detect
$E = null;
if (tableExists($pdo, $MAP['expenses_table_primary'])) $E = $MAP['expenses_table_primary'];
elseif (tableExists($pdo, $MAP['expenses_table_secondary'])) $E = $MAP['expenses_table_secondary'];

$expenseDateCol = $MAP['e_date'];
if ($E) {
    if (!colExists($pdo, $E, $expenseDateCol)) {
        if (colExists($pdo, $E, $MAP['e_date_alt1'])) $expenseDateCol = $MAP['e_date_alt1'];
        elseif (colExists($pdo, $E, $MAP['e_date_alt2'])) $expenseDateCol = $MAP['e_date_alt2'];
    }
}

// ---------------------- KPIs ULTRA ----------------------
$kpi = [
  'bookings_total' => 0,
  'bookings_confirmed' => 0,
  'bookings_cancelled' => 0,
  'conversion_rate' => 0.0,
  'cancel_rate' => 0.0,

  'revenue' => 0.0,
  'avg_booking' => 0.0,

  'expenses' => 0.0,
  'profit' => 0.0,
  'profit_margin' => 0.0,

  'vehicles_total' => 0,
  'cars_busy_today' => 0,
  'cars_available_today' => 0,

  'booked_days_total' => 0,
  'utilization_rate' => 0.0,

  'notifications_unread' => 0,
  'insurance_alerts' => 0,
  'gps_alerts' => 0,
  'gps_active' => 0,
  'gps_expired' => 0,

  'mom_revenue' => 0.0,
  'mom_revenue_pct' => 0.0,
];

$kpi['bookings_total'] = (int) safeFetchColumn($pdo, "
  SELECT COUNT(*)
  FROM `$B`
  WHERE {$MAP['b_company_id']}=:cid
    AND DATE({$MAP['b_created_at']}) BETWEEN :start AND :end
", $paramsRange, 0);

$kpi['bookings_confirmed'] = (int) safeFetchColumn($pdo, "
  SELECT COUNT(*)
  FROM `$B`
  WHERE {$MAP['b_company_id']}=:cid
    AND DATE({$MAP['b_created_at']}) BETWEEN :start AND :end
    AND {$MAP['b_status']} IN ('confirmed','paid','completed')
", $paramsRange, 0);

$kpi['bookings_cancelled'] = (int) safeFetchColumn($pdo, "
  SELECT COUNT(*)
  FROM `$B`
  WHERE {$MAP['b_company_id']}=:cid
    AND DATE({$MAP['b_created_at']}) BETWEEN :start AND :end
    AND {$MAP['b_status']} IN ('cancelled','canceled','refused')
", $paramsRange, 0);

$kpi['conversion_rate'] = pct($kpi['bookings_confirmed'], $kpi['bookings_total']);
$kpi['cancel_rate'] = pct($kpi['bookings_cancelled'], $kpi['bookings_total']);

$kpi['revenue'] = (float) safeFetchColumn($pdo, "
  SELECT COALESCE(SUM($priceCol),0)
  FROM `$B`
  WHERE {$MAP['b_company_id']}=:cid
    AND DATE({$MAP['b_created_at']}) BETWEEN :start AND :end
    AND {$MAP['b_status']} IN ('confirmed','paid','completed')
", $paramsRange, 0.0);

$kpi['avg_booking'] = ($kpi['bookings_confirmed'] > 0) ? round($kpi['revenue'] / $kpi['bookings_confirmed'], 2) : 0.0;

$kpi['vehicles_total'] = (int) safeFetchColumn($pdo, "
  SELECT COUNT(*)
  FROM `$V`
  WHERE {$MAP['v_company_id']}=:cid
", ['cid'=>$companyId], 0);

// Busy cars today
$kpi['cars_busy_today'] = (int) safeFetchColumn($pdo, "
  SELECT COUNT(DISTINCT {$MAP['b_vehicle_id']})
  FROM `$B`
  WHERE {$MAP['b_company_id']}=:cid
    AND {$MAP['b_status']} IN ('confirmed','paid','completed')
    AND DATE({$MAP['b_start_date']}) <= :today
    AND DATE({$MAP['b_end_date']}) >= :today
    AND {$MAP['b_vehicle_id']} IS NOT NULL
", ['cid'=>$companyId, 'today'=>$today], 0);

$kpi['cars_available_today'] = max(0, $kpi['vehicles_total'] - $kpi['cars_busy_today']);

// Notifications
$kpi['notifications_unread'] = (int) safeFetchColumn($pdo, "
  SELECT COUNT(*)
  FROM `$N`
  WHERE {$MAP['n_company_id']}=:cid AND {$MAP['n_is_read']}=0
", ['cid'=>$companyId], 0);

$kpi['insurance_alerts'] = (int) safeFetchColumn($pdo, "
  SELECT COUNT(*)
  FROM `$N`
  WHERE {$MAP['n_company_id']}=:cid AND {$MAP['n_is_read']}=0
    AND {$MAP['n_type']} IN ('insurance_expiring','insurance_cancelled')
", ['cid'=>$companyId], 0);

$kpi['gps_alerts'] = (int) safeFetchColumn($pdo, "
  SELECT COUNT(*)
  FROM `$N`
  WHERE {$MAP['n_company_id']}=:cid AND {$MAP['n_is_read']}=0
    AND {$MAP['n_type']} IN ('gps_expiring_7','gps_expiring_3','gps_expired')
", ['cid'=>$companyId], 0);

// GPS subs
if (tableExists($pdo, $G)) {
  $kpi['gps_active'] = (int) safeFetchColumn($pdo, "
    SELECT COUNT(*) FROM `$G`
    WHERE {$MAP['g_company_id']}=:cid AND {$MAP['g_status']}='active'
  ", ['cid'=>$companyId], 0);

  $kpi['gps_expired'] = (int) safeFetchColumn($pdo, "
    SELECT COUNT(*) FROM `$G`
    WHERE {$MAP['g_company_id']}=:cid AND {$MAP['g_status']}='expired'
  ", ['cid'=>$companyId], 0);
}

// Expenses + profit (if expenses table exists)
if ($E && colExists($pdo, $E, $MAP['e_amount']) && colExists($pdo, $E, $MAP['e_company_id'])) {
  $kpi['expenses'] = (float) safeFetchColumn($pdo, "
    SELECT COALESCE(SUM({$MAP['e_amount']}),0)
    FROM `$E`
    WHERE {$MAP['e_company_id']}=:cid
      AND DATE($expenseDateCol) BETWEEN :start AND :end
  ", $paramsRange, 0.0);
}
$kpi['profit'] = $kpi['revenue'] - $kpi['expenses'];
$kpi['profit_margin'] = ($kpi['revenue'] > 0) ? round(($kpi['profit'] / $kpi['revenue']) * 100, 1) : 0.0;

// ---------------------- Utilization (overall) ----------------------
$bookingRanges = safeFetchAll($pdo, "
  SELECT {$MAP['b_start_date']} AS sd, {$MAP['b_end_date']} AS ed
  FROM `$B`
  WHERE {$MAP['b_company_id']}=:cid
    AND {$MAP['b_status']} IN ('confirmed','paid','completed')
    AND (
      DATE({$MAP['b_start_date']}) <= :end
      AND DATE({$MAP['b_end_date']}) >= :start
    )
", $paramsRange);

$bookedDays = 0;
$rangeStartTs = strtotime($startDate);
$rangeEndTs   = strtotime($endDate);
foreach ($bookingRanges as $r) {
  $sd = $r['sd'] ? strtotime(date('Y-m-d', strtotime($r['sd']))) : null;
  $ed = $r['ed'] ? strtotime(date('Y-m-d', strtotime($r['ed']))) : null;
  if (!$sd || !$ed) continue;
  $a = max($sd, $rangeStartTs);
  $b = min($ed, $rangeEndTs);
  if ($b >= $a) $bookedDays += (int) round(($b - $a)/86400) + 1;
}
$kpi['booked_days_total'] = $bookedDays;
$capacityDays = max(1, $kpi['vehicles_total'] * $daysInRange);
$kpi['utilization_rate'] = pct($bookedDays, $capacityDays, 1);

// ---------------------- MoM revenue (this month vs previous month) ----------------------
$monthStart = date('Y-m-01');
$monthEnd = date('Y-m-t');
$prevMonthStart = date('Y-m-01', strtotime('-1 month'));
$prevMonthEnd = date('Y-m-t', strtotime('-1 month'));

$thisMonthRev = (float) safeFetchColumn($pdo, "
  SELECT COALESCE(SUM($priceCol),0)
  FROM `$B`
  WHERE {$MAP['b_company_id']}=:cid
    AND {$MAP['b_status']} IN ('confirmed','paid','completed')
    AND DATE({$MAP['b_created_at']}) BETWEEN :s AND :e
", ['cid'=>$companyId, 's'=>$monthStart, 'e'=>$monthEnd], 0.0);

$prevMonthRev = (float) safeFetchColumn($pdo, "
  SELECT COALESCE(SUM($priceCol),0)
  FROM `$B`
  WHERE {$MAP['b_company_id']}=:cid
    AND {$MAP['b_status']} IN ('confirmed','paid','completed')
    AND DATE({$MAP['b_created_at']}) BETWEEN :s AND :e
", ['cid'=>$companyId, 's'=>$prevMonthStart, 'e'=>$prevMonthEnd], 0.0);

$kpi['mom_revenue'] = $thisMonthRev - $prevMonthRev;
$kpi['mom_revenue_pct'] = ($prevMonthRev > 0) ? round(($kpi['mom_revenue'] / $prevMonthRev) * 100, 1) : 0.0;

// ---------------------- Charts data ----------------------
$bookingsPerDay = safeFetchAll($pdo, "
  SELECT DATE({$MAP['b_created_at']}) AS d, COUNT(*) AS c
  FROM `$B`
  WHERE {$MAP['b_company_id']}=:cid
    AND DATE({$MAP['b_created_at']}) BETWEEN :start AND :end
  GROUP BY DATE({$MAP['b_created_at']})
  ORDER BY d ASC
", $paramsRange);

$revenuePerDay = safeFetchAll($pdo, "
  SELECT DATE({$MAP['b_created_at']}) AS d, COALESCE(SUM($priceCol),0) AS s
  FROM `$B`
  WHERE {$MAP['b_company_id']}=:cid
    AND DATE({$MAP['b_created_at']}) BETWEEN :start AND :end
    AND {$MAP['b_status']} IN ('confirmed','paid','completed')
  GROUP BY DATE({$MAP['b_created_at']})
  ORDER BY d ASC
", $paramsRange);

$byStatus = safeFetchAll($pdo, "
  SELECT {$MAP['b_status']} AS st, COUNT(*) AS c
  FROM `$B`
  WHERE {$MAP['b_company_id']}=:cid
    AND DATE({$MAP['b_created_at']}) BETWEEN :start AND :end
  GROUP BY {$MAP['b_status']}
  ORDER BY c DESC
", $paramsRange);

$revenueByMonth = safeFetchAll($pdo, "
  SELECT DATE_FORMAT({$MAP['b_created_at']}, '%Y-%m') AS m, COALESCE(SUM($priceCol),0) AS s
  FROM `$B`
  WHERE {$MAP['b_company_id']}=:cid
    AND {$MAP['b_status']} IN ('confirmed','paid','completed')
    AND DATE({$MAP['b_created_at']}) BETWEEN :start AND :end
  GROUP BY DATE_FORMAT({$MAP['b_created_at']}, '%Y-%m')
  ORDER BY m ASC
", $paramsRange);

// ---------------------- ULTRA Tables ----------------------
// Top vehicles (revenue + bookings)
$topVehicles = safeFetchAll($pdo, "
  SELECT v.{$MAP['v_id']} AS id,
         CONCAT(COALESCE(v.{$MAP['v_brand']},''),' ',COALESCE(v.{$MAP['v_model']},''),' — ',COALESCE(v.{$MAP['v_plate']},'')) AS name,
         COUNT(b.{$MAP['b_id']}) AS total,
         COALESCE(SUM(b.$priceCol),0) AS revenue
  FROM `$B` b
  JOIN `$V` v ON v.{$MAP['v_id']}=b.{$MAP['b_vehicle_id']}
  WHERE b.{$MAP['b_company_id']}=:cid
    AND DATE(b.{$MAP['b_created_at']}) BETWEEN :start AND :end
    AND b.{$MAP['b_status']} IN ('confirmed','paid','completed')
  GROUP BY v.{$MAP['v_id']}
  ORDER BY revenue DESC, total DESC
  LIMIT 10
", $paramsRange);

// Utilization per vehicle (booked days per car / daysInRange)
$vehicleRanges = safeFetchAll($pdo, "
  SELECT v.{$MAP['v_id']} AS vehicle_id,
         CONCAT(COALESCE(v.{$MAP['v_brand']},''),' ',COALESCE(v.{$MAP['v_model']},''),' — ',COALESCE(v.{$MAP['v_plate']},'')) AS vehicle_name,
         b.{$MAP['b_start_date']} AS sd,
         b.{$MAP['b_end_date']} AS ed
  FROM `$B` b
  JOIN `$V` v ON v.{$MAP['v_id']}=b.{$MAP['b_vehicle_id']}
  WHERE b.{$MAP['b_company_id']}=:cid
    AND b.{$MAP['b_status']} IN ('confirmed','paid','completed')
    AND b.{$MAP['b_vehicle_id']} IS NOT NULL
    AND (
      DATE(b.{$MAP['b_start_date']}) <= :end
      AND DATE(b.{$MAP['b_end_date']}) >= :start
    )
", $paramsRange);

$utilByVehicle = []; // vehicle_id => ['name'=>..., 'days'=>...]
foreach ($vehicleRanges as $r) {
  $vid = (int)$r['vehicle_id'];
  if (!isset($utilByVehicle[$vid])) {
    $utilByVehicle[$vid] = ['vehicle_id'=>$vid, 'name'=>$r['vehicle_name'] ?: ('Vehicle #'.$vid), 'days'=>0];
  }
  $sd = $r['sd'] ? strtotime(date('Y-m-d', strtotime($r['sd']))) : null;
  $ed = $r['ed'] ? strtotime(date('Y-m-d', strtotime($r['ed']))) : null;
  if (!$sd || !$ed) continue;

  $a = max($sd, $rangeStartTs);
  $b = min($ed, $rangeEndTs);
  if ($b >= $a) $utilByVehicle[$vid]['days'] += (int) round(($b - $a)/86400) + 1;
}
$utilRows = array_values($utilByVehicle);
usort($utilRows, fn($a,$b) => $b['days'] <=> $a['days']);

// Top customers
$hasCustomerName = colExists($pdo, $B, $MAP['b_customer_name']);
$hasCustomerId   = colExists($pdo, $B, $MAP['b_customer_id']);

$topCustomers = [];
if ($hasCustomerName || $hasCustomerId) {
  $customerExpr = $hasCustomerName ? $MAP['b_customer_name'] : $MAP['b_customer_id'];
  $topCustomers = safeFetchAll($pdo, "
    SELECT $customerExpr AS customer,
           COUNT({$MAP['b_id']}) AS total,
           COALESCE(SUM($priceCol),0) AS revenue
    FROM `$B`
    WHERE {$MAP['b_company_id']}=:cid
      AND DATE({$MAP['b_created_at']}) BETWEEN :start AND :end
      AND {$MAP['b_status']} IN ('confirmed','paid','completed')
    GROUP BY $customerExpr
    ORDER BY revenue DESC, total DESC
    LIMIT 10
  ", $paramsRange);
}

// Latest notifications
$latestNotifs = safeFetchAll($pdo, "
  SELECT id, {$MAP['n_type']} AS type, data, {$MAP['n_is_read']} AS is_read, {$MAP['n_created_at']} AS created_at
  FROM `$N`
  WHERE {$MAP['n_company_id']}=:cid
  ORDER BY id DESC
  LIMIT 10
", ['cid'=>$companyId]);

// ---------------------- Export CSV (ULTRA) ----------------------
if (isset($_GET['export']) && in_array($_GET['export'], ['bookings','utilization'], true)) {
    $export = $_GET['export'];

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="stats_'.$export.'_'.date('Ymd_His').'.csv"');

    $out = fopen('php://output', 'w');

    if ($export === 'bookings') {
        fputcsv($out, ['Booking ID','Created At','Status','Vehicle ID','Start Date','End Date','Total']);
        $rowsExp = safeFetchAll($pdo, "
          SELECT {$MAP['b_id']} AS id, {$MAP['b_created_at']} AS created_at, {$MAP['b_status']} AS status,
                 {$MAP['b_vehicle_id']} AS vehicle_id, {$MAP['b_start_date']} AS start_date, {$MAP['b_end_date']} AS end_date,
                 $priceCol AS total
          FROM `$B`
          WHERE {$MAP['b_company_id']}=:cid AND DATE({$MAP['b_created_at']}) BETWEEN :start AND :end
          ORDER BY {$MAP['b_id']} DESC
          LIMIT 5000
        ", $paramsRange);

        foreach ($rowsExp as $r) {
            fputcsv($out, [$r['id'], $r['created_at'], $r['status'], $r['vehicle_id'], $r['start_date'], $r['end_date'], $r['total']]);
        }
    }

    if ($export === 'utilization') {
        fputcsv($out, ['Vehicle ID','Vehicle','Booked Days','Days in Range','Utilization %']);
        foreach ($utilRows as $r) {
            $u = pct($r['days'], $daysInRange, 1);
            fputcsv($out, [$r['vehicle_id'], $r['name'], $r['days'], $daysInRange, $u]);
        }
    }

    fclose($out);
    exit;
}

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';

// Prepare JS arrays
$labelsBookings = array_map(fn($r) => $r['d'], $bookingsPerDay);
$valuesBookings = array_map(fn($r) => (int)$r['c'], $bookingsPerDay);

$labelsRevenue = array_map(fn($r) => $r['d'], $revenuePerDay);
$valuesRevenue = array_map(fn($r) => (float)$r['s'], $revenuePerDay);

$labelsStatus = array_map(fn($r) => (string)$r['st'], $byStatus);
$valuesStatus = array_map(fn($r) => (int)$r['c'], $byStatus);

$labelsRevM = array_map(fn($r) => $r['m'], $revenueByMonth);
$valuesRevM = array_map(fn($r) => (float)$r['s'], $revenueByMonth);

$labelsTopV = array_map(fn($r) => $r['name'] ?: ('Vehicle #'.$r['id']), $topVehicles);
$valuesTopVRevenue = array_map(fn($r) => (float)$r['revenue'], $topVehicles);
$valuesTopVCount = array_map(fn($r) => (int)$r['total'], $topVehicles);

// quick helpers for UI
$momArrow = $kpi['mom_revenue'] >= 0 ? '▲' : '▼';
$momCls = $kpi['mom_revenue'] >= 0 ? 'text-success' : 'text-danger';
?>

<div class="col-md-10 p-4">

  <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
    <div>
      <h5 class="mb-1">Statistics Dashboard (ULTRA)</h5>
      <div class="small text-muted">
        Period: <span class="fw-semibold"><?= htmlspecialchars($startDate) ?></span> → <span class="fw-semibold"><?= htmlspecialchars($endDate) ?></span>
        • Utilization = booked days / (fleet capacity).
      </div>
    </div>

    <form class="d-flex flex-wrap gap-2" method="get">
      <select class="form-select form-select-sm" name="range" onchange="this.form.submit()">
        <option value="7"  <?= $range==='7'?'selected':'' ?>>Last 7 days</option>
        <option value="30" <?= $range==='30'?'selected':'' ?>>Last 30 days</option>
        <option value="90" <?= $range==='90'?'selected':'' ?>>Last 90 days</option>
        <option value="custom" <?= $range==='custom'?'selected':'' ?>>Custom</option>
      </select>

      <?php if ($range==='custom'): ?>
        <input type="date" class="form-control form-control-sm" name="start" value="<?= htmlspecialchars($startDate) ?>">
        <input type="date" class="form-control form-control-sm" name="end" value="<?= htmlspecialchars($endDate) ?>">
        <button class="btn btn-sm btn-dark">Apply</button>
      <?php endif; ?>

      <div class="dropdown">
        <button class="btn btn-sm btn-outline-dark dropdown-toggle" type="button" data-bs-toggle="dropdown">
          Export CSV
        </button>
        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item" href="?range=<?= urlencode($range) ?>&start=<?= urlencode($startDate) ?>&end=<?= urlencode($endDate) ?>&export=bookings">Bookings (max 5000)</a></li>
          <li><a class="dropdown-item" href="?range=<?= urlencode($range) ?>&start=<?= urlencode($startDate) ?>&end=<?= urlencode($endDate) ?>&export=utilization">Utilization per vehicle</a></li>
        </ul>
      </div>
    </form>
  </div>

  <!-- KPIs ULTRA -->
  <div class="row g-3 mb-3">
    <div class="col-6 col-lg-3">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <div class="small text-muted">Revenue</div>
          <div class="fs-4 fw-bold"><?= money($kpi['revenue']) ?> MAD</div>
          <div class="small text-muted">Avg booking: <?= money($kpi['avg_booking']) ?> MAD</div>
          <div class="small <?= $momCls ?>">
            MoM: <?= $momArrow ?> <?= money($kpi['mom_revenue']) ?> (<?= number_format($kpi['mom_revenue_pct'],1) ?>%)
          </div>
        </div>
      </div>
    </div>

    <div class="col-6 col-lg-3">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <div class="small text-muted">Expenses <?= $E ? '' : '(not detected)' ?></div>
          <div class="fs-4 fw-bold"><?= money($kpi['expenses']) ?> MAD</div>
          <div class="small text-muted">Table: <?= $E ? htmlspecialchars($E) : '—' ?></div>
        </div>
      </div>
    </div>

    <div class="col-6 col-lg-3">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <div class="small text-muted">Profit</div>
          <div class="fs-4 fw-bold"><?= money($kpi['profit']) ?> MAD</div>
          <div class="small text-muted">Margin: <?= number_format($kpi['profit_margin'],1) ?>%</div>
        </div>
      </div>
    </div>

    <div class="col-6 col-lg-3">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <div class="small text-muted">Fleet utilization</div>
          <div class="fs-4 fw-bold"><?= number_format($kpi['utilization_rate'], 1) ?>%</div>
          <div class="small text-muted">
            Booked days: <?= (int)$kpi['booked_days_total'] ?> / <?= (int)($kpi['vehicles_total']*$daysInRange) ?>
          </div>
          <div class="small text-muted"><?= (int)$kpi['cars_busy_today'] ?> busy today • <?= (int)$kpi['cars_available_today'] ?> available</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bookings + Alerts -->
  <div class="row g-3 mb-3">
    <div class="col-lg-8">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <div class="d-flex justify-content-between flex-wrap gap-2">
            <div>
              <div class="small text-muted">Bookings</div>
              <div class="fs-5 fw-bold"><?= (int)$kpi['bookings_total'] ?></div>
              <div class="small text-muted">
                Confirmed: <?= (int)$kpi['bookings_confirmed'] ?> • Cancelled: <?= (int)$kpi['bookings_cancelled'] ?>
              </div>
            </div>

            <div class="text-end">
              <div class="small text-muted">Conversion / Cancel rate</div>
              <div class="fs-5 fw-bold"><?= number_format($kpi['conversion_rate'],1) ?>%</div>
              <div class="small text-muted">Cancel: <?= number_format($kpi['cancel_rate'],1) ?>%</div>
            </div>

            <div class="text-end">
              <div class="small text-muted">Unread Alerts</div>
              <div class="fs-5 fw-bold"><?= (int)$kpi['notifications_unread'] ?></div>
              <div class="small text-muted">Insurance: <?= (int)$kpi['insurance_alerts'] ?> • GPS: <?= (int)$kpi['gps_alerts'] ?></div>
              <div class="mt-2">
                <a class="btn btn-sm btn-outline-dark" href="notifications.php">Open notifications</a>
              </div>
            </div>
          </div>

          <hr>

          <div class="d-flex flex-wrap gap-2">
            <a class="btn btn-sm btn-outline-primary" href="vehicles.php">Vehicles</a>
            <a class="btn btn-sm btn-outline-primary" href="gps.php">GPS</a>
            <a class="btn btn-sm btn-outline-primary" href="bookings.php">Bookings</a>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="card shadow-sm h-100">
        <div class="card-header fw-semibold">GPS Subscriptions</div>
        <div class="card-body">
          <div class="d-flex justify-content-between">
            <div>
              <div class="small text-muted">Active</div>
              <div class="fs-4 fw-bold"><?= (int)$kpi['gps_active'] ?></div>
            </div>
            <div class="text-end">
              <div class="small text-muted">Expired</div>
              <div class="fs-4 fw-bold"><?= (int)$kpi['gps_expired'] ?></div>
            </div>
          </div>
          <div class="small text-muted mt-2">Alerts (unread): <?= (int)$kpi['gps_alerts'] ?></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Charts -->
  <div class="row g-3 mb-3">
    <div class="col-lg-6">
      <div class="card shadow-sm">
        <div class="card-header fw-semibold">Bookings per day</div>
        <div class="card-body">
          <canvas id="chartBookings" height="130"></canvas>
          <?php if (!$bookingsPerDay): ?><div class="small text-muted mt-2">No bookings data.</div><?php endif; ?>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="card shadow-sm">
        <div class="card-header fw-semibold">Revenue per day</div>
        <div class="card-body">
          <canvas id="chartRevenue" height="130"></canvas>
          <?php if (!$revenuePerDay): ?><div class="small text-muted mt-2">No revenue data.</div><?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <div class="row g-3 mb-3">
    <div class="col-lg-6">
      <div class="card shadow-sm">
        <div class="card-header fw-semibold">Bookings by status</div>
        <div class="card-body">
          <canvas id="chartStatus" height="140"></canvas>
          <?php if (!$byStatus): ?><div class="small text-muted mt-2">No status data.</div><?php endif; ?>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="card shadow-sm">
        <div class="card-header fw-semibold">Revenue by month</div>
        <div class="card-body">
          <canvas id="chartRevMonth" height="140"></canvas>
          <?php if (!$revenueByMonth): ?><div class="small text-muted mt-2">No monthly data.</div><?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Tables ULTRA -->
  <div class="row g-3">
    <div class="col-lg-7">
      <div class="card shadow-sm">
        <div class="card-header fw-semibold">Top vehicles (Revenue + Bookings)</div>
        <div class="card-body">
          <?php if (!$topVehicles): ?>
            <div class="text-muted">No top vehicles data.</div>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table table-sm align-middle">
                <thead>
                  <tr>
                    <th>Vehicle</th>
                    <th class="text-end">Bookings</th>
                    <th class="text-end">Revenue</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($topVehicles as $r): ?>
                    <tr>
                      <td class="fw-semibold"><?= htmlspecialchars($r['name'] ?: ('Vehicle #'.$r['id'])) ?></td>
                      <td class="text-end"><?= (int)$r['total'] ?></td>
                      <td class="text-end"><?= money($r['revenue']) ?> MAD</td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
            <canvas id="chartTopVehiclesRevenue" height="120"></canvas>
          <?php endif; ?>
        </div>
      </div>

      <div class="card shadow-sm mt-3">
        <div class="card-header fw-semibold">Utilization per vehicle (Booked days)</div>
        <div class="card-body">
          <?php if (!$utilRows): ?>
            <div class="text-muted">No utilization data (no confirmed bookings with dates).</div>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table table-sm align-middle">
                <thead>
                  <tr>
                    <th>Vehicle</th>
                    <th class="text-end">Booked days</th>
                    <th class="text-end">Utilization</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach (array_slice($utilRows, 0, 12) as $r): ?>
                    <?php $u = pct($r['days'], $daysInRange, 1); ?>
                    <tr>
                      <td class="fw-semibold"><?= htmlspecialchars($r['name']) ?></td>
                      <td class="text-end"><?= (int)$r['days'] ?></td>
                      <td class="text-end"><?= number_format($u,1) ?>%</td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
            <div class="small text-muted">Days in range: <?= (int)$daysInRange ?> • Showing top 12</div>
          <?php endif; ?>
        </div>
      </div>

    </div>

    <div class="col-lg-5">
      <div class="card shadow-sm">
        <div class="card-header fw-semibold">Top customers</div>
        <div class="card-body">
          <?php if (!$topCustomers): ?>
            <div class="text-muted">No customer data (customer_name/customer_id not found).</div>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table table-sm align-middle">
                <thead>
                  <tr>
                    <th>Customer</th>
                    <th class="text-end">Bookings</th>
                    <th class="text-end">Revenue</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($topCustomers as $r): ?>
                    <tr>
                      <td class="fw-semibold"><?= htmlspecialchars((string)$r['customer']) ?></td>
                      <td class="text-end"><?= (int)$r['total'] ?></td>
                      <td class="text-end"><?= money($r['revenue']) ?> MAD</td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <div class="card shadow-sm mt-3">
        <div class="card-header fw-semibold d-flex justify-content-between align-items-center">
          <span>Latest alerts</span>
          <a class="btn btn-sm btn-outline-dark" href="notifications.php">Open</a>
        </div>
        <div class="card-body">
          <?php if (!$latestNotifs): ?>
            <div class="text-muted">No notifications.</div>
          <?php else: ?>
            <div class="list-group">
              <?php foreach ($latestNotifs as $n): ?>
                <?php
                  $isUnread = ((int)$n['is_read'] === 0);
                  $data = [];
                  if (!empty($n['data'])) {
                    $decoded = json_decode($n['data'], true);
                    if (is_array($decoded)) $data = $decoded;
                  }
                  $vehicle = $data['vehicle'] ?? '—';
                  $plate = $data['plate'] ?? ($data['plate_number'] ?? '—');
                ?>
                <div class="list-group-item d-flex justify-content-between align-items-start <?= $isUnread ? 'bg-light' : '' ?>">
                  <div class="me-3">
                    <div class="small text-muted"><?= htmlspecialchars($n['created_at']) ?></div>
                    <div class="fw-semibold"><?= htmlspecialchars($n['type']) ?></div>
                    <div class="small"><?= htmlspecialchars($vehicle) ?> (<?= htmlspecialchars($plate) ?>)</div>
                  </div>
                  <div class="text-end">
                    <?= $isUnread ? '<span class="badge bg-primary">New</span>' : '<span class="small text-muted">Read</span>' ?>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>

    </div>
  </div>

</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
  const bookingsLabels = <?= json_encode($labelsBookings, JSON_UNESCAPED_UNICODE) ?>;
  const bookingsValues = <?= json_encode($valuesBookings, JSON_UNESCAPED_UNICODE) ?>;

  const revenueLabels = <?= json_encode($labelsRevenue, JSON_UNESCAPED_UNICODE) ?>;
  const revenueValues = <?= json_encode($valuesRevenue, JSON_UNESCAPED_UNICODE) ?>;

  const statusLabels  = <?= json_encode($labelsStatus, JSON_UNESCAPED_UNICODE) ?>;
  const statusValues  = <?= json_encode($valuesStatus, JSON_UNESCAPED_UNICODE) ?>;

  const revMLabels = <?= json_encode($labelsRevM, JSON_UNESCAPED_UNICODE) ?>;
  const revMValues = <?= json_encode($valuesRevM, JSON_UNESCAPED_UNICODE) ?>;

  const topLabels = <?= json_encode($labelsTopV, JSON_UNESCAPED_UNICODE) ?>;
  const topRevenue = <?= json_encode($valuesTopVRevenue, JSON_UNESCAPED_UNICODE) ?>;

  // Bookings line
  const ctxB = document.getElementById('chartBookings');
  if (ctxB) new Chart(ctxB, {
    type: 'line',
    data: { labels: bookingsLabels, datasets: [{ label:'Bookings', data: bookingsValues, tension: 0.35 }] },
    options: { responsive:true, scales:{ y:{ beginAtZero:true } } }
  });

  // Revenue bar
  const ctxR = document.getElementById('chartRevenue');
  if (ctxR) new Chart(ctxR, {
    type: 'bar',
    data: { labels: revenueLabels, datasets: [{ label:'Revenue', data: revenueValues }] },
    options: { responsive:true, scales:{ y:{ beginAtZero:true } } }
  });

  // Status pie
  const ctxS = document.getElementById('chartStatus');
  if (ctxS) new Chart(ctxS, {
    type: 'pie',
    data: { labels: statusLabels, datasets: [{ label:'Status', data: statusValues }] },
    options: { responsive:true }
  });

  // Revenue by month
  const ctxM = document.getElementById('chartRevMonth');
  if (ctxM) new Chart(ctxM, {
    type: 'line',
    data: { labels: revMLabels, datasets: [{ label:'Revenue/month', data: revMValues, tension: 0.35 }] },
    options: { responsive:true, scales:{ y:{ beginAtZero:true } } }
  });

  // Top vehicles revenue
  const ctxT = document.getElementById('chartTopVehiclesRevenue');
  if (ctxT) new Chart(ctxT, {
    type: 'bar',
    data: { labels: topLabels, datasets: [{ label:'Revenue', data: topRevenue }] },
    options: { responsive:true, scales:{ y:{ beginAtZero:true } } }
  });
</script>

<?php require_once __DIR__ . '/../templates/footer.php'; ?>
