<?php
// public/users.php

require_once __DIR__ . '/../includes/auth.php';
require_super_admin(); // غير السوبر أدمن يقدر يدخل لهاد الصفحة

require_once __DIR__ . '/../config/config.php';

$page_title = 'Users – Car Rental SaaS';

$errors  = [];
$success = '';

// ----------------- جلب الشركات للـ select -----------------
$stmt = $pdo->query("SELECT id, name FROM companies ORDER BY name ASC");
$companies = $stmt->fetchAll();

// ----------------- جلب user للتعديل -----------------
$edit_user = null;
if (isset($_GET['edit']) && ctype_digit($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id LIMIT 1");
    $stmt->execute(['id' => $id]);
    $edit_user = $stmt->fetch();
}

// ----------------- معالجة POST (إضافة / تعديل) -----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id          = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $name        = trim($_POST['name'] ?? '');
    $email       = trim($_POST['email'] ?? '');
    $phone       = trim($_POST['phone'] ?? '');
    $company_id  = trim($_POST['company_id'] ?? '');
    $password    = trim($_POST['password'] ?? '');
    $is_super    = isset($_POST['is_super_admin']) ? 1 : 0;
    $is_active   = isset($_POST['is_active']) ? 1 : 0;

    if ($name === '')  $errors[] = 'Name is required.';
    if ($email === '') $errors[] = 'Email is required.';

    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format.';
    }

    if ($id === 0 && $password === '') {
        $errors[] = 'Password is required for new users.';
    }

    // company_id يمكن تكون null للسوبر أدمن
    if ($company_id !== '' && !ctype_digit($company_id)) {
        $errors[] = 'Invalid company selection.';
    }

    if (empty($errors)) {

        // كنجهز data المشتركة
        $data = [
            'name'        => $name,
            'email'       => $email,
            'phone'       => $phone ?: null,
            'company_id'  => $company_id !== '' ? (int)$company_id : null,
            'is_super_admin' => $is_super,
            'is_active'      => $is_active,
        ];

        // password:
        // في الـ SQL استعملنا MD5('admin123')، باش نبقاو متوافقين غادي نستعمل md5 هنا
        if ($id === 0 || $password !== '') {
            $data['password'] = md5($password);
        }

        // كنشيك واش email موجود عند user آخر
        $sqlCheck = "SELECT id FROM users WHERE email = :email";
        if ($id > 0) {
            $sqlCheck .= " AND id != :id";
        }
        $stmtCheck = $pdo->prepare($sqlCheck);
        $paramsCheck = ['email' => $email];
        if ($id > 0) $paramsCheck['id'] = $id;
        $stmtCheck->execute($paramsCheck);
        if ($stmtCheck->fetch()) {
            $errors[] = 'Email already used by another user.';
        } else {

            if (empty($errors)) {
                if ($id > 0) {
                    // UPDATE
                    $sql = "UPDATE users SET 
                                name = :name,
                                email = :email,
                                phone = :phone,
                                company_id = :company_id,
                                is_super_admin = :is_super_admin,
                                is_active = :is_active";

                    if ($password !== '') {
                        $sql .= ", password = :password";
                    }

                    $sql .= " WHERE id = :id";

                    $data['id'] = $id;

                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($data);

                    $success = 'User updated successfully.';
                } else {
                    // INSERT
                    $sql = "INSERT INTO users 
                                (name, email, password, phone, company_id, is_super_admin, is_active)
                            VALUES 
                                (:name, :email, :password, :phone, :company_id, :is_super_admin, :is_active)";

                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($data);

                    $success = 'New user created successfully.';
                }

                header('Location: users.php?success=1');
                exit;
            }
        }
    }
}

if (isset($_GET['success'])) {
    $success = 'Changes saved successfully.';
}

// ----------------- جلب جميع المستخدمين -----------------
$stmt = $pdo->query("
    SELECT u.*, c.name AS company_name
    FROM users u
    LEFT JOIN companies c ON u.company_id = c.id
    ORDER BY u.id DESC
");
$users = $stmt->fetchAll();

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-md-10 p-4">

    <div class="topbar d-flex justify-content-between align-items-center px-3 py-2 mb-3">
        <h5 class="mb-0">Users Management</h5>
    </div>

    <div class="row g-3">
        <!-- FORM ADD / EDIT -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="card-title mb-3">
                        <?= $edit_user ? 'Edit user' : 'Add new user' ?>
                    </h6>

                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger py-2">
                            <?php foreach ($errors as $err): ?>
                                <div><?= htmlspecialchars($err) ?></div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($success && empty($errors) && !isset($_GET['success'])): ?>
                        <div class="alert alert-success py-2"><?= htmlspecialchars($success) ?></div>
                    <?php endif; ?>

                    <form method="post" action="users.php<?= $edit_user ? '?edit=' . (int)$edit_user['id'] : '' ?>">
                        <input type="hidden" name="id" value="<?= $edit_user ? (int)$edit_user['id'] : 0 ?>">

                        <div class="mb-2">
                            <label class="form-label">Name *</label>
                            <input type="text" name="name" class="form-control"
                                   value="<?= htmlspecialchars($edit_user['name'] ?? '') ?>" required>
                        </div>

                        <div class="mb-2">
                            <label class="form-label">Email *</label>
                            <input type="email" name="email" class="form-control"
                                   value="<?= htmlspecialchars($edit_user['email'] ?? '') ?>" required>
                        </div>

                        <div class="mb-2">
                            <label class="form-label">Phone</label>
                            <input type="text" name="phone" class="form-control"
                                   value="<?= htmlspecialchars($edit_user['phone'] ?? '') ?>">
                        </div>

                        <div class="mb-2">
                            <label class="form-label">Company (Agency)</label>
                            <select name="company_id" class="form-select">
                                <option value="">-- Super Admin / No Company --</option>
                                <?php foreach ($companies as $c): ?>
                                    <option value="<?= (int)$c['id'] ?>"
                                        <?= (isset($edit_user['company_id']) && (int)$edit_user['company_id'] === (int)$c['id']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($c['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text small">
                                اختر وكالة الكراء التي ينتمي إليها هذا المستخدم.
                            </div>
                        </div>

                        <div class="mb-2">
                            <label class="form-label">
                                Password <?= $edit_user ? '(laisser vide si pas de changement)' : '*' ?>
                            </label>
                            <input type="password" name="password" class="form-control">
                        </div>

                        <div class="form-check mb-1">
                            <input class="form-check-input" type="checkbox" name="is_super_admin" id="is_super_admin"
                                   <?= isset($edit_user['is_super_admin']) && $edit_user['is_super_admin'] ? 'checked' : '' ?>>
                            <label class="form-check-label" for="is_super_admin">
                                Super Admin
                            </label>
                        </div>

                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" name="is_active" id="is_active"
                                   <?= (!isset($edit_user['is_active']) || $edit_user['is_active']) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="is_active">
                                Active user
                            </label>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">
                            <?= $edit_user ? 'Save changes' : 'Add user' ?>
                        </button>

                        <?php if ($edit_user): ?>
                            <a href="users.php" class="btn btn-link w-100 mt-1">Cancel edit</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

        <!-- LIST USERS -->
        <div class="col-md-8">
            <?php if ($success && isset($_GET['success'])): ?>
                <div class="alert alert-success py-2"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>

            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="card-title mb-3">All users</h6>

                    <div class="table-responsive">
                        <table class="table table-sm align-middle">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name / Email</th>
                                <th>Company</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if (!$users): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted">No users found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($users as $u): ?>
                                    <tr>
                                        <td><?= (int)$u['id'] ?></td>
                                        <td>
                                            <div class="fw-semibold"><?= htmlspecialchars($u['name']) ?></div>
                                            <div class="small text-muted"><?= htmlspecialchars($u['email']) ?></div>
                                        </td>
                                        <td class="small">
                                            <?= $u['company_name'] ? htmlspecialchars($u['company_name']) : '— Super Admin / No company —' ?>
                                        </td>
                                        <td>
                                            <?php if ($u['is_super_admin']): ?>
                                                <span class="badge bg-dark">Super Admin</span>
                                            <?php else: ?>
                                                <span class="badge bg-primary">Agency User</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($u['is_active']): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="users.php?edit=<?= (int)$u['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                Edit
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>

<?php
require_once __DIR__ . '/../templates/footer.php';
