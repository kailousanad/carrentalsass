<?php
// public/vehicles.php

require_once __DIR__ . '/../includes/auth.php';
require_login();

if (is_super_admin()) {
    redirect('index.php');
}

require_once __DIR__ . '/../config/config.php';

$page_title = 'Vehicles – Car Rental SaaS';

$companyId = current_company_id();
if (!$companyId) {
    die('Company ID not found in session.');
}

$errors  = [];
$success = '';

/** ===== Helpers for insurance badge (from vehicle_insurances) ===== */
function insurance_days_left($endDate): int
{
    $today = strtotime(date('Y-m-d'));
    $end   = strtotime((string)$endDate);
    return (int)floor(($end - $today) / 86400);
}

function insurance_badge_class($days): string
{
    if ($days < 0)   return 'bg-dark';
    if ($days <= 10) return 'bg-danger';
    if ($days <= 30) return 'bg-warning text-dark';
    return 'bg-success';
}

/** ===== Cancel active insurance when vehicle is sold ===== */
function cancel_active_insurance_on_sold(PDO $pdo, int $companyId, int $vehicleId): void
{
    // Cancel active insurance
    $pdo->prepare("
        UPDATE vehicle_insurances
        SET status='cancelled',
            cancel_reason='Sold vehicle',
            cancelled_at=NOW(),
            updated_at=NOW()
        WHERE company_id=:cid AND vehicle_id=:vid AND status='active'
    ")->execute([
        'cid' => $companyId,
        'vid' => $vehicleId,
    ]);

    // Optional: clear legacy expiry date field (old system)
    $pdo->prepare("
        UPDATE vehicles
        SET insurance_expiry_date = NULL
        WHERE id=:id AND company_id=:cid
        LIMIT 1
    ")->execute([
        'id'  => $vehicleId,
        'cid' => $companyId,
    ]);

    // Optional: create notification (if table exists)
    try {
        $veh = $pdo->prepare("SELECT brand, model, plate_number FROM vehicles WHERE id=:id AND company_id=:cid LIMIT 1");
        $veh->execute(['id' => $vehicleId, 'cid' => $companyId]);
        $vmeta = $veh->fetch() ?: [];

        $data = json_encode([
            'vehicle_id' => $vehicleId,
            'plate_number' => $vmeta['plate_number'] ?? null,
            'vehicle' => trim(($vmeta['brand'] ?? '') . ' ' . ($vmeta['model'] ?? '')),
            'reason' => 'Sold vehicle',
        ], JSON_UNESCAPED_UNICODE);

        $pdo->prepare("
            INSERT INTO notifications (company_id, user_id, type, data, is_read, created_at)
            VALUES (:cid, NULL, 'insurance_cancelled', :data, 0, NOW())
        ")->execute([
            'cid'  => $companyId,
            'data' => $data,
        ]);
    } catch (Throwable $e) {
        // ignore notification errors to avoid breaking flow
    }
}

/** ===== CSRF (optional – keep safe if your system uses it) ===== */
if (empty($_SESSION['_csrf'])) {
    $_SESSION['_csrf'] = bin2hex(random_bytes(16));
}

/** ===== Change status via GET ===== */
if (isset($_GET['status'], $_GET['id']) && ctype_digit($_GET['id'])) {
    $id     = (int)$_GET['id'];
    $status = (string)$_GET['status'];

    $allowedStatus = ['in_park','on_rent','maintenance','sold'];

    if (in_array($status, $allowedStatus, true)) {

        $pdo->beginTransaction();
        try {
            // Update vehicle status
            $stmt = $pdo->prepare("UPDATE vehicles
                                   SET status = :status
                                   WHERE id = :id AND company_id = :company_id
                                   LIMIT 1");
            $stmt->execute([
                'status'     => $status,
                'id'         => $id,
                'company_id' => $companyId,
            ]);

            // Cancel insurance only if sold
            if ($status === 'sold') {
                cancel_active_insurance_on_sold($pdo, $companyId, $id);
            }

            $pdo->commit();
            header('Location: vehicles.php?success=1');
            exit;

        } catch (Throwable $e) {
            $pdo->rollBack();
            $errors[] = 'Error updating status: ' . $e->getMessage();
        }
    }
}

/** ===== Fetch vehicle to edit ===== */
$edit_vehicle = null;
if (isset($_GET['edit']) && ctype_digit($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM vehicles WHERE id = :id AND company_id = :company_id LIMIT 1");
    $stmt->execute([
        'id'         => $id,
        'company_id' => $companyId,
    ]);
    $edit_vehicle = $stmt->fetch();
}

/** ===== Handle POST (add/edit) ===== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CSRF check (optional)
    if (!isset($_POST['_csrf']) || !hash_equals($_SESSION['_csrf'], (string)$_POST['_csrf'])) {
        $errors[] = 'Security token invalid. Please refresh the page.';
    }

    $id                    = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $brand                 = trim($_POST['brand'] ?? '');
    $model                 = trim($_POST['model'] ?? '');
    $plate_number          = trim($_POST['plate_number'] ?? '');
    $vin                   = trim($_POST['vin'] ?? '');
    $year                  = trim($_POST['year'] ?? '');
    $color                 = trim($_POST['color'] ?? '');
    $mileage_current       = trim($_POST['mileage_current'] ?? '0');
    $fuel_type             = (string)($_POST['fuel_type'] ?? 'diesel');
    $status                = (string)($_POST['status'] ?? 'in_park');
    $insurance_expiry_date = trim($_POST['insurance_expiry_date'] ?? '');
    $technical_visit_date  = trim($_POST['technical_visit_expiry_date'] ?? '');
    $oil_change_next_at_km = trim($_POST['oil_change_next_at_km'] ?? '');
    $notes                 = trim($_POST['notes'] ?? '');

    if ($brand === '')        $errors[] = 'Brand is required.';
    if ($model === '')        $errors[] = 'Model is required.';
    if ($plate_number === '') $errors[] = 'Plate number is required.';

    if ($year !== '' && !ctype_digit($year)) {
        $errors[] = 'Year must be a number (e.g. 2022).';
    }

    if ($mileage_current !== '' && !ctype_digit($mileage_current)) {
        $errors[] = 'Mileage must be a positive number.';
    }

    $allowedFuel   = ['diesel','essence','hybrid','electric'];
    $allowedStatus = ['in_park','on_rent','maintenance','sold'];

    if (!in_array($fuel_type, $allowedFuel, true))   $fuel_type = 'diesel';
    if (!in_array($status, $allowedStatus, true))    $status    = 'in_park';

    if (empty($errors)) {
        $pdo->beginTransaction();
        try {
            if ($id > 0) {
                // UPDATE
                $sql = "UPDATE vehicles SET
                            brand = :brand,
                            model = :model,
                            plate_number = :plate_number,
                            vin = :vin,
                            year = :year,
                            color = :color,
                            mileage_current = :mileage_current,
                            fuel_type = :fuel_type,
                            status = :status,
                            insurance_expiry_date = :insurance_expiry_date,
                            technical_visit_expiry_date = :technical_visit_expiry_date,
                            oil_change_next_at_km = :oil_change_next_at_km,
                            notes = :notes
                        WHERE id = :id AND company_id = :company_id";

                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    'brand'                       => $brand,
                    'model'                       => $model,
                    'plate_number'                => $plate_number,
                    'vin'                         => $vin ?: null,
                    'year'                        => $year ?: null,
                    'color'                       => $color ?: null,
                    'mileage_current'             => (int)$mileage_current,
                    'fuel_type'                   => $fuel_type,
                    'status'                      => $status,
                    'insurance_expiry_date'       => $insurance_expiry_date ?: null,
                    'technical_visit_expiry_date' => $technical_visit_date ?: null,
                    'oil_change_next_at_km'       => $oil_change_next_at_km ?: null,
                    'notes'                       => $notes ?: null,
                    'id'                          => $id,
                    'company_id'                  => $companyId,
                ]);

                if ($status === 'sold') {
                    cancel_active_insurance_on_sold($pdo, $companyId, $id);
                }

            } else {
                // INSERT
                $sql = "INSERT INTO vehicles
                            (company_id, brand, model, plate_number, vin, year, color, mileage_current, fuel_type, status,
                             insurance_expiry_date, technical_visit_expiry_date, oil_change_next_at_km, notes)
                        VALUES
                            (:company_id, :brand, :model, :plate_number, :vin, :year, :color, :mileage_current, :fuel_type, :status,
                             :insurance_expiry_date, :technical_visit_expiry_date, :oil_change_next_at_km, :notes)";

                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    'company_id'                  => $companyId,
                    'brand'                       => $brand,
                    'model'                       => $model,
                    'plate_number'                => $plate_number,
                    'vin'                         => $vin ?: null,
                    'year'                        => $year ?: null,
                    'color'                       => $color ?: null,
                    'mileage_current'             => (int)$mileage_current,
                    'fuel_type'                   => $fuel_type,
                    'status'                      => $status,
                    'insurance_expiry_date'       => $insurance_expiry_date ?: null,
                    'technical_visit_expiry_date' => $technical_visit_date ?: null,
                    'oil_change_next_at_km'       => $oil_change_next_at_km ?: null,
                    'notes'                       => $notes ?: null,
                ]);

                $newId = (int)$pdo->lastInsertId();

                if ($status === 'sold') {
                    cancel_active_insurance_on_sold($pdo, $companyId, $newId);
                }
            }

            $pdo->commit();
            header('Location: vehicles.php?success=1');
            exit;

        } catch (Throwable $e) {
            $pdo->rollBack();
            $errors[] = 'Save error: ' . $e->getMessage();
        }
    }

    // If errors, keep edit mode if id exists (so modal opens filled)
    if (!empty($errors) && $id > 0 && !$edit_vehicle) {
        $stmt = $pdo->prepare("SELECT * FROM vehicles WHERE id = :id AND company_id = :company_id LIMIT 1");
        $stmt->execute([
            'id'         => $id,
            'company_id' => $companyId,
        ]);
        $edit_vehicle = $stmt->fetch();
    }
}

if (isset($_GET['success'])) {
    $success = 'Changes saved successfully.';
}

/** ===== Fetch vehicles (with active real insurance) ===== */
$stmt = $pdo->prepare("
    SELECT
        v.*,
        vi.id AS insurance_id,
        vi.end_date AS insurance_end_date,
        vi.status AS insurance_status
    FROM vehicles v
    LEFT JOIN vehicle_insurances vi
      ON vi.company_id = v.company_id
     AND vi.vehicle_id = v.id
     AND vi.status = 'active'
    WHERE v.company_id = :company_id
    ORDER BY v.id DESC
");
$stmt->execute(['company_id' => $companyId]);
$vehicles = $stmt->fetchAll();

require_once __DIR__ . '/../templates/header.php';
require_once __DIR__ . '/../templates/sidebar.php';
?>

<div class="col-12 col-lg-10 p-4">

  <div class="topbar d-flex justify-content-between align-items-center px-3 py-2 mb-3">
    <div>
      <h5 class="mb-0">Vehicles Management</h5>
      <div class="small text-muted"><?= count($vehicles) ?> vehicles</div>
    </div>

    <div class="d-flex gap-2">
      <a class="btn btn-sm btn-outline-dark" href="vehicles.php">
        <i class="bi bi-arrow-repeat me-1"></i> Refresh
      </a>

      <button type="button" class="btn btn-sm btn-primary"
              data-bs-toggle="modal" data-bs-target="#vehicleModal">
        <i class="bi bi-plus-circle me-1"></i> Add new vehicle
      </button>
    </div>
  </div>

  <?php if ($success && isset($_GET['success'])): ?>
    <div class="alert alert-success py-2"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>

  <!-- =========================
       VEHICLE MODAL (ADD/EDIT)
       ========================= -->
  <div class="modal fade" id="vehicleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable modal-dialog-centered">
      <div class="modal-content" style="border-radius:18px;">
        <div class="modal-header">
          <h6 class="modal-title d-flex align-items-center gap-2">
            <i class="bi bi-car-front"></i>
            <?= $edit_vehicle ? 'Edit vehicle' : 'Add new vehicle' ?>
          </h6>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">

          <?php if (!empty($errors)): ?>
            <div class="alert alert-danger py-2">
              <?php foreach ($errors as $err): ?>
                <div><?= htmlspecialchars($err) ?></div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>

          <form method="post" action="vehicles.php<?= $edit_vehicle ? '?edit=' . (int)$edit_vehicle['id'] : '' ?>">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($_SESSION['_csrf']) ?>">
            <input type="hidden" name="id" value="<?= $edit_vehicle ? (int)$edit_vehicle['id'] : 0 ?>">

            <div class="row g-2">

              <div class="col-md-6">
                <label class="form-label">Brand *</label>
                <input type="text" name="brand" class="form-control"
                       value="<?= htmlspecialchars($edit_vehicle['brand'] ?? '') ?>" required>
              </div>

              <div class="col-md-6">
                <label class="form-label">Model *</label>
                <input type="text" name="model" class="form-control"
                       value="<?= htmlspecialchars($edit_vehicle['model'] ?? '') ?>" required>
              </div>

              <div class="col-md-6">
                <label class="form-label">Plate number *</label>
                <input type="text" name="plate_number" class="form-control"
                       value="<?= htmlspecialchars($edit_vehicle['plate_number'] ?? '') ?>" required>
              </div>

              <div class="col-md-6">
                <label class="form-label">VIN</label>
                <input type="text" name="vin" class="form-control"
                       value="<?= htmlspecialchars($edit_vehicle['vin'] ?? '') ?>">
              </div>

              <div class="col-md-4">
                <label class="form-label">Year</label>
                <input type="text" name="year" class="form-control"
                       value="<?= htmlspecialchars($edit_vehicle['year'] ?? '') ?>">
              </div>

              <div class="col-md-4">
                <label class="form-label">Color</label>
                <input type="text" name="color" class="form-control"
                       value="<?= htmlspecialchars($edit_vehicle['color'] ?? '') ?>">
              </div>

              <div class="col-md-4">
                <label class="form-label">Current mileage (km)</label>
                <input type="text" name="mileage_current" class="form-control"
                       value="<?= htmlspecialchars($edit_vehicle['mileage_current'] ?? '0') ?>">
              </div>

              <div class="col-md-6">
                <label class="form-label">Fuel type</label>
                <?php $fuelValue = $edit_vehicle['fuel_type'] ?? 'diesel'; ?>
                <select name="fuel_type" class="form-select">
                  <option value="diesel"   <?= $fuelValue === 'diesel'   ? 'selected' : '' ?>>Diesel</option>
                  <option value="essence"  <?= $fuelValue === 'essence'  ? 'selected' : '' ?>>Essence</option>
                  <option value="hybrid"   <?= $fuelValue === 'hybrid'   ? 'selected' : '' ?>>Hybrid</option>
                  <option value="electric" <?= $fuelValue === 'electric' ? 'selected' : '' ?>>Electric</option>
                </select>
              </div>

              <div class="col-md-6">
                <label class="form-label">Status</label>
                <?php $statusValue = $edit_vehicle['status'] ?? 'in_park'; ?>
                <select name="status" class="form-select">
                  <option value="in_park"     <?= $statusValue === 'in_park'     ? 'selected' : '' ?>>In park</option>
                  <option value="on_rent"     <?= $statusValue === 'on_rent'     ? 'selected' : '' ?>>On rent</option>
                  <option value="maintenance" <?= $statusValue === 'maintenance' ? 'selected' : '' ?>>Maintenance</option>
                  <option value="sold"        <?= $statusValue === 'sold'        ? 'selected' : '' ?>>Sold</option>
                </select>
                <div class="small text-muted mt-1">
                  Note: If you set <b>Sold</b>, active insurance will be cancelled automatically.
                </div>
              </div>

              <div class="col-md-6">
                <label class="form-label">Insurance expiry date (legacy)</label>
                <input type="date" name="insurance_expiry_date" class="form-control"
                       value="<?= htmlspecialchars($edit_vehicle['insurance_expiry_date'] ?? '') ?>">
                <div class="small text-muted mt-1">
                  Real insurance is managed in <b>Insurance</b> module.
                </div>
              </div>

              <div class="col-md-6">
                <label class="form-label">Technical visit expiry date</label>
                <input type="date" name="technical_visit_expiry_date" class="form-control"
                       value="<?= htmlspecialchars($edit_vehicle['technical_visit_expiry_date'] ?? '') ?>">
              </div>

              <div class="col-md-6">
                <label class="form-label">Next oil change at (km)</label>
                <input type="text" name="oil_change_next_at_km" class="form-control"
                       value="<?= htmlspecialchars($edit_vehicle['oil_change_next_at_km'] ?? '') ?>">
              </div>

              <div class="col-12">
                <label class="form-label">Notes</label>
                <textarea name="notes" rows="3" class="form-control"><?= htmlspecialchars($edit_vehicle['notes'] ?? '') ?></textarea>
              </div>

            </div>

            <div class="d-flex gap-2 mt-3">
              <button type="submit" class="btn btn-primary flex-grow-1">
                <?= $edit_vehicle ? 'Save changes' : 'Add vehicle' ?>
              </button>

              <?php if ($edit_vehicle): ?>
                <a href="vehicles.php" class="btn btn-outline-dark">Cancel</a>
              <?php else: ?>
                <button type="button" class="btn btn-outline-dark" data-bs-dismiss="modal">Close</button>
              <?php endif; ?>
            </div>

          </form>

        </div>
      </div>
    </div>
  </div>

  <!-- LIST VEHICLES -->
  <div class="card shadow-sm">
    <div class="card-body">
      <div class="d-flex align-items-center justify-content-between mb-3">
        <h6 class="card-title mb-0">Your vehicles</h6>
        <div class="small text-muted">
          Tip: use <b>Edit</b> to open popup.
        </div>
      </div>

      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead>
          <tr>
            <th>ID</th>
            <th>Car</th>
            <th>Plate</th>
            <th>Mileage</th>
            <th>Status</th>
            <th>Insurance</th>
            <th style="min-width:180px;">Actions</th>
          </tr>
          </thead>
          <tbody>
          <?php if (!$vehicles): ?>
            <tr>
              <td colspan="7" class="text-center text-muted py-4">No vehicles yet.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($vehicles as $v): ?>
              <tr>
                <td class="fw-semibold"><?= (int)$v['id'] ?></td>
                <td>
                  <div class="fw-semibold"><?= htmlspecialchars($v['brand'] . ' ' . $v['model']) ?></div>
                  <?php if (!empty($v['color'])): ?>
                    <div class="small text-muted">Color: <?= htmlspecialchars((string)$v['color']) ?></div>
                  <?php endif; ?>
                </td>
                <td><?= htmlspecialchars((string)$v['plate_number']) ?></td>
                <td><?= (int)$v['mileage_current'] ?> km</td>
                <td>
                  <?php
                    $badgeClass = 'bg-secondary';
                    switch ((string)$v['status']) {
                      case 'in_park':     $badgeClass = 'bg-success'; break;
                      case 'on_rent':     $badgeClass = 'bg-primary'; break;
                      case 'maintenance': $badgeClass = 'bg-warning text-dark'; break;
                      case 'sold':        $badgeClass = 'bg-dark'; break;
                    }
                  ?>
                  <span class="badge <?= $badgeClass ?>">
                    <?= htmlspecialchars(ucfirst(str_replace('_',' ', (string)$v['status']))) ?>
                  </span>
                </td>

                <!-- Insurance: show from vehicle_insurances.active -->
                <td class="small">
                  <?php if (!empty($v['insurance_end_date'])): ?>
                    <?php
                      $d = insurance_days_left($v['insurance_end_date']);
                      $cls = insurance_badge_class($d);
                      $txt = ($d < 0) ? 'Expired' : ('باقي ' . $d . ' يوم');
                    ?>
                    <div class="fw-semibold"><?= htmlspecialchars((string)$v['insurance_end_date']) ?></div>
                    <span class="badge <?= $cls ?>"><?= htmlspecialchars($txt) ?></span>
                  <?php else: ?>
                    <?php if ((string)$v['status'] === 'sold'): ?>
                      <span class="badge bg-secondary">Insurance cancelled</span>
                    <?php else: ?>
                      <span class="text-muted">No insurance</span>
                    <?php endif; ?>
                  <?php endif; ?>
                </td>

                <td class="text-nowrap">
                  <!-- Edit opens server-side edit mode then auto-opens modal -->
                  <a href="vehicles.php?edit=<?= (int)$v['id'] ?>#openVehicleModal"
                     class="btn btn-sm btn-outline-primary mb-1">
                    <i class="bi bi-pencil-square me-1"></i>Edit
                  </a>

                  <div class="btn-group btn-group-sm mb-1" role="group">
                    <a href="vehicles.php?id=<?= (int)$v['id'] ?>&status=in_park"
                       class="btn btn-outline-success">Park</a>
                    <a href="vehicles.php?id=<?= (int)$v['id'] ?>&status=maintenance"
                       class="btn btn-outline-warning">Maint.</a>
                    <a href="vehicles.php?id=<?= (int)$v['id'] ?>&status=sold"
                       class="btn btn-outline-dark"
                       onclick="return confirm('Mark as sold? Active insurance will be cancelled.')">
                      Sold
                    </a>
                  </div>
                </td>

              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>

</div>

<?php if ($edit_vehicle || !empty($errors)): ?>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    if (window.bootstrap) {
      const el = document.getElementById('vehicleModal');
      if (el) new bootstrap.Modal(el).show();
    }
  });
</script>
<?php endif; ?>

<?php
require_once __DIR__ . '/../templates/footer.php';
