<?php
// templates/footer.php
declare(strict_types=1);
?>

      <!-- /Main content col -->
    </div><!-- /row -->
  </div><!-- /container-fluid -->
</div><!-- /app -->

<!-- =========================
     ULTRA TOAST CONTAINER
     ========================= -->
<div class="toast-container position-fixed bottom-0 end-0 p-3" id="toastContainer" style="z-index:1100;"></div>

<!-- =========================
     ULTRA CONFIRM MODAL
     ========================= -->
<div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title" id="confirmModalTitle">Confirm action</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="confirmModalBody">
        Are you sure you want to continue?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-dark" data-bs-dismiss="modal">Cancel</button>
        <a href="#" class="btn btn-danger" id="confirmModalBtn">Yes, continue</a>
      </div>
    </div>
  </div>
</div>

<!-- =========================
     Bootstrap JS (ALWAYS FIRST)
     ========================= -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- =========================
     Dashboard UI JS (Optional)
     ========================= -->
<script src="assets/js/dashboard-ui.js" defer></script>

<?php if (!empty($extra_js_files) && is_array($extra_js_files)): ?>
  <?php foreach ($extra_js_files as $f): ?>
    <script src="<?= htmlspecialchars($f, ENT_QUOTES) ?>"></script>
  <?php endforeach; ?>
<?php endif; ?>

<script>
function escapeHtml(str){
  return String(str).replace(/[&<>"']/g, (m)=>({
    "&":"&amp;",
    "<":"&lt;",
    ">":"&gt;",
    '"':"&quot;",
    "'":"&#039;"
  }[m]));
}

function showToast(message, type = 'info') {
  const colors = {
    success: 'bg-success',
    error: 'bg-danger',
    info: 'bg-primary',
    warning: 'bg-warning text-dark'
  };

  if (typeof window.bootstrap === 'undefined' || !window.bootstrap.Toast) {
    alert(message);
    return;
  }

  const toast = document.createElement('div');
  toast.className = `toast align-items-center text-white ${colors[type] || colors.info} border-0`;
  toast.setAttribute('role','alert');
  toast.setAttribute('aria-live','assertive');
  toast.setAttribute('aria-atomic','true');

  toast.innerHTML = `
    <div class="d-flex">
      <div class="toast-body fw-semibold">${escapeHtml(message)}</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  `;

  document.getElementById('toastContainer').appendChild(toast);
  const bsToast = new bootstrap.Toast(toast, { delay: 4200 });
  bsToast.show();

  toast.addEventListener('hidden.bs.toast', () => toast.remove());
}

function confirmAction(url, title = 'Confirm action', message = 'Are you sure?') {
  if (typeof window.bootstrap === 'undefined' || !window.bootstrap.Modal) {
    window.location.href = url;
    return;
  }
  document.getElementById('confirmModalTitle').innerText = title;
  document.getElementById('confirmModalBody').innerText = message;
  document.getElementById('confirmModalBtn').setAttribute('href', url);

  const modal = new bootstrap.Modal(document.getElementById('confirmModal'));
  modal.show();
}

(function(){
  const params = new URLSearchParams(window.location.search);
  if (params.has('success')) showToast(params.get('success'), 'success');
  if (params.has('error')) showToast(params.get('error'), 'error');
})();
</script>

</body>
</html>
