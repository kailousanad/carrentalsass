<?php
// templates/header.php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';

$page_title = $page_title ?? 'Car Rental SaaS';
$userName   = $_SESSION['user_name'] ?? 'User';
$qValue     = isset($_GET['q']) ? (string)$_GET['q'] : '';
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($page_title) ?></title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<!-- حذف هذه الأسطر -->
<link rel="stylesheet" href="assets/css/bookings-list.css?...">
<link rel="stylesheet" href="assets/css/dashboard-ui.css?...">
<link rel="stylesheet" href="assets/css/app.css?...">

<!-- أضف هذا السطر الوحيد -->
<link rel="stylesheet" href="assets/css/ultra-all.css?v=<?= time() ?>">
  <?php if (!empty($extra_css_files) && is_array($extra_css_files)): ?>
    <?php foreach ($extra_css_files as $f): ?>
      <link rel="stylesheet" href="<?= htmlspecialchars($f) ?>">
    <?php endforeach; ?>
  <?php endif; ?>
</head>

<body>

<div class="app">
  <div class="container-fluid">
    <div class="row g-0">

      <!-- Topbar (Global) -->
      <div class="col-12 app-topbar">
        <div class="topbar-inner d-flex flex-wrap align-items-center justify-content-between gap-2">

          <div class="d-flex align-items-center gap-2">
            <!-- Mobile sidebar toggle -->
            <button class="btn btn-sm btn-outline-dark d-lg-none"
                    type="button"
                    data-bs-toggle="offcanvas"
                    data-bs-target="#sidebarOffcanvas"
                    aria-controls="sidebarOffcanvas">
              <i class="bi bi-list"></i>
            </button>

            <div>
              <div class="topbar-title"><?= e($page_title) ?></div>
              <div class="topbar-sub">Fast actions • Smart alerts • Clean workflow</div>
            </div>
          </div>

          <!-- Quick search (UX) -->
          <form class="topbar-search position-relative flex-grow-1 d-none d-md-block"
                method="get" action="bookings.php">
            <i class="bi bi-search"></i>
            <input class="form-control form-control-sm"
                   name="q"
                   placeholder="Search booking #, plate, customer…"
                   value="<?= e($qValue) ?>">
          </form>

          <div class="d-flex align-items-center gap-2">
            <!-- Quick actions -->
            <div class="dropdown">
              <button class="btn btn-sm btn-primary dropdown-toggle" data-bs-toggle="dropdown">
                <i class="bi bi-plus-lg me-1"></i> Quick add
              </button>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="booking_create.php"><i class="bi bi-calendar2-plus me-2"></i>New booking</a></li>
                <li><a class="dropdown-item" href="vehicles.php"><i class="bi bi-car-front me-2"></i>Add vehicle</a></li>
                <li><a class="dropdown-item" href="expenses.php"><i class="bi bi-receipt me-2"></i>Add expense</a></li>
                <li><a class="dropdown-item" href="incomes.php"><i class="bi bi-cash-coin me-2"></i>Add income</a></li>
              </ul>
            </div>

            <!-- User menu -->
            <div class="dropdown">
              <button class="btn btn-sm btn-outline-dark dropdown-toggle" data-bs-toggle="dropdown">
                <i class="bi bi-person-circle me-1"></i><?= e($userName) ?>
              </button>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="settings.php"><i class="bi bi-gear me-2"></i>Settings</a></li>
                <li><a class="dropdown-item" href="notifications.php"><i class="bi bi-bell me-2"></i>Notifications</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
              </ul>
            </div>
          </div>

        </div>
      </div>
