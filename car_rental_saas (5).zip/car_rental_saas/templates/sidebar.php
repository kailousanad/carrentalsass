<?php
// templates/sidebar.php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';

$userName = $_SESSION['user_name'] ?? 'User';

ob_start(); ?>
  <div class="app-sidebar__inner">
    <div class="dusty-brand">
      <div class="dusty-brand__logo"><span></span></div>
      <div class="dusty-brand__meta">
        <div class="dusty-brand__name">Car Rental SaaS</div>
        <div class="dusty-brand__sub"><?= e($userName) ?></div>
      </div>
    </div>

    <?php include __DIR__ . '/sidebar.php.nav.php'; ?>
  </div>
<?php $sidebarInner = ob_get_clean(); ?>

<!-- ✅ Desktop sidebar -->
<aside class="col-12 col-lg-2 d-none d-lg-block app-sidebar app-sidebar--dusty">
  <?= $sidebarInner ?>
</aside>

<!-- ✅ Mobile offcanvas sidebar (matches header button target) -->
<div class="offcanvas offcanvas-start d-lg-none dusty-offcanvas" tabindex="-1"
     id="sidebarOffcanvas" aria-labelledby="sidebarOffcanvasLabel">
  <div class="offcanvas-header">
    <h6 class="offcanvas-title fw-bold" id="sidebarOffcanvasLabel">Menu</h6>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
  </div>
  <div class="offcanvas-body p-0">
    <aside class="app-sidebar app-sidebar--dusty app-sidebar--offcanvas">
      <?= $sidebarInner ?>
    </aside>
  </div>
</div>
