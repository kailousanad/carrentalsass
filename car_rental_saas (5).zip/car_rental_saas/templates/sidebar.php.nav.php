<?php
// templates/sidebar.php.nav.php
declare(strict_types=1);

$current = basename($_SERVER['PHP_SELF'] ?? '');

/** safe active helper */
if (!function_exists('nav_active')) {
  function nav_active(string $file, string $current): string {
    return $file === $current ? 'active' : '';
  }
}

$unread = $unread ?? 0; // safe default
?>

<nav class="nav flex-column gap-1 px-1">
  <a class="nav-link <?= nav_active('index.php',$current) ?>" href="index.php">
    <i class="bi bi-speedometer2 me-2"></i>Dashboard
  </a>

  <div class="text-uppercase small text-muted fw-bold px-2 mt-3">Operations</div>

  <a class="nav-link <?= nav_active('bookings.php',$current) ?>" href="bookings.php">
    <i class="bi bi-calendar2-check me-2"></i>Bookings
  </a>

  <a class="nav-link <?= nav_active('calendar.php',$current) ?>" href="calendar.php">
    <i class="bi bi-calendar3 me-2"></i>Calendar
  </a>

  <a class="nav-link <?= nav_active('vehicles.php',$current) ?>" href="vehicles.php">
    <i class="bi bi-car-front me-2"></i>Vehicles
  </a>
  <a class="nav-link <?= nav_active('drivers.phpp',$current) ?>" href="drivers.php">
    <i class="bi bi-car-front me-2"></i>drivers
  <a class="nav-link <?= nav_active('maintenance.php',$current) ?>" href="maintenance.php">
    <i class="bi bi-wrench-adjustable-circle me-2"></i>Maintenance
  </a>

  <a class="nav-link <?= nav_active('gps.php',$current) ?>" href="gps.php">
    <i class="bi bi-broadcast-pin me-2"></i>GPS
  </a>
    <a class="nav-link <?= nav_active('insurance.php',$current) ?>" href="insurance.php">
    <i class="bi bi-broadcast-pin me-2"></i>insurance
 </a>
  <div class="text-uppercase small text-muted fw-bold px-2 mt-3">Finance</div>

  <a class="nav-link <?= nav_active('incomes.php',$current) ?>" href="incomes.php">
    <i class="bi bi-cash-coin me-2"></i>Incomes
  </a>

  <a class="nav-link <?= nav_active('expenses.php',$current) ?>" href="expenses.php">
    <i class="bi bi-receipt-cutoff me-2"></i>Expenses
  </a>
    <a class="nav-link <?= nav_active('statistics.php',$current) ?>" href="statistics.php">
    <i class="bi bi-receipt-cutoff me-2"></i>statistics
  </a>
      <a class="nav-link <?= nav_active('installments.php',$current) ?>" href="installments.php">
    <i class="bi bi-receipt-cutoff me-2"></i>installments
  </a>


  <div class="text-uppercase small text-muted fw-bold px-2 mt-3">System</div>

  <a class="nav-link <?= nav_active('notifications.php',$current) ?>" href="notifications.php">
    <i class="bi bi-bell me-2"></i>Notifications
    <?php if (!empty($unread)): ?>
      <span class="badge bg-danger ms-auto"><?= (int)$unread ?></span>
    <?php endif; ?>
  </a>

  <a class="nav-link <?= nav_active('settings.php',$current) ?>" href="settings.php">
    <i class="bi bi-gear me-2"></i>Settings
  </a>

  <?php if (function_exists('is_super_admin') && is_super_admin()): ?>
    <div class="text-uppercase small text-muted fw-bold px-2 mt-3">Super admin</div>
    <a class="nav-link <?= nav_active('companies.php',$current) ?>" href="companies.php">
      <i class="bi bi-buildings me-2"></i>Companies
    </a>
    <a class="nav-link <?= nav_active('users.php',$current) ?>" href="users.php">
      <i class="bi bi-people me-2"></i>Users
    </a>
  <?php endif; ?>

  <div class="text-uppercase small text-muted fw-bold px-2 mt-3">Session</div>
  <a class="nav-link text-danger" href="logout.php">
    <i class="bi bi-box-arrow-right me-2"></i>Logout
  </a>
</nav>
